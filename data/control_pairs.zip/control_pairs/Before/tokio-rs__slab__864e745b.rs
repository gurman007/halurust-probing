    fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Entry::Filled(ref mut val) => Some(val),
            Entry::Empty(_) => None,
        } 
    }
    fn as_ref(&self) -> Option<&T> {
        match *self {
            Entry::Filled(ref val) => Some(val),
            Entry::Empty(_) => None,
        } 
    }
    fn put(&mut self, val: T) -> usize {
        match *self {
            Entry::Empty(nxt) => {
                mem::replace(self, Entry::Filled(val));
                nxt
            },
            Entry::Filled(_) => panic!("Should not happen"),
        } 
    }

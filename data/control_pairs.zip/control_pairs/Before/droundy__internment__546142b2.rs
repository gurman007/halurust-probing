struct RcI<T: Hash+Eq+PartialEq> {
    data: HashMap<T, Box<T>>,
    counts: HashMap<Intern<T>, usize>,
}
    pub fn new(val: T) -> ArcIntern<T> {
        let mymutex = match CONTAINER.try_get::<Mutex<RcI<T>>>() {
            Some(m) => m,
            None => {
                CONTAINER.set::<Mutex<RcI<T>>>(Mutex::new(
                    RcI {
                        data: HashMap::<T,Box<T>>::new(),
                        counts: HashMap::<Intern<T>,usize>::new(),
                    }));
                CONTAINER.get::<Mutex<RcI<T>>>()
            },
        };
        let mut m = mymutex.lock().unwrap();
        if m.data.get(&val).is_none() {
            let b = Box::new(val.clone());
            let p: *const T = b.borrow();
            m.counts.insert(Intern { pointer: p }, 1);
            m.data.insert(val.clone(), b);
            return ArcIntern { pointer: p };
        }
        let xx = ArcIntern { pointer: m.data.get(&val).unwrap().borrow() };
        // need to increment the count for this!
        if let Some(mc) = m.counts.get_mut(&Intern{ pointer: xx.pointer }) {
            *mc += 1;
        }
        xx
    }
    fn drop(&mut self) {
        let mut m = CONTAINER.get::<Mutex<RcI<T>>>().lock().unwrap();
        let mut am_finished = false;
        if let Some(mc) = m.counts.get_mut(&Intern{ pointer: self.pointer }) {
            *mc -= 1;
            if *mc == 0 {
                am_finished = true;
            }
        }
        if am_finished {
            m.data.remove(self);
            m.counts.remove(&Intern{ pointer: self.pointer });
        }
    }

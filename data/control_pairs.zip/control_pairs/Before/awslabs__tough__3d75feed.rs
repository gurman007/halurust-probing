pub(crate) enum Command {
    /// Create a new root.json metadata file
    Init {
        /// Path where root.json is written
        path: PathBuf,
    },
}
    pub(crate) fn run(&self) -> Result<()> {
        match self {
            Command::Init { path } => write_json(
                path,
                &Signed {
                    signed: Root {
                        spec_version: "1.0".to_owned(),
                        consistent_snapshot: true,
                        version: NonZeroU64::new(1).unwrap(),
                        expires: Utc::now(),
                        keys: HashMap::new(),
                        roles: hashmap! {
                            RoleType::Root => role_keys!(),
                            RoleType::Snapshot => role_keys!(),
                            RoleType::Targets => role_keys!(),
                            RoleType::Timestamp => role_keys!(),
                        },
                        _extra: HashMap::new(),
                    },
                    signatures: Vec::new(),
                },
            ),
        }
    }

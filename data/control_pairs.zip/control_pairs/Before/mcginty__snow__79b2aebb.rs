pub enum Session {
    /// A session in the handshake stage (the starting state).
    Handshake(HandshakeState),

    /// A session after having completed a handshake, in general-purpose transport mode.
    Transport(TransportState),

    /// A session after having completed a handshake, in explicit-nonce transport mode.
    StatelessTransport(StatelessTransportState),
}
    pub fn into_transport_mode(self) -> Result<Self, Error> {
        match self {
            Session::Handshake(state) => {
                if !state.is_finished() {
                    bail!(StateProblem::HandshakeNotFinished)
                } else {
                    Ok(Session::Transport(state.try_into()?))
                }
            },
            _ => Ok(self)
        }
    }
    pub fn into_stateless_transport_mode(self) -> Result<Self, Error> {
        match self {
            Session::Handshake(state) => {
                if !state.is_finished() {
                    bail!(StateProblem::HandshakeNotFinished)
                } else {
                    Ok(Session::StatelessTransport(state.try_into()?))
                }
            },
            _ => Ok(self)
        }
    }
    fn into(self) -> Session {
        Session::Handshake(self)
    }

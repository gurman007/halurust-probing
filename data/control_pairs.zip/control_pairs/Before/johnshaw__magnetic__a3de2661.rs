pub struct MPSCConsumer<T, B: Buffer<T>> {
    queue: Arc<MPSCQueue<T, B>>,
}
pub fn mpsc_queue<T, B: Buffer<T>>(buf: B) -> (MPSCProducer<T, B>, MPSCConsumer<T, B>) {
    let queue = MPSCQueue {
        head: CachePadded::new(AtomicPair::default()),
        tail: CachePadded::new(AtomicUsize::new(0)),
        buf,
        consumer: AtomicBool::new(true),
        _marker: PhantomData,
    };

    let queue = Arc::new(queue);

    (
        MPSCProducer {
            queue: queue.clone(),
        },
        MPSCConsumer { queue },
    )
}
pub struct SPMCProducer<T, B: Buffer<T>> {
    queue: Arc<SPMCQueue<T, B>>,
}
pub fn spmc_queue<T, B: Buffer<T>>(buf: B) -> (SPMCProducer<T, B>, SPMCConsumer<T, B>) {
    let queue = SPMCQueue {
        head: CachePadded::new(AtomicUsize::new(0)),
        tail: CachePadded::new(AtomicPair::default()),
        buf,
        producer: AtomicBool::new(true),
        _marker: PhantomData,
    };

    let queue = Arc::new(queue);

    (
        SPMCProducer {
            queue: queue.clone(),
        },
        SPMCConsumer { queue },
    )
}
pub struct SPSCConsumer<T, B: Buffer<T>> {
    queue: Arc<SPSCQueue<T, B>>,
}
pub struct SPSCProducer<T, B: Buffer<T>> {
    queue: Arc<SPSCQueue<T, B>>,
}
pub fn spsc_queue<T, B: Buffer<T>>(buf: B) -> (SPSCProducer<T, B>, SPSCConsumer<T, B>) {
    let queue = SPSCQueue {
        head: CachePadded::new(AtomicUsize::new(0)),
        tail: CachePadded::new(AtomicUsize::new(0)),
        buf,
        _marker: PhantomData,
    };

    let queue = Arc::new(queue);

    (
        SPSCProducer {
            queue: queue.clone(),
        },
        SPSCConsumer { queue },
    )
}

fn encode_var_usize(buffer: &mut Vec<u8>, mut value: usize) -> usize {
    let mut len_chunks = 0;
    loop {
        let mut chunk = (value as u8) & 0x7F_u8;
        value >>= 7;
        chunk |= ((value != 0) as u8) << 7;
        buffer.push(chunk);
        len_chunks += 1;
        if value == 0 {
            break
        }
    }
    len_chunks
}
fn decode_var_usize(buffer: &[u8]) -> Option<usize> {
    let mut result: usize = 0;
    for i in 0.. {
        let byte = *buffer.get(i)?;
        let shifted = ((byte & 0x7F_u8) as usize).checked_shl((i * 7) as u32)?;
        result = result.checked_add(shifted)?;
        if (byte & 0x80) == 0 {
            break
        }
    }
    Some(result)
}

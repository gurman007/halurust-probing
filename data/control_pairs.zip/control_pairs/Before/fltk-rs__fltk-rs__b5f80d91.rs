pub fn override_scale() -> f32 {
    unsafe {
        Fl_override_scale()
    }
}
pub fn restore_scale(s: f32) {
    unsafe {
        Fl_restore_scale(s)
    }
}
    pub fn index(&self) -> Option<i32> {
        Some(self.find(&self.try_current_widget()?))
    }   

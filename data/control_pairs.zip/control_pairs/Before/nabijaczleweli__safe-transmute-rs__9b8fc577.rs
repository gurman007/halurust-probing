unsafe fn copy_to_vec_unchecked<S, T>(data: &[S]) -> Vec<T> {
    let len = data.len() * core::mem::size_of::<S>() / core::mem::size_of::<T>();
    let mut out = Vec::with_capacity(len);
    core::ptr::copy_nonoverlapping(
        data.as_ptr() as *const u8,
        out.as_mut_ptr() as *mut u8,
        len * core::mem::size_of::<T>());
    out.set_len(len);
    out
}
pub struct UnalignedError<'a, S, T> {
    /// The required amount of bytes to discard at the front for the attempted
    /// transmutation to be successful.
    pub offset: usize,
    /// A slice of the original source data.
    pub source: &'a [S],
    phantom: PhantomData<T>,
}
    pub fn new(offset: usize, source: &'a [S]) -> Self {
        UnalignedError {
            offset,
            source,
            phantom: PhantomData,
        }
    }

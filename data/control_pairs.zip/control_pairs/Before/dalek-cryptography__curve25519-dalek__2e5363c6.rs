    pub fn verify<D>(&self, message: &[u8], signature: &Signature) -> Result<(), SignatureError>
            where D: Digest<OutputSize = U64> + Default
    {
        let A = self.0.decompress()
            .ok_or_else(|| SignatureError(InternalError::PointDecompressionError))?;

        let mut h = D::default();
        h.input(signature.r.as_bytes());
        h.input(self.as_bytes());
        h.input(&message);
        let k = Scalar::from_hash(h);

        let R = EdwardsPoint::vartime_double_scalar_mul_basepoint(&k, &(-A), &signature.s);

        if R.compress() == signature.r {
            Ok(())
        } else {
            Err(SignatureError(InternalError::VerifyError))
        }
    }
    pub fn verify_prehashed<D>(&self,
                               prehashed_message: D,
                               context: Option<&[u8]>,
                               signature: &Signature) -> Result<(), SignatureError>
        where D: Digest<OutputSize = U64> + Default
    {
        let ctx = context.unwrap_or(b"");
        debug_assert!(ctx.len() <= 255, "The context must not be longer than 255 octets.");

        let A = self.0.decompress()
            .ok_or_else(|| SignatureError(InternalError::PointDecompressionError))?;

        let mut h = D::default();
        h.input(b"SigEd25519 no Ed25519 collisions");
        h.input(&[1]); // Ed25519ph
        h.input(&[ctx.len() as u8]);
        h.input(ctx);
        h.input(signature.r.as_bytes());
        h.input(self.as_bytes());
        h.input(prehashed_message.fixed_result().as_slice());
        let k = Scalar::from_hash(h);

        let R = EdwardsPoint::vartime_double_scalar_mul_basepoint(&k, &(-A), &signature.s);

        if R.compress() == signature.r {
            Ok(())
        } else {
            Err(SignatureError(InternalError::VerifyError))
        }
    }

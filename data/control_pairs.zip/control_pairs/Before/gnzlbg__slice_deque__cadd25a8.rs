    fn vecdeque_drop() {
        static mut DROPS: i32 = 0;
        #[derive(Clone)] struct Elem(i32);
        impl Drop for Elem {
            fn drop(&mut self) {
                unsafe {
                    println!("dropping: {} += 1 = {}", DROPS, DROPS + 1);
                    DROPS += 1;
                }
            }
        }

        let mut ring = SliceDeque::new();
        ring.push_back(Elem(0));
        ring.push_front(Elem(1));
        ring.push_back(Elem(2));
        ring.push_front(Elem(3));
        ::std::mem::drop(ring);

        assert_eq!(unsafe { DROPS }, 4);
    }

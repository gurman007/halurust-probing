pub fn key_len(tag: u32) -> usize {
    encoded_len_varint(u64::from(tag << 3))
}
pub fn encoded_len_varint(value: u64) -> usize {
    // Based on [VarintSize64][1].
    // [1]: https://github.com/protocolbuffers/protobuf/blob/v28.3/src/google/protobuf/io/coded_stream.h#L1744-L1756
    // Safety: value | 1 is non-zero.
    let log2value = unsafe { NonZeroU64::new_unchecked(value | 1) }.ilog2();
    ((log2value * 9 + (64 + 9)) / 64) as usize
}

    pub fn new(private_key: [u8; 32]) -> Curve25519PublicKey {
        Self { inner: PublicKey::from(private_key) }
    }
    pub fn to_bytes(&self) -> [u8; 32] {
        self.inner.to_bytes()
    }
    pub fn from_base64(base64_key: &str) -> Result<Curve25519PublicKey, Curve25519KeyError> {
        let key_vec = base64_decode(base64_key)?;

        if key_vec.len() == 32 {
            let mut key = [0u8; 32];
            key.copy_from_slice(&key_vec);
            Ok(Self::from(key))
        } else {
            Err(Curve25519KeyError::InvalidKeyLength)
        }
    }
    fn from(bytes: [u8; 32]) -> Curve25519PublicKey {
        Curve25519PublicKey { inner: PublicKey::from(bytes) }
    }
pub enum Curve25519KeyError {
    #[error("Failed decoding curve25519 key from base64: {}", .0)]
    Base64Error(#[from] DecodeError),
    #[error("Failed decoding curve25519 key from base64: Invalid number of bytes for curve25519.")]
    InvalidKeyLength,
}
    fn decoding_incorrect_num_of_bytes_fails() {
        let base64_payload = "aaaa";
        assert!(matches!(
            Curve25519PublicKey::from_base64(base64_payload),
            Err(Curve25519KeyError::InvalidKeyLength)
        ));
    }

    fn to_tokens(&self, tokens: &mut TokenStream) {
        let t = match self {
            Self::Text(text) => quote! { MatcherSegment::Text(#text)},
            Self::Env(env) => quote! {MatcherSegment::Env(#env)},
        };
        tokens.append_all(t);
    }

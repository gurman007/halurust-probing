    fn emit_result_is_err(&mut self, destination: u8) {
        let ok = ProgramResult::Ok(0);
        let err_kind = unsafe { *(&ok as *const _ as *const u64).add(1) };
        self.emit_ins(X86Instruction::lea(OperandSize::S64, RBP, destination, Some(X86IndirectAccess::Offset(self.slot_on_environment_stack(RuntimeEnvironmentSlot::ProgramResult)))));
        self.emit_ins(X86Instruction::cmp_immediate(OperandSize::S64, destination, err_kind as i64, Some(X86IndirectAccess::Offset(0))));
    }
    pub fn unwrap_err(self) -> E {
        match self {
            Self::Ok(value) => panic!("unwrap_err {:?}", value),
            Self::Err(error) => error,
        }
    }
    fn test_program_result_is_stable() {
        let ok = ProgramResult::Ok(42);
        assert_eq!(unsafe { *(&ok as *const _ as *const u64) }, 0);
        let err = ProgramResult::Err(Box::new(EbpfError::JitNotCompiled));
        assert_eq!(unsafe { *(&err as *const _ as *const u64) }, 1);
    }

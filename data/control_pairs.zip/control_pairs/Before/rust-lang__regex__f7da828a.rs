fn utf8_decode(bytes: &[u8]) -> Option<Result<char, u8>> {
    if bytes.is_empty() {
        return None;
    }
    match core::str::from_utf8(&bytes[..core::cmp::min(4, bytes.len())]) {
        Ok(s) => Some(Ok(s.chars().next().unwrap())),
        Err(_) => Some(Err(bytes[0])),
    }
}
    pub fn alternation(hirs: Vec<Hir>) -> Hir {
        // We rebuild the alternation by simplifying it. We proceed similarly
        // as the concatenation case. But in this case, there's no literal
        // simplification happening. We're just flattening alternations.
        let mut new = vec![];
        for hir in hirs {
            let (kind, props) = hir.into_parts();
            match kind {
                HirKind::Alternation(hirs2) => {
                    new.extend(hirs2);
                }
                kind => {
                    new.push(Hir { kind, props });
                }
            }
        }
        if new.is_empty() {
            return Hir::fail();
        } else if new.len() == 1 {
            return new.pop().unwrap();
        }
        let props = Properties::alternation(&new);
        Hir { kind: HirKind::Alternation(new), props }
    }
    fn print_alternation() {
        roundtrip("|", "(?:|)");
        roundtrip("||", "(?:||)");

        roundtrip("a|b", "(?:a|b)");
        roundtrip("a|b|c", "(?:a|b|c)");
        roundtrip("foo|bar|quux", "(?:(?:foo)|(?:bar)|(?:quux))");
    }
    fn regression_repetition_alternation() {
        let expr = Hir::concat(alloc::vec![
            Hir::literal("x".as_bytes()),
            Hir::repetition(hir::Repetition {
                min: 1,
                max: None,
                greedy: true,
                hir: Box::new(Hir::alternation(alloc::vec![
                    Hir::literal("a".as_bytes()),
                    Hir::literal("b".as_bytes()),
                ])),
            }),
            Hir::literal("y".as_bytes()),
        ]);
        assert_eq!(r"(?:x(?:a|b)+y)", expr.to_string());

        let expr = Hir::concat(alloc::vec![
            Hir::look(hir::Look::Start),
            Hir::repetition(hir::Repetition {
                min: 1,
                max: None,
                greedy: true,
                hir: Box::new(Hir::alternation(alloc::vec![
                    Hir::look(hir::Look::Start),
                    Hir::look(hir::Look::End),
                ])),
            }),
            Hir::look(hir::Look::End),
        ]);
        assert_eq!(r"(?:\A(?:\A|\z)+\z)", expr.to_string());
    }
    fn regression_alternation_concat() {
        let expr = Hir::concat(alloc::vec![
            Hir::literal("a".as_bytes()),
            Hir::alternation(alloc::vec![
                Hir::literal("b".as_bytes()),
                Hir::literal("c".as_bytes()),
            ]),
        ]);
        assert_eq!(r"(?:a(?:b|c))", expr.to_string());

        let expr = Hir::concat(alloc::vec![
            Hir::look(hir::Look::Start),
            Hir::alternation(alloc::vec![
                Hir::look(hir::Look::Start),
                Hir::look(hir::Look::End),
            ]),
        ]);
        assert_eq!(r"(?:\A(?:\A|\z))", expr.to_string());
    }
    fn analysis_is_alternation_literal() {
        // Positive examples.
        assert!(props(r"a").is_alternation_literal());
        assert!(props(r"ab").is_alternation_literal());
        assert!(props(r"abc").is_alternation_literal());
        assert!(props(r"(?m)abc").is_alternation_literal());
        assert!(props(r"a|b").is_alternation_literal());
        assert!(props(r"a|b|c").is_alternation_literal());
        assert!(props(r"foo|bar").is_alternation_literal());
        assert!(props(r"foo|bar|baz").is_alternation_literal());
        assert!(props(r"[a]").is_alternation_literal());
        assert!(props(r"[a]|b").is_alternation_literal());
        assert!(props(r"a|[b]").is_alternation_literal());
        assert!(props(r"(?:a)|b").is_alternation_literal());
        assert!(props(r"a|(?:b)").is_alternation_literal());

        // Negative examples.
        assert!(!props(r"").is_alternation_literal());
        assert!(!props(r"^").is_alternation_literal());
        assert!(!props(r"(a)").is_alternation_literal());
        assert!(!props(r"a+").is_alternation_literal());
        assert!(!props(r"foo(a)").is_alternation_literal());
        assert!(!props(r"(a)foo").is_alternation_literal());
        assert!(!props(r"[ab]").is_alternation_literal());
        assert!(!props(r"[ab]|b").is_alternation_literal());
        assert!(!props(r"a|[ab]").is_alternation_literal());
        assert!(!props(r"(a)|b").is_alternation_literal());
        assert!(!props(r"a|(b)").is_alternation_literal());
    }
    fn smart_alternation() {
        assert_eq!(
            t("(?:foo)|(?:bar)"),
            hir_alt(vec![hir_lit("foo"), hir_lit("bar")])
        );
        assert_eq!(
            t("quux|(?:abc|def|xyz)|baz"),
            hir_alt(vec![
                hir_lit("quux"),
                hir_lit("abc"),
                hir_lit("def"),
                hir_lit("xyz"),
                hir_lit("baz"),
            ])
        );
    }

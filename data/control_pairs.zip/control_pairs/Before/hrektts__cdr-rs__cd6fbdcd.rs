    fn read_padding_of<T>(&mut self) -> Result<()> {
        let alignment = std::mem::size_of::<T>();
        let mut padding = [0; 8];
        self.pos %= 8;
        match (self.pos as usize) % alignment {
            0 => Ok(()),
            n @ 1...7 => {
                let amt = alignment - n;
                self.read_size(amt as u64)?;
                self.reader
                    .read_exact(&mut padding[..amt])
                    .map_err(Into::into)
            }
            _ => unreachable!(),
        }
    }
    fn write_padding_of<T>(&mut self) -> Result<()> {
        let alignment = std::mem::size_of::<T>();
        let padding = [0; 8];
        self.pos %= 8;
        match (self.pos as usize) % alignment {
            0 => Ok(()),
            n @ 1...7 => {
                let amt = alignment - n;
                self.pos += amt as u64;
                self.writer.write_all(&padding[..amt]).map_err(Into::into)
            }
            _ => unreachable!(),
        }
    }

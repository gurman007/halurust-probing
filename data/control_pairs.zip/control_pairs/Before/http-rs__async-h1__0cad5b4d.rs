    pub fn new(res: Response) -> Self {
        Self {
            res,
            depth: 0,
            state: State::Start,
            bytes_written: 0,
            head: vec![],
            head_bytes_written: 0,
            body_len: 0,
            body_bytes_written: 0,
            chunked: ChunkedEncoder::new(),
            method,
        }
    }

    fn random() -> Self {
        use serde_json::Value;
        Value::Null
    }
struct U<T1, T2: Debug, T3>
where
    T3: Display,
{
    a: T1,
    b: T2,
    c: T3,
    value: [T1; 16],
}
fn generate() {
    <U<u8, i32, i64>>::random();
    <C<(i16, i8, u32), [u8; 32], String>>::random();
    <E<Vec<u8>, char, bool>>::random();
}

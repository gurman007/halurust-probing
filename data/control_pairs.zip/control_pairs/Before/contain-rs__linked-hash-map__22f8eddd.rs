    pub fn contains_key(&self, k: &K) -> bool {
        self.map.contains_key(&KeyRef{k: k})
    }
    pub fn get(&self, k: &K) -> Option<&V> {
        self.map.get(&KeyRef{k: k}).map(|e| &e.value)
    }
    pub fn get_mut(&mut self, k: &K) -> Option<&mut V> {
        self.map.get_mut(&KeyRef{k: k}).map(|e| &mut e.value)
    }
    pub fn get_refresh(&mut self, k: &K) -> Option<&V> {
        let (value, node_ptr_opt) = match self.map.get_mut(&KeyRef{k: k}) {
            None => (None, None),
            Some(node) => {
                let node_ptr: *mut LinkedHashMapEntry<K, V> = &mut **node;
                (Some(unsafe { &(*node_ptr).value }), Some(node_ptr))
            }
        };
        match node_ptr_opt {
            None => (),
            Some(node_ptr) => {
                self.detach(node_ptr);
                self.attach(node_ptr);
            }
        }
        return value;
    }
    pub fn remove(&mut self, k: &K) -> Option<V> {
        let removed = self.map.remove(&KeyRef{k: k});
        removed.map(|mut node| {
            let node_ptr: *mut LinkedHashMapEntry<K,V> = &mut *node;
            self.detach(node_ptr);
            node.value
        })
    }
    fn index(&self, index: &K) -> &V {
        self.get(index).expect("no entry found for key")
    }
    fn index_mut(&mut self, index: &K) -> &mut V {
        self.get_mut(index).expect("no entry found for key")
    }
    fn test_iter_mut() {
        let mut map = LinkedHashMap::new();
        map.insert("a", 10);
        map.insert("c", 30);
        map.insert("b", 20);

        {
            let mut iter = map.iter_mut();
            let entry = iter.next().unwrap();
            assert_eq!(&"a", entry.0);
            *entry.1 = 17;

            // reverse iterator
            let mut iter = iter.rev();
            let entry = iter.next().unwrap();
            assert_eq!(&"b", entry.0);
            *entry.1 = 23;

            let entry = iter.next().unwrap();
            assert_eq!(&"c", entry.0);
            assert_eq!(None, iter.next());
            assert_eq!(None, iter.next());
        }

        assert_eq!(17, map["a"]);
        assert_eq!(23, map["b"]);
    }

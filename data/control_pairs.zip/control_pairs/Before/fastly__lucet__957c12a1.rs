    fn run_func(&mut self, func: FunctionHandle, args: &[Val]) -> Result<RunResult, Error> {
        if !(self.state.is_ready() || (self.state.is_faulted() && !self.state.is_fatal())) {
            return Err(Error::InvalidArgument(
                "instance must be ready or non-fatally faulted",
            ));
        }
        if func.ptr.as_usize() == 0 {
            return Err(Error::InvalidArgument(
                "entrypoint function cannot be null; this is probably a malformed module",
            ));
        }

        let sig = self.module.get_signature(func.id);

        // in typechecking these values, we can only really check that arguments are correct.
        // in the future we might want to make return value use more type safe as well.

        if sig.params.len() != args.len() {
            return Err(Error::InvalidArgument(
                "entrypoint function signature mismatch (number of arguments is incorrect)",
            ));
        }

        for (param_ty, arg) in sig.params.iter().zip(args.iter()) {
            if param_ty != &arg.value_type() {
                return Err(Error::InvalidArgument(
                    "entrypoint function signature mismatch",
                ));
            }
        }

        self.entrypoint = Some(func.ptr);

        let mut args_with_vmctx = vec![Val::from(self.alloc.slot().heap)];
        args_with_vmctx.extend_from_slice(args);

        let self_ptr = self as *mut _;
        Context::init_with_callback(
            unsafe { self.alloc.stack_u64_mut() },
            &mut self.ctx,
            execution::exit_guest_region,
            self_ptr,
            func.ptr.as_usize(),
            &args_with_vmctx,
        )?;

        self.with_terminability().swap_and_return()
    }
    fn with_terminability(&mut self) -> &mut Self {
        unsafe {
            // Get a raw pointer to the top of the guest stack.
            let top_of_stack = self.ctx.gpr.rsp as *mut u64;
            // Move the guest code address to rbx, and then put the address of the activation thunk
            // at the top of the stack, so that we will start execution at `enter_guest_region`.
            self.ctx.gpr.rbx = *top_of_stack;
            *top_of_stack = crate::context::lucet_context_activate as u64;
            // Pass a pointer to our guest-side entrypoint bootstrap code in `rsi`, and then put
            // its first argument (a raw pointer to `self`) in `rdi`.
            self.ctx.gpr.rsi = execution::enter_guest_region as u64;
            self.ctx.gpr.rdi = self.ctx.callback_data_ptr() as u64;
        }
        self
    }
pub unsafe extern "C" fn exit_guest_region(instance: *mut Instance) {
    let terminable = (*instance)
        .kill_state
        .terminable
        .swap(false, Ordering::SeqCst);
    if !terminable {
        // If we are here, something else has taken the terminable flag, so it's not safe to
        // actually exit a guest context yet. Because this is called when exiting a guest context,
        // the termination mechanism will be a signal, delivered at some point (hopefully soon!).
        // Further, because the termination mechanism will be a signal, we are constrained to only
        // signal-safe behavior. So, we will hang indefinitely waiting for the sigalrm to arrive.
        #[allow(clippy::empty_loop)]
        loop {}
    } else {
        let current_domain = (*instance).kill_state.execution_domain.lock().unwrap();
        match *current_domain {
            Domain::Pending => {
                panic!("Invalid state: Instance marked as pending while exiting a guest region.");
            }
            Domain::Guest => {
                // We finished executing the code in our guest region normally! We should reset
                // the kill state, invalidating any existing killswitches' weak references. We
                // forget the mutex guard so that we don't invoke its destructor and segfault.
                (*instance).kill_state = Arc::new(KillState::default());
                mem::forget(current_domain);
            }
            Domain::Hostcall => {
                panic!(
                    "Invalid state: Instance marked as in a hostcall while exiting a guest region."
                );
            }
            Domain::Terminated => {
                panic!(
                    "Invalid state: Instance marked as terminated while exiting a guest region."
                );
            }
            Domain::Cancelled => {
                panic!("Invalid state: Instance marked as cancelled while exiting a guest region.");
            }
        };
    }
}
    pub fn end_hostcall(&self) -> Option<TerminationDetails> {
        let mut current_domain = self.execution_domain.lock().unwrap();
        match *current_domain {
            Domain::Pending => {
                panic!("Invalid state: Instance marked as pending while exiting a hostcall.");
            }
            Domain::Guest => {
                panic!("Invalid state: Instance marked as in guest code while exiting a hostcall.");
            }
            Domain::Hostcall => {
                *current_domain = Domain::Guest;
                None
            }
            Domain::Terminated => Some(TerminationDetails::Remote),
            Domain::Cancelled => {
                panic!("Invalid state: Instance marked as cancelled while exiting a hostcall.");
            }
        }
    }

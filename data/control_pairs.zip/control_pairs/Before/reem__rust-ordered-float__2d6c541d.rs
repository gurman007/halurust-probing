mod impl_arbitrary {
    use super::{FloatIsNan, NotNan, OrderedFloat};
    use arbitrary::{Arbitrary, Unstructured};
    use num_traits::FromPrimitive;

    macro_rules! impl_arbitrary {
        ($($f:ident),+) => {
            $(
                impl<'a> Arbitrary<'a> for NotNan<$f> {
                    fn arbitrary(u: &mut Unstructured<'a>) -> arbitrary::Result<Self> {
                        let float: $f = u.arbitrary()?;
                        match NotNan::new(float) {
                            Ok(notnan_value) => Ok(notnan_value),
                            Err(FloatIsNan) => {
                                // If our arbitrary float input was a NaN (encoded by exponent = max
                                // value), then replace it with a finite float, reusing the mantissa
                                // bits.
                                //
                                // This means the output is not uniformly distributed among all
                                // possible float values, but Arbitrary makes no promise that that
                                // is true.
                                //
                                // An alternative implementation would be to return an
                                // `arbitrary::Error`, but that is not as useful since it forces the
                                // caller to retry with new random/fuzzed data; and the precendent of
                                // `arbitrary`'s built-in implementations is to prefer the approach of
                                // mangling the input bits to fit.

                                let (mantissa, _exponent, sign) =
                                    num_traits::Float::integer_decode(float);
                                let revised_float = <$f>::from_i64(
                                    i64::from(sign) * mantissa as i64
                                ).unwrap();

                                // If this unwrap() fails, then there is a bug in the above code.
                                Ok(NotNan::new(revised_float).unwrap())
                            }
                        }
                    }

                    fn size_hint(depth: usize) -> (usize, Option<usize>) {
                        <$f as Arbitrary>::size_hint(depth)
                    }
                }

                impl<'a> Arbitrary<'a> for OrderedFloat<$f> {
                    fn arbitrary(u: &mut Unstructured<'a>) -> arbitrary::Result<Self> {
                        let float: $f = u.arbitrary()?;
                        Ok(OrderedFloat::from(float))
                    }

                    fn size_hint(depth: usize) -> (usize, Option<usize>) {
                        <$f as Arbitrary>::size_hint(depth)
                    }
                }
            )*
        }
    }
    impl_arbitrary! { f32, f64 }
}

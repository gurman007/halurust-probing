pub(crate) fn locate(src: u16, get: bool) -> Result<usize, ()> {
    let mut pos: u32 = if get {
        (src & GET_MASK).trailing_zeros()
    } else {
        src.trailing_zeros()
    };

    Err(())
}
pub(crate) fn in_state(origin: u16, pos: u16) -> Result<u16, ()> {
    // if the bit is marked for free to edit, mark the bit
    if (origin & (0b1 << (2 * pos + 1))) == 0 {
        return Ok(origin | (0b1 << (2 * pos + 1)))
    }

    // already marked, skip
    Err(())
}
pub(crate) fn out_state(origin: u16, pos: u16) -> Result<u16, ()> {
    // only update if the position is marked, otherwise it will be deadlocked
    if (origin & (0b1 << (2 * pos + 1))) > 0 {
        return Ok(origin ^ (0b11 << (2 * pos)));
    }

    // the bit not marked for being edited? skip
    Err(())
}

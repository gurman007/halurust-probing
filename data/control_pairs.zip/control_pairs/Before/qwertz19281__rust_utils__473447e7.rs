        impl<T> AsArray for ($t,$($ts),*) {
            type Dest = [T; $n];
            #[inline]
            fn as_array(self) -> Self::Dest {
                let ($l,$($ls),*) = self;
                [$l,$($ls),*]
            }
        }
impl<T> RefClonable for Rc<T> {
    #[inline] fn refc(&self) -> Self {
        Rc::clone(self)
    }
}

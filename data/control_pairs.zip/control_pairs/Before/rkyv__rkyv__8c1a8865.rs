    fn partial_ord_option() {
        use core::cmp::Ordering;

        use super::ArchivedOption;

        let a: ArchivedOption<u8> = ArchivedOption::Some(42);
        let b = Some(42);
        assert_eq!(Some(Ordering::Equal), a.partial_cmp(&b));
        assert_eq!(Some(Ordering::Equal), b.partial_cmp(&a));

        let a: ArchivedOption<u8> = ArchivedOption::Some(1);
        let b = Some(2);
        assert_eq!(Some(Ordering::Less), a.partial_cmp(&b));
        assert_eq!(Some(Ordering::Greater), b.partial_cmp(&a));

        let a: ArchivedOption<u8> = ArchivedOption::Some(2);
        let b = Some(1);
        assert_eq!(Some(Ordering::Greater), a.partial_cmp(&b));
        assert_eq!(Some(Ordering::Less), b.partial_cmp(&a));
    }
impl<T: PartialEq<U>, U, E: PartialEq<F>, F> PartialEq<ArchivedResult<T, E>>
    for Result<U, F>
{
    #[inline]
    fn eq(&self, other: &ArchivedResult<T, E>) -> bool {
        other.eq(self)
    }
}

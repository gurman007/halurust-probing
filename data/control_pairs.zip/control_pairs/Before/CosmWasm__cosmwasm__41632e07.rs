fn expand_attributes(func: &mut ItemFn) -> syn::Result<TokenStream> {
    let attributes = std::mem::take(&mut func.attrs);
    let mut stream = TokenStream::new();
    for attribute in attributes {
        if !attribute.path().is_ident("set_state_version") {
            func.attrs.push(attribute);
            continue;
        }

        if func.sig.ident != "migrate" {
            return Err(syn::Error::new_spanned(
                &attribute,
                "you only want to add this macro to your migrate function",
            ));
        }

        let version: syn::LitInt = attribute.parse_args()?;
        let version = version.base10_digits();

        stream = quote! {
            #stream

            #[allow(unused)]
            #[doc(hidden)]
            #[link_section = "cw_contract_state_version"]
            /// This is an internal constant exported as a custom section denoting the contract state version.
            /// The format and even the existence of this value is an implementation detail, DO NOT RELY ON THIS!
            static __CW_CONTRACT_STATE_VERSION: &str = #version;
        };
    }

    Ok(stream)
}
    fn contract_state_version_expansion() {
        let code = quote! {
            #[set_state_version(2)]
            fn migrate(deps: DepsMut, env: Env, msg: MigrateMsg) -> Response {
                // Logic here
            }
        };

        let actual = entry_point_impl(TokenStream::new(), code);
        let expected = quote! {
            #[allow(unused)]
            #[doc(hidden)]
            #[link_section = "cw_contract_state_version"]
            /// This is an internal constant exported as a custom section denoting the contract state version.
            /// The format and even the existence of this value is an implementation detail, DO NOT RELY ON THIS!
            static __CW_CONTRACT_STATE_VERSION: &str = "2";

            fn migrate(deps: DepsMut, env: Env, msg: MigrateMsg) -> Response {
                // Logic here
            }

            #[cfg(target_arch = "wasm32")]
            mod __wasm_export_migrate {
                #[no_mangle]
                extern "C" fn migrate(ptr_0: u32, ptr_1: u32) -> u32 {
                    ::cosmwasm_std::do_migrate(&super::migrate, ptr_0, ptr_1)
                }
            }
        };

        assert_eq!(actual.to_string(), expected.to_string());
    }

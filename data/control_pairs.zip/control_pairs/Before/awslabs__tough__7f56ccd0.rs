    pub fn write<P>(&self, outdir: P, consistent_snapshot: bool) -> Result<()>
    where
        P: AsRef<Path>,
    {
        let outdir = outdir.as_ref();
        std::fs::create_dir_all(outdir).context(error::DirCreate { path: outdir })?;

        let filename = self.signed.signed.filename(consistent_snapshot);

        let path = outdir.join(filename);
        std::fs::write(&path, &self.buffer).context(error::FileWrite { path })
    }
    fn sign(
        path: &PathBuf,
        key_source: &[Box<dyn KeySource>],
        cross_sign: Option<PathBuf>,
    ) -> Result<()> {
        let root: Signed<Root> = load_file(path)?;

        let signed_root = match cross_sign {
            // This will get the keys from current root.json for validation
            None => SignedRole::new(
                root.signed.clone(),
                &KeyHolder::Root(root.signed),
                key_source,
                &SystemRandom::new(),
            )
            .context(error::SignRoot { path })?,
            Some(cross_sign_root) => {
                // This will get the keys from cross-sign root.json for validation
                let old_root: Signed<Root> = load_file(&cross_sign_root)?;
                SignedRole::new(
                    root.signed,
                    &KeyHolder::Root(old_root.signed),
                    key_source,
                    &SystemRandom::new(),
                )
                .context(error::SignRoot { path })?
            }
        };

        // Quick check that root is signed by enough key IDs
        for (roletype, rolekeys) in &signed_root.signed().signed.roles {
            if rolekeys.threshold.get() > rolekeys.keyids.len() as u64 {
                return Err(error::Error::UnstableRoot {
                    role: *roletype,
                    threshold: rolekeys.threshold.get(),
                    actual: rolekeys.keyids.len(),
                });
            }
        }

        // Signature check for root
        let threshold = signed_root
            .signed()
            .signed
            .roles
            .get(&RoleType::Root)
            .ok_or_else(|| error::Error::UnstableRoot {
                // The code should never reach this point
                role: RoleType::Root,
                threshold: 0,
                actual: 0,
            })?
            .threshold
            .get();
        let signature_count = signed_root.signed().signatures.len();
        if threshold > signature_count as u64 {
            return Err(error::Error::SignatureRoot {
                threshold,
                signature_count,
            });
        }

        // Use `tempfile::NamedTempFile::persist` to perform an atomic file write.
        let parent = path.parent().context(error::PathParent { path })?;
        let mut writer =
            NamedTempFile::new_in(parent).context(error::FileTempCreate { path: parent })?;
        writer
            .write_all(signed_root.buffer())
            .context(error::FileWrite { path })?;
        writer.persist(path).context(error::FilePersist { path })?;
        Ok(())
    }

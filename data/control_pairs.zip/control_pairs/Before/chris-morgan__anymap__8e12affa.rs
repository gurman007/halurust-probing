fn test_entry() {
    #[derive(Show, PartialEq)] struct A(i32);
    #[derive(Show, PartialEq)] struct B(i32);
    #[derive(Show, PartialEq)] struct C(i32);
    #[derive(Show, PartialEq)] struct D(i32);
    #[derive(Show, PartialEq)] struct E(i32);
    #[derive(Show, PartialEq)] struct F(i32);
    #[derive(Show, PartialEq)] struct J(i32);

    let mut map: AnyMap = AnyMap::new();
    assert_eq!(map.insert(A(10)), None);
    assert_eq!(map.insert(B(20)), None);
    assert_eq!(map.insert(C(30)), None);
    assert_eq!(map.insert(D(40)), None);
    assert_eq!(map.insert(E(50)), None);
    assert_eq!(map.insert(F(60)), None);

    // Existing key (insert)
    match map.entry::<A>() {
        Entry::Vacant(_) => unreachable!(),
        Entry::Occupied(mut view) => {
            assert_eq!(view.get(), &A(10));
            assert_eq!(view.insert(A(100)), A(10));
        }
    }
    assert_eq!(map.get::<A>().unwrap(), &A(100));
    assert_eq!(map.len(), 6);


    // Existing key (update)
    match map.entry::<B>() {
        Entry::Vacant(_) => unreachable!(),
        Entry::Occupied(mut view) => {
            let v = view.get_mut();
            let new_v = B(v.0 * 10);
            *v = new_v;
        }
    }
    assert_eq!(map.get().unwrap(), &B(200));
    assert_eq!(map.len(), 6);


    // Existing key (remove)
    match map.entry::<C>() {
        Entry::Vacant(_) => unreachable!(),
        Entry::Occupied(view) => {
            assert_eq!(view.remove(), C(30));
        }
    }
    assert_eq!(map.get::<C>(), None);
    assert_eq!(map.len(), 5);


    // Inexistent key (insert)
    match map.entry::<J>() {
        Entry::Occupied(_) => unreachable!(),
        Entry::Vacant(view) => {
            assert_eq!(*view.insert(J(1000)), J(1000));
        }
    }
    assert_eq!(map.get::<J>().unwrap(), &J(1000));
    assert_eq!(map.len(), 6);
}

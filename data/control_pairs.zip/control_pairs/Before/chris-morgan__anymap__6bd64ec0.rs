pub struct AnyMap {
    data: HashMap<TypeId, Box<Any>:'static>,
}
    pub fn new() -> AnyMap {
        AnyMap {
            data: HashMap::new(),
        }
    }

    fn serialize_none(self) -> Result<Self::Ok> {
        self.add_value(0_u8)
    }
    fn serialize_some<T: ?Sized>(self, v: &T) -> Result<Self::Ok>
    where
        T: ser::Serialize,
    {
        self.add_value(1_u8)?;
        v.serialize(self)
    }

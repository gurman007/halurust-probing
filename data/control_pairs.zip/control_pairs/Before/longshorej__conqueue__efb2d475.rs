struct QueueHead<T> {
    element: T,
    next: *mut QueueHead<T>,
}
    pub fn push(&self, element: T) {
        let mut new = Box::into_raw(Box::new(QueueHead {
            element,
            next: ptr::null_mut(),
        }));

        loop {
            unsafe {
                let in_queue = self.in_queue.load(Ordering::SeqCst);

                (*new).next = in_queue;

                if self
                    .in_queue
                    .compare_and_swap(in_queue, new, Ordering::SeqCst)
                    == in_queue
                {
                    break;
                }
            }
        }
    }
    pub fn pop(&mut self) -> Option<T> {
        if self.out_queue.is_null() {
            loop {
                let mut head = self.in_queue.load(Ordering::SeqCst);

                if head.is_null() {
                    break;
                }

                if self
                    .in_queue
                    .compare_and_swap(head, ptr::null_mut(), Ordering::SeqCst)
                    == head
                {
                    while !head.is_null() {
                        unsafe {
                            let next = (*head).next;
                            (*head).next = self.out_queue;
                            self.out_queue = head;
                            head = next;
                        }
                    }

                    break;
                }
            }
        }

        if self.out_queue.is_null() {
            None
        } else {
            unsafe {
                let head = Box::from_raw(self.out_queue);
                self.out_queue = head.next;
                Some(head.element)
            }
        }
    }
            fn drop(&mut self) {
                self.sum.fetch_add(self.value, Ordering::SeqCst);
            }

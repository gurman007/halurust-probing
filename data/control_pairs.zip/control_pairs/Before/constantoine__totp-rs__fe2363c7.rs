    pub fn new(algorithm: Algorithm, digits: usize, skew: u8, step: u64, secret: T, issuer: Option<String>, account_name: String) -> Result<TOTP<T>, TotpUrlError> {
        if issuer.is_some() && issuer.as_ref().unwrap().contains(':') {
            return Err(TotpUrlError::Issuer);
        }
        if account_name.contains(':') {
            return Err(TotpUrlError::AccountName);
        }
        Ok(TOTP {
            algorithm,
            digits,
            skew,
            step,
            secret,
            issuer,
            account_name,
        })
    }
    pub fn from_url<S: AsRef<str>>(url: S) -> Result<TOTP<Vec<u8>>, TotpUrlError> {
        let url = Url::parse(url.as_ref()).map_err(|err| TotpUrlError::Url(err))?;
        if url.scheme() != "otpauth" {
            return Err(TotpUrlError::Scheme);
        }
        if url.host() != Some(Host::Domain("totp")) {
            return Err(TotpUrlError::Host);
        }

        let mut algorithm = Algorithm::SHA1;
        let mut digits = 6;
        let mut step = 30;
        let mut secret = Vec::new();
        let mut issuer: Option<String> = None;
        let mut account_name: String;

        let path = url.path().trim_start_matches('/');
        if path.contains(':') {
            let parts = path.split_once(':').unwrap();
            issuer = Some(urlencoding::decode(parts.0.to_owned().as_str()).map_err(|_| TotpUrlError::Issuer)?.to_string());
            account_name = parts.1.trim_start_matches(':').to_owned();
        } else {
            account_name = path.to_owned();
        }

        account_name = urlencoding::decode(account_name.as_str()).map_err(|_| TotpUrlError::AccountName)?.to_string();

        for (key, value) in url.query_pairs() {
            match key.as_ref() {
                "algorithm" => {
                    algorithm = match value.as_ref() {
                        "SHA1" => Algorithm::SHA1,
                        "SHA256" => Algorithm::SHA256,
                        "SHA512" => Algorithm::SHA512,
                        _ => return Err(TotpUrlError::Algorithm),
                    }
                }
                "digits" => {
                    digits = value.parse::<usize>().map_err(|_| TotpUrlError::Digits)?;
                }
                "period" => {
                    step = value.parse::<u64>().map_err(|_| TotpUrlError::Step)?;
                }
                "secret" => {
                    secret =
                        base32::decode(base32::Alphabet::RFC4648 { padding: false }, value.as_ref())
                            .ok_or(TotpUrlError::Secret)?;
                }
                "issuer" => {
                    let param_issuer = value.parse::<String>().map_err(|_| TotpUrlError::Issuer)?;
                    if issuer.is_some() && param_issuer.as_str() != issuer.as_ref().unwrap() {
                        return Err(TotpUrlError::Issuer);
                    }
                    issuer = Some(param_issuer);
                }
                _ => {}
            }
        }

        if issuer.is_some() && issuer.as_ref().unwrap().contains(':') {
            return Err(TotpUrlError::Issuer);
        }
        if account_name.contains(':') {
            return Err(TotpUrlError::AccountName);
        }
        if secret.is_empty() {
            return Err(TotpUrlError::Secret);
        }

        TOTP::new(algorithm, digits, 1, step, secret, issuer, account_name)
    }
fn assert_digits(digits: &usize) -> Result<(), Rfc6238Error> {
    if !(&6..=&8).contains(&digits) {
        Err(Rfc6238Error::InvalidDigits)
    } else {
        Ok(())
    }
}

    fn deserialize_char<V>(self, visitor: V) -> Result<V::Value>
    where
        V: de::Visitor<'de>,
    {
        let mut buf = [0u8; 4];
        self.reader.read_exact(&mut buf[..1])?;

        let width = utf8_char_width(buf[0]);
        if width != 1 {
            Err(Error::InvalidCharEncoding)
        } else {
            self.read_size(width as u64)?;
            visitor.visit_char(buf[0] as char)
        }
    }
pub enum Error {
    Message(String),
    Io(io::Error),
    DeserializeAnyNotSupported,
    InvalidBoolEncoding(u8),
    InvalidChar(char),
    InvalidCharEncoding,
    InvalidEncapsulation,
    InvalidUtf8Encoding(Utf8Error),
    NumberOutOfRange,
    SequenceMustHaveLength,
    SizeLimit,
    TypeNotSupported,
}
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        use Error::*;

        match *self {
            Message(ref msg) => Display::fmt(msg, f),
            Io(ref err) => Display::fmt(err, f),
            DeserializeAnyNotSupported => write!(
                f,
                "does not support the serde::Deserializer::deserialize_any method"
            ),
            InvalidBoolEncoding(v) => write!(f, "expected 0 or 1, found {}", v),
            InvalidChar(v) => write!(f, "expected char of width 1, found {}", v),
            InvalidCharEncoding => write!(f, "char is not valid UTF-8"),
            InvalidEncapsulation => write!(f, "encapsulation is not valid"),
            InvalidUtf8Encoding(ref err) => Display::fmt(err, f),
            NumberOutOfRange => write!(f, "sequence is too long"),
            SequenceMustHaveLength => {
                write!(f, "sequences must have a knowable size ahead of time")
            }
            SizeLimit => write!(f, "the size limit has been reached"),
            TypeNotSupported => write!(f, "unsupported type"),
        }
    }
    fn serialize_char(self, v: char) -> Result<Self::Ok> {
        let width = v.len_utf8();
        if width != 1 {
            Err(Error::InvalidChar(v))
        } else {
            let mut buf = [0u8; 1];
            v.encode_utf8(&mut buf);
            self.add_pos(width as u64);
            self.writer.write_all(&buf[..width]).map_err(Into::into)
        }
    }
    fn serialize_str(self, v: &str) -> Result<Self::Ok> {
        let terminating_char = [0u8];
        let l = v.len() + terminating_char.len();
        self.write_usize_as_u32(l)?;
        self.add_pos(l as u64);
        self.writer.write_all(v.as_bytes())?;
        self.writer.write_all(&terminating_char).map_err(Into::into)
    }
    fn serialize_char(self, v: char) -> Result<Self::Ok> {
        self.add_size(v.len_utf8() as u64)
    }

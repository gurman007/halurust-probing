    fn home_dir(&self) -> &Path {
        Path::new(&self.extras.home_dir)
    }
    fn with_home_dir(mut self, home_dir: &str) -> User {
        self.extras.home_dir = home_dir.to_owned();
        self
    }
    fn shell(&self) -> &Path {
        Path::new(&self.extras.shell)
    }
    fn with_shell(mut self, shell: &str) -> User {
        self.extras.shell = shell.to_owned();
        self
    }
            fn new(uid: uid_t, name: &str, primary_group: gid_t) -> Self;
    fn members(&self) -> &[String] {
        &*self.members
    }
        pub trait UserExt {

            /// Returns a path to this user’s home directory.
            fn home_dir(&self) -> &Path;

            /// Sets this user value’s home directory to the given string.
            /// Can be used to construct test users, which by default come with a
            /// dummy home directory string.
            fn with_home_dir(mut self, home_dir: &str) -> Self;

            /// Returns a path to this user’s shell.
            fn shell(&self) -> &Path;

            /// Sets this user’s shell path to the given string.
            /// Can be used to construct test users, which by default come with a
            /// dummy shell field.
            fn with_shell(mut self, shell: &str) -> Self;

            // TODO(ogham): Isn’t it weird that the setters take string slices, but
            // the getters return paths?

            /// Create a new `User` with the given user ID, name, and primary
            /// group ID, with the rest of the fields filled with dummy values.
            ///
            /// This method does not actually create a new user on the system—it
            /// should only be used for comparing users in tests.
            fn new(uid: uid_t, name: &str, primary_group: gid_t) -> Self;
        }
            pub unsafe fn from_passwd(passwd: c_passwd) -> UserExtras {
                let home_dir = from_raw_buf(passwd.pw_dir);
                let shell    = from_raw_buf(passwd.pw_shell);

                UserExtras {
                    home_dir:  home_dir,
                    shell:     shell,
                }
            }
            fn default() -> UserExtras {
                UserExtras {
                    home_dir: String::from("/var/empty"),
                    shell:    String::from("/bin/false"),
                }
            }

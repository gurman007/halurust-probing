    fn into_iter(self) -> Self::IntoIter {
        self.children.into_iter()
    }
    fn check_visitability() {
        let docs = parse_document_source::<DefaultScalarValue>(
            //language=GraphQL
            "
            query Hero {
                hero(episode: EMPIRE) {
                    name
                    aliasedName: name
                    friends {
                        name
                    }
                }
            }
            ",
        )
        .unwrap();
        let fragments = extract_fragments(&docs);

        if let crate::ast::Definition::Operation(ref op) = docs[0] {
            let vars = graphql_vars! {};
            let look_ahead = selection_look_ahead(&op.item.selection_set[0], &vars, &fragments);

            assert_eq!(look_ahead.field_original_name(), "hero");
            assert!(look_ahead.field_alias().is_none());
            assert_eq!(look_ahead.field_name(), "hero");

            assert!(look_ahead.has_arguments());
            let arg = look_ahead.arguments().next().unwrap();
            assert_eq!(arg.name(), "episode");
            assert_eq!(ValueDebug::from(arg.value()), ValueDebug::Enum("EMPIRE"));

            let children = look_ahead.children();
            assert!(!children.is_empty());
            assert_eq!(
                children.names().collect::<Vec<_>>(),
                vec!["name", "aliasedName", "friends"]
            );
            let mut child_iter = children.iter();

            let name_child = child_iter.next().unwrap();
            assert!(children.has_child("name"));
            assert_eq!(
                LookAheadDebug::new(name_child),
                LookAheadDebug::new(&children.select("name").unwrap())
            );
            assert_eq!(name_child.field_original_name(), "name");
            assert_eq!(name_child.field_alias(), None);
            assert_eq!(name_child.field_name(), "name");
            assert!(!name_child.has_arguments());
            assert!(name_child.children().is_empty());

            let aliased_name_child = child_iter.next().unwrap();
            assert!(children.has_child("aliasedName"));
            assert_eq!(
                LookAheadDebug::new(aliased_name_child),
                LookAheadDebug::new(&children.select("aliasedName").unwrap())
            );
            assert_eq!(aliased_name_child.field_original_name(), "name");
            assert_eq!(aliased_name_child.field_alias(), Some("aliasedName"));
            assert_eq!(aliased_name_child.field_name(), "aliasedName");
            assert!(!aliased_name_child.has_arguments());
            assert!(aliased_name_child.children().is_empty());

            let friends_child = child_iter.next().unwrap();
            assert!(children.has_child("friends"));
            assert_eq!(
                LookAheadDebug::new(friends_child),
                LookAheadDebug::new(&children.select("friends").unwrap())
            );
            assert_eq!(friends_child.field_original_name(), "friends");
            assert_eq!(friends_child.field_alias(), None);
            assert_eq!(friends_child.field_name(), "friends");
            assert!(!friends_child.has_arguments());
            assert!(!friends_child.children().is_empty());
            assert_eq!(
                friends_child.children().names().collect::<Vec<_>>(),
                vec!["name"]
            );

            assert!(child_iter.next().is_none());

            let friends_children = friends_child.children();
            let mut friends_child_iter = friends_children.iter();
            let child = friends_child_iter.next().unwrap();
            assert!(friends_children.has_child("name"));
            assert_eq!(
                LookAheadDebug::new(child),
                LookAheadDebug::new(&children.select("name").unwrap())
            );
            assert_eq!(child.field_original_name(), "name");
            assert_eq!(child.field_alias(), None);
            assert_eq!(child.field_name(), "name");
            assert!(!child.has_arguments());
            assert!(child.children().is_empty());

            assert!(friends_child_iter.next().is_none());
        } else {
            panic!("No Operation found");
        }
    }
    fn into_iter(self) -> Self::IntoIter {
        self.key_value_list.into_iter()
    }

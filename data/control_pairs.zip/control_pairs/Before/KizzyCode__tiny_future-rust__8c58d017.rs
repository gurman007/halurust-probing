	pub fn access_shared_state(&self, modifier: &mut FnMut(&mut U)) {
		let mut shared_state_lock = self.0.shared_state.lock().unwrap();
		modifier(&mut *shared_state_lock);
	}
	pub fn access_shared_state_param<V>(&self, modifier: &mut FnMut(&mut U, V), parameter: V) {
		let mut shared_state_lock = self.0.shared_state.lock().unwrap();
		modifier(&mut *shared_state_lock, parameter);
	}

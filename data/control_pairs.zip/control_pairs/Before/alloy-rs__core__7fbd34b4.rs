    pub fn format_units_with(&self, mut unit: Unit, separator: DecimalSeparator) -> String {
        // Edge case: If the number is signed and the unit is the largest possible unit, we need to
        //            subtract 1 from the unit to avoid overflow.
        if self.is_signed() && unit == Unit::MAX {
            unit = Unit::new(Unit::MAX.get() - 1).unwrap();
        }
        let units = unit.get() as usize;
        let exp10 = unit.wei();

        // TODO: `decimals` are formatted twice because U256 does not support alignment
        // (`:0>width`).
        match *self {
            Self::U256(amount) => {
                let integer = amount / exp10;
                let decimals = (amount % exp10).to_string();
                format!("{integer}{}{decimals:0>units$}", separator.separator())
            }
            Self::I256(amount) => {
                let exp10 = I256::from_raw(exp10);
                let sign = if amount.is_negative() { "-" } else { "" };
                let integer = (amount / exp10).twos_complement();
                let decimals = ((amount % exp10).twos_complement()).to_string();
                format!("{sign}{integer}{}{decimals:0>units$}", separator.separator())
            }
        }
    }

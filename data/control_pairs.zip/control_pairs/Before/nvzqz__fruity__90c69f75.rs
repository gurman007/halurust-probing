    fn class() -> &'static Class;
            fn class() -> &'static $crate::objc::Class {
                extern "C" {
                    #[link_name = $class_symbol]
                    static CLASS: $crate::objc::Class;
                }
                unsafe { &CLASS }
            }

    fn test_find_shell_deep_in_tree() {
        let tree = MockProcessTree {
            parents: HashMap::from([(300, 200), (200, 100)]),
            names: HashMap::from([
                (100, "bash".to_string()),
                (200, "cargo".to_string()),
                (300, "my_cli_app".to_string()),
            ]),
        };

        let shell = find_shell_in_process_tree(&tree, 300);
        assert!(matches!(shell, Some(Shell::Bash)));
    }

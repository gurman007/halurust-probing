    pub fn push_gateway_config<T>(mut self, addr: T, interval: std::time::Duration) -> Self
    where
        T: AsRef<String>,
    {
        self.push_gateway_config = Some(PrometheusPushGatewayConfig {
            address: addr.as_ref().to_string(),
            push_interval: interval,
        });
        self
    }
    pub fn build_with_exporter(
        mut self,
    ) -> Result<
        (
            PrometheusRecorder,
            Pin<Box<dyn Future<Output = Result<(), HyperError>> + Send + 'static>>,
        ),
        InstallError,
    > {
        let address = self.listen_address;
        let push_gateway_config = self.push_gateway_config.clone();
        let allow_ips = self.allow_ips.take();
        let recorder = self.build();
        let handle = recorder.handle();

        if let Some(address) = &address {
            let server = Server::try_bind(&address)?;
            let exporter = async move {
                let make_svc = make_service_fn(move |socket: &AddrStream| {
                    let remote_addr = socket.remote_addr().ip();
                    let allowed = allow_ips
                        .as_ref()
                        .map(|subnets| subnets.iter().any(|subnet| subnet.contains(&remote_addr)))
                        // If no subnets specified, allow all IPs.
                        .unwrap_or(true);

                    let handle = handle.clone();

                    async move {
                        Ok::<_, HyperError>(service_fn(move |_| {
                            let handle = handle.clone();

                            async move {
                                if allowed {
                                    let output = handle.render();
                                    Ok::<_, HyperError>(Response::new(Body::from(output)))
                                } else {
                                    Ok::<_, HyperError>(
                                        Response::builder()
                                            .status(StatusCode::FORBIDDEN)
                                            .body(Body::empty())
                                            .expect("static response is valid"),
                                    )
                                }
                            }
                        }))
                    }
                });
                server.serve(make_svc).await
            };
            return Ok((recorder, Box::pin(exporter)));
        }

        #[cfg(feature = "push-gateway")]
        if let Some(push_gateway_config) = &push_gateway_config {
            let push_interval = push_gateway_config.push_interval;
            let push_address = push_gateway_config.address.to_string();
            let exporter = async move {
                let client = reqwest::Client::default();
                loop {
                    tokio::time::sleep(push_interval).await;
                    let output = handle.render();
                    let response = client.put(push_address.as_str()).body(output).send().await;
                    match response {
                        Ok(response) => {
                            if let Err(e) = response.error_for_status() {
                                tracing::error!(
                                    "error status code for pushing metrics to push gateway: {:?}",
                                    e
                                )
                            }
                        }
                        Err(e) => {
                            tracing::error!("error pushing metrics to push gateway: {:?}", e)
                        }
                    }
                }
            };
            return Ok((recorder, Box::pin(exporter)));
        }

        unimplemented!("must specify at least one of listen_address or push_gateway_config");
    }

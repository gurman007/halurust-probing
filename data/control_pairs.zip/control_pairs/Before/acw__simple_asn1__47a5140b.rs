    pub fn new(x: Vec<BigUint>) -> OID {
        OID(x)
    }
    fn encode_base127_zero() {
        let zero = BigUint::from(0 as u64);
        let encoded = encode_base127(&zero);
        let expected: Vec::<u8> = vec![0x0];
        assert_eq!(expected, encoded);
    }

    fn replace(
        &self,
        params: Option<&[Type]>,
        subs: Option<&Substitution>,
        type_local_subs: Option<&BTreeMap<Symbol, Type>>,
    ) -> Type {
        let replace_vec = |types: &[Type]| {
            types
                .iter()
                .map(|t| t.replace(params, subs, type_local_subs))
                .collect()
        };
        match self {
            Type::TypeParameter(i) => {
                if let Some(ps) = params {
                    ps[*i as usize].clone()
                } else {
                    self.clone()
                }
            }
            Type::Var(i) => {
                if let Some(s) = subs {
                    if let Some(t) = s.subs.get(i) {
                        // Recursively call replacement again here, in case the substitution s
                        // refers to type variables.
                        // TODO: a more efficient approach is to maintain that type assignments
                        // are always fully specialized w.r.t. to the substitution.
                        t.replace(params, subs, type_local_subs)
                    } else {
                        self.clone()
                    }
                } else {
                    self.clone()
                }
            }
            Type::TypeLocal(sym) => {
                if let Some(subs) = type_local_subs {
                    if let Some(t) = subs.get(sym) {
                        t.clone()
                    } else {
                        self.clone()
                    }
                } else {
                    self.clone()
                }
            }
            Type::Reference(is_mut, bt) => {
                Type::Reference(*is_mut, Box::new(bt.replace(params, subs, type_local_subs)))
            }
            Type::Struct(mid, sid, args) => Type::Struct(*mid, *sid, replace_vec(args)),
            Type::Fun(args, result) => Type::Fun(
                replace_vec(args),
                Box::new(result.replace(params, subs, type_local_subs)),
            ),
            Type::Tuple(args) => Type::Tuple(replace_vec(args)),
            Type::Vector(et) => Type::Vector(Box::new(et.replace(params, subs, type_local_subs))),
            Type::TypeDomain(et) => {
                Type::TypeDomain(Box::new(et.replace(params, subs, type_local_subs)))
            }
            Type::ResourceDomain(..) | Type::Primitive(..) | Type::Error => self.clone(),
        }
    }

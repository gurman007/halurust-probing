    pub fn push(&self, element: T) {
        let mut new = Box::into_raw(Box::new(QueueHead {
            element: Some(element),
            next: ptr::null_mut(),
        }));

        loop {
            unsafe {
                let in_queue = self.in_queue.load(Ordering::SeqCst);

                if !in_queue.is_null() && (*in_queue).element.is_none() {
                    drop(Box::from_raw(new));
                    return;
                }

                (*new).next = in_queue;

                if self
                    .in_queue
                    .compare_and_swap(in_queue, new, Ordering::SeqCst)
                    == in_queue
                {
                    return;
                }
            }
        }
    }
    pub fn pop(&mut self) -> Option<T> {
        if self.out_queue.is_null() {
            loop {
                let mut head = self.in_queue.load(Ordering::SeqCst);

                if head.is_null() {
                    break;
                }

                if self
                    .in_queue
                    .compare_and_swap(head, ptr::null_mut(), Ordering::SeqCst)
                    == head
                {
                    while !head.is_null() {
                        unsafe {
                            let next = (*head).next;
                            (*head).next = self.out_queue;
                            self.out_queue = head;
                            head = next;
                        }
                    }

                    break;
                }
            }
        }

        if self.out_queue.is_null() {
            None
        } else {
            unsafe {
                let head = Box::from_raw(self.out_queue);
                self.out_queue = head.next;
                Some(head.element.unwrap())
            }
        }
    }
            fn drop(&mut self) {
                self.dropped.store(true, Ordering::SeqCst);
            }
    fn test_disconnected() {
        struct MyStruct {
            dropped: Arc<AtomicBool>,
        }

        impl Drop for MyStruct {
            fn drop(&mut self) {
                self.dropped.store(true, Ordering::SeqCst);
            }
        }

        let dropped = Arc::new(AtomicBool::new(false));

        let (tx, rx) = Queue::unbounded();

        drop(rx);

        tx.push(MyStruct {
            dropped: dropped.clone(),
        });

        assert!(dropped.load(Ordering::SeqCst));
    }
    fn benchmark() {
        let num_items = 1_000_000;

        for n in [1, 2, 4, 8, 16, 32, 64, 128].iter() {
            for _ in 0..1 {
                run(num_items, *n);
            }

            let start = time::Instant::now();

            run(num_items, *n);

            let duration = start.elapsed();

            let ns_per = duration.as_nanos() / (num_items as u128 * *n as u128);

            println!(
                "producers={}, taken={}ms, ns_per={}",
                n,
                duration.as_millis(),
                ns_per
            );
        }
    }

pub struct Allocation<'marker, 't, T>
where
    T: 't + ?Sized,
{
    /// Allocation data.
    data: &'t mut T,
    /// Dummy reference for ensuring the allocation does not outlive the
    /// `Marker` from which it was allocated.
    _phantom: PhantomData<&'marker ()>,
}
    fn deref(&self) -> &T {
        self.data
    }
    fn deref_mut(&mut self) -> &mut T {
        self.data
    }
    pub fn allocate<'marker, 't, T>(
        &'marker self,
        value: T,
    ) -> Result<Allocation<'marker, 't, T>, Error> {
        Marker::allocate(self, value)
    }
    pub fn allocate_default<'marker, 't, T: Default>(
        &'marker self,
    ) -> Result<Allocation<'marker, 't, T>, Error> {
        Marker::allocate_default(self)
    }
    pub unsafe fn allocate_uninitialized<'marker, 't, T>(
        &'marker self,
    ) -> Result<Allocation<'marker, 't, T>, Error> {
        Marker::allocate_uninitialized(self)
    }
    pub fn allocate_array<'marker, 't, T: Clone>(
        &'marker self,
        len: usize,
        value: T,
    ) -> Result<Allocation<'marker, 't, [T]>, Error> {
        Marker::allocate_array(self, len, value)
    }
    pub fn allocate_array_default<'marker, 't, T: Default>(
        &'marker self,
        len: usize,
    ) -> Result<Allocation<'marker, 't, [T]>, Error> {
        Marker::allocate_array_default(self, len)
    }
    pub fn allocate_array_with<'marker, 't, T, F: FnMut(usize) -> T>(
        &'marker self,
        len: usize,
        func: F,
    ) -> Result<Allocation<'marker, 't, [T]>, Error> {
        Marker::allocate_array_with(self, len, func)
    }
    pub unsafe fn allocate_array_uninitialized<'marker, 't, T>(
        &'marker self,
        len: usize,
    ) -> Result<Allocation<'marker, 't, [T]>, Error> {
        Marker::allocate_array_uninitialized(self, len)
    }
    pub fn concat<'marker, IntoIteratorT, IteratorT, StrT>(
        &'marker self,
        strings: IntoIteratorT,
    ) -> Result<Allocation<'marker, 'static, str>, Error>
    where
        IntoIteratorT: IntoIterator<Item = StrT, IntoIter = IteratorT>,
        IteratorT: Iterator<Item = StrT> + Clone,
        StrT: AsRef<str>,
    {
        Marker::concat(self, strings)
    }

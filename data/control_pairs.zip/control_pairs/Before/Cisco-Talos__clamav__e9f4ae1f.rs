pub unsafe extern "C" fn glob_rm(glob_str: *const c_char, err: *mut *mut FFIError) -> bool {
    let glob_str = validate_str_param!(glob_str);

    for entry in glob(glob_str).expect("Failed to read glob pattern") {
        match entry {
            Ok(path) => {
                debug!("Deleting: {path:?}");
                if let Err(e) = std::fs::remove_file(&path) {
                    warn!("Failed to delete file: {path:?}");
                    return ffi_error!(err = err, Error::IoError(e));
                }
            }
            Err(e) => {
                return ffi_error!(err = err, Error::GlobError(e));
            }
        }
    }

    true
}
pub unsafe extern "C" fn mkdir_w32(path: *const c_char, err: *mut *mut FFIError) -> bool {
    let path = validate_str_param!(path);

    if let Err(e) = std::fs::create_dir_all(&path) {
        warn!("Failed to create directory: {path:?}");
        return ffi_error!(err = err, Error::IoError(e));
    }

    true
}

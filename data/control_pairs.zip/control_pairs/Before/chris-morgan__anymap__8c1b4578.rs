    fn write(&mut self, bytes: &[u8]) {
        // This expects to receive one and exactly one 64-bit value
        debug_assert!(bytes.len() == 8);
        unsafe {
            std::ptr::copy_nonoverlapping_memory(&mut self.value,
                                                 std::mem::transmute(&bytes[0]),
                                                 1)
        }
    }
    pub fn find<'a, T: 'static>(&'a self) -> Option<&'a T> {
        self.data.find(&TypeId::of::<T>()).and_then(|any| any.as_ref::<T>())
    }
    pub fn find_mut<'a, T: 'static>(&'a mut self) -> Option<&'a mut T> {
        self.data.find_mut(&TypeId::of::<T>()).and_then(|any| any.as_mut::<T>())
    }

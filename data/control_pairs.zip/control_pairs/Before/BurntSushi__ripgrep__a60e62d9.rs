    pub(crate) fn sort<'a, I>(
        &self,
        haystacks: I,
    ) -> Box<dyn Iterator<Item = Haystack> + 'a>
    where
        I: Iterator<Item = Haystack> + 'a,
    {
        use std::{cmp::Ordering, fs::Metadata, io, time::SystemTime};

        fn attach_timestamps(
            haystacks: impl Iterator<Item = Haystack>,
            get: impl Fn(&Metadata) -> io::Result<SystemTime>,
        ) -> impl Iterator<Item = (Haystack, Option<SystemTime>)> {
            haystacks.map(move |s| {
                let time = s.path().metadata().and_then(|m| get(&m)).ok();
                (s, time)
            })
        }

        let Some(ref sort) = self.sort else { return Box::new(haystacks) };
        let mut with_timestamps: Vec<_> = match sort.kind {
            SortModeKind::Path if !sort.reverse => return Box::new(haystacks),
            SortModeKind::Path => {
                let mut haystacks = haystacks.collect::<Vec<Haystack>>();
                haystacks.sort_by(|ref h1, ref h2| {
                    h1.path().cmp(h2.path()).reverse()
                });
                return Box::new(haystacks.into_iter());
            }
            SortModeKind::LastModified => {
                attach_timestamps(haystacks, |md| md.modified()).collect()
            }
            SortModeKind::LastAccessed => {
                attach_timestamps(haystacks, |md| md.accessed()).collect()
            }
            SortModeKind::Created => {
                attach_timestamps(haystacks, |md| md.created()).collect()
            }
        };
        with_timestamps.sort_by(|(_, ref t1), (_, ref t2)| {
            let ordering = match (*t1, *t2) {
                // Both have metadata, do the obvious thing.
                (Some(t1), Some(t2)) => t1.cmp(&t2),
                // Things that error should appear later (when ascending).
                (Some(_), None) => Ordering::Less,
                // Things that error should appear later (when ascending).
                (None, Some(_)) => Ordering::Greater,
                // When both error, we can't distinguish, so treat as equal.
                (None, None) => Ordering::Equal,
            };
            if sort.reverse {
                ordering.reverse()
            } else {
                ordering
            }
        });
        Box::new(with_timestamps.into_iter().map(|(s, _)| s))
    }
fn types(low: &LowArgs) -> anyhow::Result<ignore::types::Types> {
    let mut builder = ignore::types::TypesBuilder::new();
    builder.add_defaults();
    for tychange in low.type_changes.iter() {
        match tychange {
            TypeChange::Clear { ref name } => {
                builder.clear(name);
            }
            TypeChange::Add { ref def } => {
                builder.add_def(def)?;
            }
            TypeChange::Select { ref name } => {
                builder.select(name);
            }
            TypeChange::Negate { ref name } => {
                builder.negate(name);
            }
        }
    }
    Ok(builder.build()?)
}
    fn validate_scheme(&self) -> Result<(), HyperlinkFormatError> {
        let err_invalid_scheme = HyperlinkFormatError {
            kind: HyperlinkFormatErrorKind::InvalidScheme,
        };
        let Some(Part::Text(ref part)) = self.parts.first() else {
            return Err(err_invalid_scheme);
        };
        let Some(colon) = part.find_byte(b':') else {
            return Err(err_invalid_scheme);
        };
        let scheme = &part[..colon];
        if scheme.is_empty() {
            return Err(err_invalid_scheme);
        }
        let is_valid_scheme_char = |byte| match byte {
            b'0'..=b'9' | b'A'..=b'Z' | b'a'..=b'z' | b'+' | b'-' | b'.' => {
                true
            }
            _ => false,
        };
        if !scheme.iter().all(|&b| is_valid_scheme_char(b)) {
            return Err(err_invalid_scheme);
        }
        Ok(())
    }
    fn interpolate_to(
        &self,
        env: &HyperlinkEnvironment,
        values: &Values,
        dest: &mut Vec<u8>,
    ) {
        match self {
            Part::Text(ref text) => dest.extend_from_slice(text),
            Part::Host => dest.extend_from_slice(
                env.host.as_ref().map(|s| s.as_bytes()).unwrap_or(b""),
            ),
            Part::WSLPrefix => dest.extend_from_slice(
                env.wsl_prefix.as_ref().map(|s| s.as_bytes()).unwrap_or(b""),
            ),
            Part::Path => dest.extend_from_slice(&values.path.0),
            Part::Line => {
                let line = DecimalFormatter::new(values.line.unwrap_or(1));
                dest.extend_from_slice(line.as_bytes());
            }
            Part::Column => {
                let column = DecimalFormatter::new(values.column.unwrap_or(1));
                dest.extend_from_slice(column.as_bytes());
            }
        }
    }
pub(crate) fn check(expr: &Hir, byte: u8) -> Result<(), Error> {
    assert!(byte.is_ascii(), "ban byte must be ASCII");
    let ch = char::from(byte);
    let invalid = || Err(Error::new(ErrorKind::Banned(byte)));
    match expr.kind() {
        HirKind::Empty => {}
        HirKind::Literal(hir::Literal(ref lit)) => {
            if lit.iter().find(|&&b| b == byte).is_some() {
                return invalid();
            }
        }
        HirKind::Class(hir::Class::Unicode(ref cls)) => {
            if cls.ranges().iter().map(|r| r.len()).sum::<usize>() == 1 {
                let contains =
                    |r: &&ClassUnicodeRange| r.start() <= ch && ch <= r.end();
                if cls.ranges().iter().find(contains).is_some() {
                    return invalid();
                }
            }
        }
        HirKind::Class(hir::Class::Bytes(ref cls)) => {
            if cls.ranges().iter().map(|r| r.len()).sum::<usize>() == 1 {
                let contains = |r: &&ClassBytesRange| {
                    r.start() <= byte && byte <= r.end()
                };
                if cls.ranges().iter().find(contains).is_some() {
                    return invalid();
                }
            }
        }
        HirKind::Look(_) => {}
        HirKind::Repetition(ref x) => check(&x.sub, byte)?,
        HirKind::Capture(ref x) => check(&x.sub, byte)?,
        HirKind::Concat(ref xs) => {
            for x in xs.iter() {
                check(x, byte)?;
            }
        }
        HirKind::Alternation(ref xs) => {
            for x in xs.iter() {
                check(x, byte)?;
            }
        }
    };
    Ok(())
}

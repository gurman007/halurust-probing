fn get_command_output(expand_command: String) -> io::Result<CommandOutput> {
    let split_command = shell_words::split(&expand_command)
        .map_err(|e| io::Error::other(format!("Failed to parse command: {e}")))?;
    let output = Command::new(&split_command[0])
        .args(&split_command[1..])
        .env("LANG", "C") // Set locale to C to avoid issues with rules that depend on locale
        .env("LC_ALL", "C")
        .output()?;
    Ok(CommandOutput::from(output))
}
fn choose_fixed_command(mut fixed_commands: Vec<String>) -> String {
    if fixed_commands.is_empty() {
        eprintln!(
            "{}: {}",
            "No fixed commands found".yellow(),
            "Exiting...".red()
        );
        std::process::exit(1);
    }

    let mut current_command = fixed_commands.first().unwrap();
    let mut current_index = 0;

    eprintln!();
    let _raw_mode_guard = RawModeGuard::new();
    let mut err = io::stderr();
    err.write_all(
        format!(
            "{} [{}/{}/{}/{}]",
            current_command,
            "enter".green(),
            "↑".cyan(),
            "↓".cyan(),
            "Ctrl+C".red()
        )
        .as_bytes(),
    )
    .expect("Failed to write to stderr");
    loop {
        match read() {
            Ok(event) => {
                if let Event::Key(KeyEvent {
                    code, modifiers, ..
                }) = event
                {
                    match (code, modifiers) {
                        (KeyCode::Up, _) => {
                            if fixed_commands.len() > 1 {
                                if current_index > 0 {
                                    current_index -= 1;
                                } else {
                                    current_index = fixed_commands.len() - 1;
                                }
                                current_command = fixed_commands.get(current_index).unwrap();
                                err.write_all(
                                    format!(
                                        "{} [{}/{}/{}/{}]",
                                        current_command,
                                        "enter".green(),
                                        "↑".cyan(),
                                        "↓".cyan(),
                                        "Ctrl+C".red()
                                    )
                                    .as_bytes(),
                                )
                                .expect("Failed to write to stderr");
                            }
                        }
                        (KeyCode::Down, _) => {
                            if fixed_commands.len() > 1 {
                                if current_index < fixed_commands.len() - 1 {
                                    current_index += 1;
                                } else {
                                    current_index = 0;
                                }
                                current_command = fixed_commands.get(current_index).unwrap();
                                err.write_all(
                                    format!(
                                        "{} [{}/{}/{}/{}]",
                                        current_command,
                                        "enter".green(),
                                        "↑".cyan(),
                                        "↓".cyan(),
                                        "Ctrl+C".red()
                                    )
                                    .as_bytes(),
                                )
                                .expect("Failed to write to stderr");
                            }
                        }
                        (KeyCode::Enter, _) => {
                            drop(_raw_mode_guard);
                            eprintln!();
                            eprintln!("{}: {}", "Selected command: ".green(), &current_command);
                            return fixed_commands.remove(current_index);
                        }
                        (KeyCode::Char('c'), KeyModifiers::CONTROL) => {
                            drop(_raw_mode_guard);
                            eprintln!();
                            eprintln!("{}: {}", "Exiting...".yellow(), "User interrupted".red());
                            std::process::exit(1);
                        }
                        _ => {}
                    }
                }
            }
            Err(_) => {
                eprintln!("{}: {}", "Error reading input".red(), "Exiting...".yellow());
                drop(_raw_mode_guard);
                std::process::exit(1);
            }
        }
    }
}

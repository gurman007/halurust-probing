    pub fn new<P: AsRef<Path>>(path: P, options: Options) -> Self {
        use crate::yansi::Paint;

        let path = path.as_ref();
        if !path.is_dir() {
            let path = path.display();
            error!("FileServer path '{}' is not a directory.", Paint::white(path));
            warn_!("Aborting early to prevent inevitable handler failure.");
            panic!("bad FileServer path: refusing to continue");
        }

        FileServer { root: path.into(), options, rank: Self::DEFAULT_RANK }
    }
    fn into(self) -> Vec<Route> {
        let source = figment::Source::File(self.root.clone());
        let mut route = Route::ranked(self.rank, Method::Get, "/<path..>", self);
        route.name = Some(format!("FileServer: {}/", source).into());
        vec![route]
    }
    async fn handle<'r>(&self, req: &'r Request<'_>, data: Data<'r>) -> Outcome<'r> {
        use crate::http::uri::fmt::Path;

        // Get the segments as a `PathBuf`, allowing dotfiles requested.
        let options = self.options;
        let allow_dotfiles = options.contains(Options::DotFiles);
        let path = req.segments::<Segments<'_, Path>>(0..).ok()
            .and_then(|segments| segments.to_path_buf(allow_dotfiles).ok())
            .map(|path| self.root.join(path));

        match path {
            Some(p) if p.is_dir() => {
                // Normalize '/a/b/foo' to '/a/b/foo/'.
                if options.contains(Options::NormalizeDirs) && !req.uri().path().ends_with('/') {
                    let normal = req.uri().map_path(|p| format!("{}/", p))
                        .expect("adding a trailing slash to a known good path => valid path")
                        .into_owned();

                    return Outcome::from_or_forward(req, data, Redirect::permanent(normal));
                }

                if !options.contains(Options::Index) {
                    return Outcome::forward(data);
                }

                let index = NamedFile::open(p.join("index.html")).await.ok();
                Outcome::from_or_forward(req, data, index)
            },
            Some(p) => Outcome::from_or_forward(req, data, NamedFile::open(p).await.ok()),
            None => Outcome::forward(data),
        }
    }

pub struct Slab<T, I: Index> {
    // Chunk of memory
    entries: Vec<Slot<T>>,

    // Number of Filled elements currently in the slab
    len: usize,

    // The index offset
    offset: usize,

    // Offset of the next available slot in the slab. Set to the slab's
    // capacity when the slab is full.
    next: usize,

    _marker: PhantomData<I>,
}
        fn from_usize(i: usize) -> MyIndex {
            MyIndex(i)
        }
        fn as_usize(&self) -> usize {
            let MyIndex(inner) = *self;
            inner
        }
    pub fn new(capacity: usize) -> Slab<T, I> {
        Slab::new_starting_at(I::from_usize(0), capacity)
    }
    pub fn new_starting_at(offset: I, capacity: usize) -> Slab<T, I> {
        assert!(capacity <= usize::MAX, "capacity too large");
        let entries = (1..capacity + 1)
            .map(Slot::Empty)
            .collect::<Vec<_>>();

        Slab {
            entries: entries,
            next: 0,
            len: 0,
            offset: offset.as_usize(),
            _marker: PhantomData,
        }
    }
    pub fn retain<F>(&mut self, mut fun: F)
        where F: FnMut(&T) -> bool
    {
        for i in 0..self.len {
            let idx = I::from_usize(i + self.offset);

            let _ = self.replace_with(idx, |x| {
                if fun(&x) {
                    Some(x)
                } else {
                    None
                }
            });
        }
    }
    fn insert_at(&mut self, idx: usize, value: T) -> I {
        let idx = idx - self.offset;

        self.next = match self.entries[idx] {
            Slot::Empty(next) => next,
            Slot::Filled(_) => panic!("Tried to insert into filled index"),
        };

        self.entries[idx] = Slot::Filled(value);
        self.len += 1;

        I::from_usize(idx + self.offset)
    }
    fn local_index(&self, idx: I) -> Option<usize> {
        let idx = idx.as_usize();

        if idx < self.offset {
            return None;
        }

        let idx = idx - self.offset;

        if idx >= self.entries.capacity() {
            return None;
        }

        Some(idx)
    }
pub enum Entry<'slab, I: Index + 'slab, T: 'slab> {
    Vacant(VacantEntry<'slab, I, T>),
    Occupied(OccupiedEntry<'slab, I, T>),
}
pub struct VacantEntry<'slab, I: Index + 'slab, T: 'slab> {
    slab: &'slab mut Slab<T, I>,
    idx: usize,
}
    pub fn index(&self) -> I {
        I::from_usize(self.idx)
    }
pub struct OccupiedEntry<'slab, I: Index + 'slab, T: 'slab> {
    slab: &'slab mut Slab<T, I>,
    idx: usize,
}
pub struct SlabIter<'a, T: 'a, I: Index + 'a> {
    slab: &'a Slab<T, I>,
    cur_idx: usize,
    yielded: usize,
}
pub struct SlabMutIter<'a, T: 'a, I: Index + 'a> {
    iter: SlabIter<'a, T, I>,
}

fn p384_scalar_inv_to_mont(a: Scalar<R>, cpu: cpu::Features) -> Scalar<R> {
    // Calculate the modular inverse of scalar |a| using Fermat's Little
    // Theorem:
    //
    //    a**-1 (mod n) == a**(n - 2) (mod n)
    //
    // The exponent (n - 2) is:
    //
    //    0xffffffffffffffffffffffffffffffffffffffffffffffffc7634d81f4372ddf\
    //      581a0db248b0a77aecec196accc52971

    fn mul(a: &Scalar<R>, b: &Scalar<R>, _cpu: cpu::Features) -> Scalar<R> {
        binary_op(p384_scalar_mul_mont, a, b)
    }

    fn sqr(a: &Scalar<R>, _cpu: cpu::Features) -> Scalar<R> {
        binary_op(p384_scalar_mul_mont, a, a)
    }

    fn sqr_mut(a: &mut Scalar<R>, _cpu: cpu::Features) {
        unary_op_from_binary_op_assign(p384_scalar_mul_mont, a);
    }

    // Returns (`a` squared `squarings` times) * `b`.
    fn sqr_mul(
        a: &Scalar<R>,
        squarings: LeakyWord,
        b: &Scalar<R>,
        cpu: cpu::Features,
    ) -> Scalar<R> {
        debug_assert!(squarings >= 1);
        let mut tmp = sqr(a, cpu);
        for _ in 1..squarings {
            sqr_mut(&mut tmp, cpu);
        }
        mul(&tmp, b, cpu)
    }

    // Sets `acc` = (`acc` squared `squarings` times) * `b`.
    fn sqr_mul_acc(acc: &mut Scalar<R>, squarings: LeakyWord, b: &Scalar<R>, cpu: cpu::Features) {
        debug_assert!(squarings >= 1);
        for _ in 0..squarings {
            sqr_mut(acc, cpu);
        }
        let _: cpu::Features = cpu;
        binary_op_assign(p384_scalar_mul_mont, acc, b)
    }

    // Indexes into `d`.
    const B_1: usize = 0;
    const B_11: usize = 1;
    const B_101: usize = 2;
    const B_111: usize = 3;
    const B_1001: usize = 4;
    const B_1011: usize = 5;
    const B_1101: usize = 6;
    const B_1111: usize = 7;
    const DIGIT_COUNT: usize = 8;

    // Calculate the window values.
    let mut d = [Scalar::zero(); DIGIT_COUNT];
    d[B_1] = a;
    let b_10 = &sqr(&d[B_1], cpu); // 2
    d[B_11] = mul(&d[B_1], b_10, cpu); // 3
    d[B_101] = mul(&d[B_11], b_10, cpu); // 5
    d[B_111] = mul(&d[B_101], b_10, cpu); // 7
    d[B_1001] = mul(&d[B_111], b_10, cpu); // 9
    d[B_1011] = mul(&d[B_1001], b_10, cpu); // 11
    d[B_1101] = mul(&d[B_1011], b_10, cpu); // 13
    d[B_1111] = mul(&d[B_1101], b_10, cpu); // 15

    // ffffffffffffffffffffffffffffffffffffffffffffffff
    let ff = sqr_mul(&d[B_1111], 0 + 4, &d[B_1111], cpu);
    let ffff = sqr_mul(&ff, 0 + 8, &ff, cpu);
    let ffffffff = sqr_mul(&ffff, 0 + 16, &ffff, cpu);
    let ffffffffffffffff = sqr_mul(&ffffffff, 0 + 32, &ffffffff, cpu);
    let ffffffffffffffffffffffff = sqr_mul(&ffffffffffffffff, 0 + 32, &ffffffff, cpu);
    let mut acc = sqr_mul(
        &ffffffffffffffffffffffff,
        0 + 96,
        &ffffffffffffffffffffffff,
        cpu,
    );

    // The rest of the exponent, in binary, is:
    //
    //    1100011101100011010011011000000111110100001101110010110111011111
    //    0101100000011010000011011011001001001000101100001010011101111010
    //    1110110011101100000110010110101011001100110001010010100101110001

    #[allow(clippy::cast_possible_truncation)]
    static REMAINING_WINDOWS: [(u8, u8); 39] = [
        (2, B_11 as u8),
        (3 + 3, B_111 as u8),
        (1 + 2, B_11 as u8),
        (3 + 2, B_11 as u8),
        (1 + 4, B_1001 as u8),
        (4, B_1011 as u8),
        (6 + 4, B_1111 as u8),
        (3, B_101 as u8),
        (4 + 1, B_1 as u8),
        (4, B_1011 as u8),
        (4, B_1001 as u8),
        (1 + 4, B_1101 as u8),
        (4, B_1101 as u8),
        (4, B_1111 as u8),
        (1 + 4, B_1011 as u8),
        (6 + 4, B_1101 as u8),
        (5 + 4, B_1101 as u8),
        (4, B_1011 as u8),
        (2 + 4, B_1001 as u8),
        (2 + 1, B_1 as u8),
        (3 + 4, B_1011 as u8),
        (4 + 3, B_101 as u8),
        (2 + 3, B_111 as u8),
        (1 + 4, B_1111 as u8),
        (1 + 4, B_1011 as u8),
        (4, B_1011 as u8),
        (2 + 3, B_111 as u8),
        (1 + 2, B_11 as u8),
        (5 + 2, B_11 as u8),
        (2 + 4, B_1011 as u8),
        (1 + 3, B_101 as u8),
        (1 + 2, B_11 as u8),
        (2 + 2, B_11 as u8),
        (2 + 2, B_11 as u8),
        (3 + 3, B_101 as u8),
        (2 + 3, B_101 as u8),
        (2 + 3, B_101 as u8),
        (2, B_11 as u8),
        (3 + 1, B_1 as u8),
    ];

    for &(squarings, digit) in &REMAINING_WINDOWS[..] {
        sqr_mul_acc(
            &mut acc,
            LeakyWord::from(squarings),
            &d[usize::from(digit)],
            cpu,
        );
    }

    acc
}

    pub fn accept(&mut self) -> impl Future<Output = Option<<Self as Stream>::Item>> + '_ {
        self.next()
    }
    pub fn replace_acceptor(&mut self, acceptor: T) {
        self.tls = acceptor;
    }

    fn test_base_2b<OutLen: ArraySize, B: Unsigned>(x: &[u8]) {
        if x.len() < (OutLen::USIZE * B::USIZE + 7) / 8 {
            return; // TODO: enforce this at the prop level
        }

        let a = base_2b::<OutLen, B>(x);
        let mut b = BigUint::from_bytes_be(&x[..(OutLen::USIZE * B::USIZE + 7) / 8]);

        if (B::USIZE * OutLen::USIZE) % 8 != 0 {
            // Clear lower bits of b
            b >>= 8 - ((B::USIZE * OutLen::USIZE) % 8);
        }

        let c: BigUint = a.iter().fold(0u8.into(), |acc, x| (acc << B::U8) + x);

        assert_eq!(b, c);
    }

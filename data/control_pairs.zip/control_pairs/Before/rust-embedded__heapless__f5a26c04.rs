    pub fn write(&mut self, t: T) {
        self.data[self.write_at] = t;
        self.write_at = (self.write_at + 1) % self.len();
    }
    pub fn recent(&self) -> &T {
        &self.data[(self.write_at + self.len() - 1) % self.len()]
    }

	pub fn new(key: &WebSocketKey) -> WebSocketAccept {
		let serialized = key.serialize();
		let mut concat_key = String::with_capacity(serialized.len() + 36);
		concat_key.push_str(&serialized[..]);
		concat_key.push_str(MAGIC_GUID);
		let mut sha1 = Sha1::new();
		sha1.update(concat_key.as_bytes());
		let bytes = sha1.digest().bytes();
		WebSocketAccept(bytes)
	}

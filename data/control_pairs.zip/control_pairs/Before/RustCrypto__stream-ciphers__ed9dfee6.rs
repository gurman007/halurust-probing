pub(crate) struct Cipher {
    /// Secret key
    key: [u32; KEY_WORDS],

    /// Initialization vector
    iv: [u32; IV_WORDS],

    /// Offset of the initial counter in the keystream. This is derived from
    /// the extra 4 bytes in the 96-byte nonce RFC 7539 version (or is always
    /// 0 in the legacy version)
    counter_offset: u64,
}

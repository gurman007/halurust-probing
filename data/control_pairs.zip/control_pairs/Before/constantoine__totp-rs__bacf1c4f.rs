    pub fn get_qr(&self, label: &str, issuer: &str) -> Result<String, Box<dyn std::error::Error>> {
        let url = self.get_url(label, issuer);
        let code = QrCode::new(&url)?;
        let mut vec = Vec::new();
        let encoder = image::png::PngEncoder::new(&mut vec);
        encoder.encode(
            code.render::<Luma<u8>>().build().as_ref(),
            ((code.width() + 8) * 8) as u32,
            ((code.width() + 8) * 8) as u32,
            image::ColorType::L8,
        )?;
        Ok(base64::encode(vec))
    }
    fn generates_qr() {
        use sha1::{Digest, Sha1};

        let totp = TOTP::new(Algorithm::SHA1, 6, 1, 1, "TestSecret");
        let qr = totp.get_qr("test_url", "totp-rs").unwrap();

        // Create hash from image
        let hash_digest = Sha1::digest(qr.as_bytes());
        assert_eq!(
            format!("{:x}", hash_digest).as_str(),
            "3abc0127e7a2b1013fb25c97ef14422c1fe9e878"
        );
    }

            fn siv(&self, components: &[&[u8]], payload: &[u8]) -> [u8; Self::BLOCK_LEN] {
                // 2.4.  S2V
                // https://tools.ietf.org/html/rfc5297#section-2.4
                if components.is_empty() && payload.is_empty() {
                    // indicates a string that is 127 zero bits concatenated with a
                    // single one bit, that is 0^127 || 1^1.
                    let one = 1u128.to_be_bytes();
                    return self.cmac(&one, None);
                }

                let mut d = self.cmac(&Self::BLOCK_ZERO, None);
                for aad in components.iter() {
                    d = dbl(u128::from_be_bytes(d)).to_be_bytes();
                    let d2 = self.cmac(aad, None);

                    xor_si128_inplace(&mut d, &d2);
                }

                let plen = payload.len();
                if plen < Self::BLOCK_LEN {
                    // T = dbl(D) xor pad(Sn)
                    let mut t = dbl(u128::from_be_bytes(d)).to_be_bytes();

                    for i in 0..plen {
                        t[i] ^= payload[i];
                    }
                    t[plen] ^= 0b1000_0000;

                    return self.cmac(&t, None);
                } else if plen == Self::BLOCK_LEN {
                    let mut block = [0u8; Self::BLOCK_LEN];
                    block.copy_from_slice(payload);

                    xor_si128_inplace(&mut block, &d);
                    return self.cmac(&block, None);
                } else if plen > Self::BLOCK_LEN {
                    let n = plen - Self::BLOCK_LEN;
                    
                    let m1 = &payload[..n];
                    let mut m2 = [0u8; Self::BLOCK_LEN];
                    m2.copy_from_slice(&payload[n..]);

                    xor_si128_inplace(&mut m2, &d);
                    return self.cmac(&m1, Some(&m2));
                } else {
                    unreachable!()
                }
            }
            pub fn encrypt_slice(&self, components: &[&[u8]], aead_pkt: &mut [u8]) {
                debug_assert!(aead_pkt.len() >= Self::TAG_LEN);

                let (tag_out, plaintext_and_ciphertext) = aead_pkt.split_at_mut(Self::TAG_LEN);

                self.encrypt_slice_detached(components, plaintext_and_ciphertext, tag_out)
            }
            pub fn decrypt_slice(&self, components: &[&[u8]], aead_pkt: &mut [u8]) -> bool {
                debug_assert!(aead_pkt.len() >= Self::TAG_LEN);

                let (tag_in, ciphertext_and_plaintext) = aead_pkt.split_at_mut(Self::TAG_LEN);

                self.decrypt_slice_detached(components, ciphertext_and_plaintext, &tag_in)
            }
            pub fn encrypt_slice_detached(&self, components: &[&[u8]], plaintext_and_ciphertext: &mut [u8], tag_out: &mut [u8]) {
                let plen = plaintext_and_ciphertext.len();
                let tlen = tag_out.len();

                debug_assert!(plen <= Self::P_MAX);
                debug_assert!(tlen == Self::TAG_LEN);

                assert!(components.len() < Self::COMPONENTS_MAX);

                // V = S2V(K1, AD1, ..., ADn, P)
                let v = self.siv(components, &plaintext_and_ciphertext);
                // Q = V bitand (1^64 || 0^1 || 1^31 || 0^1 || 1^31)
                let mut q = v.clone();
                and_si128_inplace(&mut q, &Self::V1);

                // CTR Counter
                let mut counter = u128::from_be_bytes(q);

                let n = plen / Self::BLOCK_LEN;
                for i in 0..n {
                    let chunk = &mut plaintext_and_ciphertext[i * Self::BLOCK_LEN..i * Self::BLOCK_LEN + Self::BLOCK_LEN];

                    let mut keystream_block = counter.to_be_bytes();
                    self.cipher.encrypt(&mut keystream_block);

                    xor_si128_inplace(chunk, &keystream_block);

                    counter = counter.wrapping_add(1);
                }

                if plen % Self::BLOCK_LEN != 0 {
                    let rem = &mut plaintext_and_ciphertext[n * Self::BLOCK_LEN..];
                    let rlen = rem.len();

                    let mut keystream_block = counter.to_be_bytes();
                    self.cipher.encrypt(&mut keystream_block);

                    for i in 0..rlen {
                        rem[i] ^= keystream_block[i];
                    }

                    // counter = counter.wrapping_add(1);
                }
                
                tag_out.copy_from_slice(&v[..Self::TAG_LEN]);
            }
            pub fn decrypt_slice_detached(&self, components: &[&[u8]], ciphertext_and_plaintext: &mut [u8], tag_in: &[u8]) -> bool {
                let clen = ciphertext_and_plaintext.len();
                let tlen = tag_in.len();

                debug_assert!(clen <= Self::P_MAX);
                debug_assert!(tlen == Self::TAG_LEN);

                assert!(components.len() < Self::COMPONENTS_MAX);

                let mut q = [0u8; Self::BLOCK_LEN];
                q[..Self::TAG_LEN].copy_from_slice(tag_in);
                and_si128_inplace(&mut q, &Self::V1);

                // CTR Counter
                let mut counter = u128::from_be_bytes(q);

                let n = clen / Self::BLOCK_LEN;
                for i in 0..n {
                    let chunk = &mut ciphertext_and_plaintext[i * Self::BLOCK_LEN..i * Self::BLOCK_LEN + Self::BLOCK_LEN];

                    let mut keystream_block = counter.to_be_bytes();
                    self.cipher.encrypt(&mut keystream_block);

                    xor_si128_inplace(chunk, &keystream_block);

                    counter = counter.wrapping_add(1);
                }

                if clen % Self::BLOCK_LEN != 0 {
                    let rem = &mut ciphertext_and_plaintext[n * Self::BLOCK_LEN..];
                    let rlen = rem.len();

                    let mut keystream_block = counter.to_be_bytes();
                    self.cipher.encrypt(&mut keystream_block);

                    for i in 0..rlen {
                        rem[i] ^= keystream_block[i];
                    }

                    // counter = counter.wrapping_add(1);
                }

                // T = S2V(K1, AD1, ..., ADn, P)
                let tag = self.siv(components, &ciphertext_and_plaintext);
                
                // Verify
                constant_time_eq(tag_in, &tag[..Self::TAG_LEN])
            }

fn read_sheet_data(xml: &mut XmlReader<BufReader<ZipFile>>,
                   strings: &[String],
                   cells: &mut Vec<Cell>)
                   -> Result<()> {
    while let Some(res_event) = xml.next() {
        match res_event {
            Err(e) => return Err(e.into()),
            Ok(Event::Start(ref c_element)) if c_element.name() == b"c" => {
                let pos = match c_element.attributes()
                    .filter_map(|a| match a {
                        Err(e) => Some(Err(e.into())),
                        Ok((b"r", v)) => Some(get_row_column(v)),
                        _ => None,
                    })
                    .next() {
                    Some(v) => v?,
                    None => return Err("Cell without a 'r' reference tag".into()),
                };
                loop {
                    match xml.next() {
                        Some(Err(e)) => return Err(e.into()),
                        Some(Ok(Event::Start(ref e))) => {
                            match e.name() {
                                b"v" => {
                                    // value
                                    let v = xml.read_text_unescaped(b"v")?;
                                    let value = match c_element.attributes()
                                        .filter_map(|a| a.ok())
                                        .find(|&(k, _)| k == b"t") {
                                        Some((_, b"s")) => {
                                            // shared string
                                            let idx: usize = v.parse()?;
                                            DataType::String(strings[idx].clone())
                                        }
                                        Some((_, b"str")) => {
                                            // regular string
                                            DataType::String(v)
                                        }
                                        Some((_, b"b")) => {
                                            // boolean
                                            DataType::Bool(v != "0")
                                        }
                                        Some((_, b"e")) => {
                                            // error
                                            DataType::Error(v.parse()?)
                                        }
                                        _ => v.parse().map(DataType::Float)?,
                                    };
                                    cells.push(Cell::new(pos, value));
                                    break;
                                }
                                b"f" => (), // formula, ignore
                                _name => return Err("not v or f node".into()),
                            }
                        }
                        Some(Ok(Event::End(ref e))) if e.name() == b"c" => break,
                        None => return Err("End of xml".into()),
                        _ => (),
                    }
                }
            }
            Ok(Event::End(ref e)) if e.name() == b"sheetData" => return Ok(()),
            _ => (),
        }
    }
    Err("Could not find </sheetData>".into())
}

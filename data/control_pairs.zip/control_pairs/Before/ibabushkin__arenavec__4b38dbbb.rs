impl<T, H: AllocHandle > SliceVec<T, H> {
    /// Create a new empty vector of capacity `0` using the given handle.
    pub fn new(handle: H) -> Self {
        Self::with_capacity(handle, 0)
    }

    /// Create a new vector of given capacity using the given handle.
    pub fn with_capacity(handle: H, capacity: usize) -> Self {
        SliceVec {
            slice: unsafe { Slice::new_empty(handle, capacity) },
            capacity,
        }
    }

    /// Return the current capacity of the vector.
    pub fn capacity(&self) -> usize {
        self.capacity
    }

    /// Reseve enough space in the vector for at least `size` additional elements.
    pub fn reserve(&mut self, additional: usize) {
        let ptr = self.slice.ptr;
        let size = self.slice.len + additional;

        if self.capacity >= size {
            return;
        }

        let mut new_capacity = if self.capacity > 0 { self.capacity } else { 4 };

        while new_capacity < size {
            new_capacity *= 2;
        }

        let new_ptr: NonNull<T> = self.slice.handle.allocate_or_extend(ptr, self.capacity, new_capacity);

        if ptr != new_ptr {
            unsafe {
                ptr::copy_nonoverlapping(ptr.as_ptr(), new_ptr.as_ptr(), self.slice.len());
            }

            self.slice.ptr = new_ptr;
        }

        self.capacity = new_capacity;
    }

    // TODO: shrink_to_fit

    // TODO: shrink_to

    /// Shorten the vector, keeping the first `len` elements and dropping the rest.
    ///
    /// If `len` is greater than the vector's current length, this has no effect.
    pub fn truncate(&mut self, len: usize) {
        let old_len = self.slice.len;

        if len < old_len {
            unsafe {
                ptr::drop_in_place(&mut self.slice[len..old_len]);
            }

            self.slice.len = len;
        }
    }

    /// Remove an element from the vector and return it.
    ///
    /// The removed element is replaced by the last element of the vector.
    /// This does not preserve ordering, but is O(1).
    pub fn swap_remove(&mut self, index: usize) -> T {
        let hole: *mut T = &mut self[index];
        self.slice.len -= 1;

        unsafe {
            let last = ptr::read(self.slice.ptr.as_ptr().add(self.slice.len));
            ptr::replace(hole, last)
        }
    }

    // TODO: insert

    // TODO: remove

    // TODO: retain

    // TODO: dedup_by_key

    // TODO: dedup_by

    /// Push an element into the vector.
    pub fn push(&mut self, elem: T) {
        if self.slice.len == self.capacity {
            let new_capacity = if self.capacity == 0 {
                4
            } else {
                self.capacity * 2
            };

            self.reserve(new_capacity - self.capacity);
        }

        unsafe {
            ptr::write(self.slice.ptr.as_ptr().add(self.slice.len()), elem);
        }

        self.slice.len = self.slice.len() + 1;
    }

    /// Remove the last element from the vector and return it, or `None` if the vector is empty.
    pub fn pop(&mut self) -> Option<T> {
        if self.is_empty() {
            return None;
        }

        unsafe {
            self.slice.len -= 1;
            Some(ptr::read(self.slice.ptr.as_ptr().add(self.slice.len)))
        }
    }

    /// Move all elements of `other` into `self`, leaving `other` empty.
    pub fn append(&mut self, other: &mut Self) {
        let count = other.len();
        self.reserve(count);
        let len = self.len();

        unsafe {
            ptr::copy_nonoverlapping(
                other.slice.ptr.as_ptr(),
                self.slice.ptr.as_ptr().add(len),
                count);
        }

        other.slice.len = 0;
    }

    // TODO: drain

    /// Clear the vector.
    pub fn clear(&mut self) {
        unsafe {
            ptr::drop_in_place(&mut self.slice[..]);
        }

        self.slice.len = 0;
    }

    /// Return the number of elements in the vector.
    pub fn len(&self) -> usize {
        self.slice.len
    }

    /// Return `true` if the vector contains no elements.
    pub fn is_empty(&self) -> bool {
        self.slice.len == 0
    }

    // TODO: split_off

    /// Resize the vector to hold `len` elements, initialized to the return value of `f` if necessary.
    pub fn resize_with<F>(&mut self, len: usize, mut f: F)
    where
        F: FnMut() -> T,
    {
        let old_len = self.slice.len;

        if self.capacity < len {
            self.reserve(len - old_len);
        }

        for i in old_len..len.saturating_sub(1) {
            unsafe { ptr::write(self.slice.ptr.as_ptr().add(i), f()) }
        }

        if len > old_len {
            unsafe {
                ptr::write(self.slice.ptr.as_ptr().add(len - 1), f());
            }
        } else if len < old_len {
            unsafe {
                ptr::drop_in_place(&mut self.slice[len..old_len]);
            }
        }

        self.slice.len = len;
    }

    /// Resize the vector to hold `len` elements, initialized to `value` if necessary.
    pub fn resize(&mut self, len: usize, value: T)
    where
        T: Clone,
    {
        let old_len = self.slice.len;

        if self.capacity < len {
            self.reserve(len - old_len);
        }

        for i in old_len..len.saturating_sub(1) {
            unsafe { ptr::write(self.slice.ptr.as_ptr().add(i), value.clone()) }
        }

        if len > old_len {
            unsafe {
                ptr::write(self.slice.ptr.as_ptr().add(len - 1), value);
            }
        } else if len < old_len {
            unsafe {
                ptr::drop_in_place(&mut self.slice[len..old_len]);
            }
        }

        self.slice.len = len;
    }

    // TODO: extend from slice

    // TODO: dedup

    // TODO: remove_item

    // TODO: splice

    // TODO: drain_filter
}

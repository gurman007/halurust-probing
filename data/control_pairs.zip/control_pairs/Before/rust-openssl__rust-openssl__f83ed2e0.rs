        pub struct X509_REVOKED {
            pub serialNumber: *mut ASN1_INTEGER,
            pub revocationDate: *mut ASN1_TIME,
            extensions: *mut stack_st_X509_EXTENSION,
            issuer: *mut stack_st_GENERAL_NAME,
            reason: c_int,
            sequence: c_int,
        }
    pub fn X509_REVOKED_free(x: *mut X509_REVOKED);

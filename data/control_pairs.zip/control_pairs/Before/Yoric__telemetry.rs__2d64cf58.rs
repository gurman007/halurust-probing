struct FlagFront<K> {
    back_end: BackEnd<K>,
}
struct FlagStorage {
    // `true` once we have called `record`, `false` until then.
    encountered: bool
}
    fn record_cb<F>(&self, cb: F) where F: FnOnce() -> Option<()>  {
        if let Some(k) = self.back_end.get_key() {
            match cb() {
                None => {}
                Some(()) => self.back_end.raw_record(&k, 0)
            }
        }
    }
    pub fn new(feature: &Feature, meta: Metadata) -> KeyedFlag<K> {
        let storage = Box::new(FlagStorageMap { encountered: HashSet::new() });
        let key = feature.telemetry.register_keyed(meta, storage);
        KeyedFlag {
            back_end: BackEnd::new(feature, key),
        }
    }
struct FlagStorageMap {
    encountered: HashSet<String>
}

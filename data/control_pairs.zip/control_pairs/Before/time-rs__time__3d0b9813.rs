    const unsafe fn from_parts(year: i32, is_leap_year: bool, ordinal: u16) -> Self {
        debug_assert!(year >= MIN_YEAR);
        debug_assert!(year <= MAX_YEAR);
        debug_assert!(ordinal != 0);
        debug_assert!(ordinal <= days_in_year(year));
        debug_assert!(crate::util::is_leap_year(year) == is_leap_year);

        Self {
            // Safety: `ordinal` is not zero.
            value: unsafe {
                NonZeroI32::new_unchecked(year << 10 | (is_leap_year as i32) << 9 | ordinal as i32)
            },
        }
    }
    const fn is_in_leap_year(self) -> bool {
        self.value.get() >> 9 & 1 == 1
    }
    pub const fn length(self, year: i32) -> u8 {
        let val = self as u8;
        if hint::unlikely(val == 2) {
            if util::is_leap_year(year) {
                29
            } else {
                28
            }
        } else {
            30 | val ^ val >> 3
        }
    }

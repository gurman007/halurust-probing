    unsafe fn owned_from_parts(mut ptr: NonNull<Self>, capacity: NonZeroUsize) -> Vec<T> {
        Vec::from_raw_parts(
            ptr.as_mut().as_mut_ptr(),
            ptr.as_mut().len(),
            capacity.get(),
        )
    }

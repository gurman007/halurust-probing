    pub fn set_whitelist_filtering(&mut self, hosts: Vec<String>) -> &Self {
        // FIXME replace host strings with InetSomethings
        unsafe {
            cass_cluster_set_whitelist_filtering(self.0, hosts.join(",").as_ptr() as *const i8);
        }
        self
    }

    pub struct Codec<Req, Resp> {
        phantom: PhantomData<(Req, Resp)>,
    }
        fn default() -> Self {
            Codec {
                phantom: PhantomData,
            }
        }
        fn clone(&self) -> Self {
            Self::default()
        }
        async fn read_request<T>(&mut self, _: &Self::Protocol, io: &mut T) -> io::Result<Req>
        where
            T: AsyncRead + Unpin + Send,
        {
            let mut vec = Vec::new();

            io.take(REQUEST_SIZE_MAXIMUM).read_to_end(&mut vec).await?;

            cbor4ii::serde::from_slice(vec.as_slice()).map_err(decode_into_io_error)
        }
        async fn read_response<T>(&mut self, _: &Self::Protocol, io: &mut T) -> io::Result<Resp>
        where
            T: AsyncRead + Unpin + Send,
        {
            let mut vec = Vec::new();

            io.take(RESPONSE_SIZE_MAXIMUM).read_to_end(&mut vec).await?;

            cbor4ii::serde::from_slice(vec.as_slice()).map_err(decode_into_io_error)
        }
    pub struct Codec<Req, Resp> {
        phantom: PhantomData<(Req, Resp)>,
    }
        fn default() -> Self {
            Codec {
                phantom: PhantomData,
            }
        }
        fn clone(&self) -> Self {
            Self::default()
        }
        async fn read_request<T>(&mut self, _: &Self::Protocol, io: &mut T) -> io::Result<Req>
        where
            T: AsyncRead + Unpin + Send,
        {
            let mut vec = Vec::new();

            io.take(REQUEST_SIZE_MAXIMUM).read_to_end(&mut vec).await?;

            Ok(serde_json::from_slice(vec.as_slice())?)
        }
        async fn read_response<T>(&mut self, _: &Self::Protocol, io: &mut T) -> io::Result<Resp>
        where
            T: AsyncRead + Unpin + Send,
        {
            let mut vec = Vec::new();

            io.take(RESPONSE_SIZE_MAXIMUM).read_to_end(&mut vec).await?;

            Ok(serde_json::from_slice(vec.as_slice())?)
        }

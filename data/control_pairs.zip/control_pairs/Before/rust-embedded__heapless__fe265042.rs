pub struct IntoIter<T, N>
where
    N: ArrayLength<T>,
{
    vec_rev: Vec<T, N>
}
    fn next(&mut self) -> Option<Self::Item> {
        self.vec_rev.pop()
    }
    fn into_iter(mut self) -> Self::IntoIter {
        self.reverse();
        IntoIter { vec_rev: self }
    }
            fn new() -> Self {
                unsafe {
                    COUNT += 1;
                }
                Droppable
            }
    fn drop() {
        struct Droppable;
        impl Droppable {
            fn new() -> Self {
                unsafe {
                    COUNT += 1;
                }
                Droppable
            }
        }
        impl Drop for Droppable {
            fn drop(&mut self) {
                unsafe {
                    COUNT -= 1;
                }
            }
        }

        static mut COUNT: i32 = 0;

        {
            let mut v: Vec<Droppable, U2> = Vec::new();
            v.push(Droppable::new()).ok().unwrap();
            v.push(Droppable::new()).ok().unwrap();
            v.pop().unwrap();
        }

        assert_eq!(unsafe { COUNT }, 0);

        {
            let mut v: Vec<Droppable, U2> = Vec::new();
            v.push(Droppable::new()).ok().unwrap();
            v.push(Droppable::new()).ok().unwrap();
        }

        assert_eq!(unsafe { COUNT }, 0);
    }

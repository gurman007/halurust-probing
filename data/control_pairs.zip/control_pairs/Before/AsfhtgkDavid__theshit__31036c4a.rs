pub fn get_aliases() -> HashMap<String, String> {
    let raw_aliases = env::var("SH_SHELL_ALIASES").unwrap_or(String::from(""));
    let split_raw_aliases = raw_aliases.split('\n');
    let mut aliases: HashMap<String, String> = HashMap::new();
    for raw_alias in split_raw_aliases {
        if !raw_alias.contains('=') || raw_alias.is_empty() {
            continue;
        }
        if let Some((name, mut value)) = raw_alias.split_once('=') {
            let value_bytes = value.as_bytes();
            if (value_bytes[0] == b'"' && value_bytes[value.len() - 1] == b'"')
                || (value_bytes[0] == b'\'' && value_bytes[value.len() - 1] == b'\'')
            {
                value = &value[1..value.len() - 1];
            }
            aliases.insert(
                name.replacen("alias ", "", 1).to_string(),
                value.to_string(),
            );
        }
    }
    aliases
}
pub fn get_aliases() -> HashMap<String, String> {
    let raw_aliases = env::var("SH_SHELL_ALIASES").unwrap_or(String::from(""));
    let split_raw_aliases = raw_aliases.split('\n');
    let mut aliases: HashMap<String, String> = HashMap::new();
    for raw_alias in split_raw_aliases {
        if !raw_alias.contains("alias ") || raw_alias.is_empty() {
            continue;
        }
        let parts = misc::split_command(raw_alias);
        if parts.len() != 3 || parts[0] != "alias" {
            continue;
        }
        aliases.insert(parts[1].to_string(), parts[2].to_string());
    }
    aliases
}
pub fn setup_alias(setup_command: String, config_path: &Path) -> Result<()> {
    let mut config_file = match OpenOptions::new().read(true).append(true).open(config_path) {
        Ok(file) => file,
        Err(error) => match error.kind() {
            ErrorKind::NotFound => {
                println!(
                    "Can't find config file({}), do you want to create it? (Y/n)",
                    config_path.display()
                );
                let mut input = String::new();
                stdin()
                    .read_line(&mut input)
                    .expect("Error getting user input");
                if input.trim().eq_ignore_ascii_case("y") || input.trim().is_empty() {
                    File::create(config_path).expect("Failed to create config file")
                } else {
                    return Err(ErrorKind::NotFound.into());
                }
            }
            _ => {
                return Err(error);
            }
        },
    };

    let mut config_content = String::new();

    config_file.read_to_string(&mut config_content)?;
    if config_content.contains(&setup_command) {
        return Err(ErrorKind::AlreadyExists.into());
    }

    writeln!(config_file, "{setup_command}")
}
pub fn get_aliases() -> HashMap<String, String> {
    let raw_aliases = env::var("SH_SHELL_ALIASES").unwrap_or(String::from(""));
    let split_raw_aliases = raw_aliases.split('\n');
    let mut aliases: HashMap<String, String> = HashMap::new();
    for raw_alias in split_raw_aliases {
        if !raw_alias.contains('=') || raw_alias.is_empty() {
            continue;
        }
        if let Some((name, mut value)) = raw_alias.split_once('=') {
            let value_bytes = value.as_bytes();
            if (value_bytes[0] == b'"' && value_bytes[value.len() - 1] == b'"')
                || (value_bytes[0] == b'\'' && value_bytes[value.len() - 1] == b'\'')
            {
                value = &value[1..value.len() - 1];
            }
            aliases.insert(name.to_string(), value.to_string());
        }
    }
    aliases
}

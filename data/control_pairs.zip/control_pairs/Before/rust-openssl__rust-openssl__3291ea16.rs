            pub fn EVP_PKEY_CTX_add1_hkdf_info(
                ctx: *mut EVP_PKEY_CTX,
                info: *const u8,
                infolen: c_int,
            ) -> c_int;
    pub fn OSSL_PARAM_construct_end() -> OSSL_PARAM;
pub struct OSSL_PARAM {
    key: *const c_char,
    data_type: c_uchar,
    data: *mut c_void,
    data_size: size_t,
    return_size: size_t,
}

    fn fill_buf(&mut self) -> IoResult<&[u8]> {
        if self.buf.capacity() == self.consumed {
            self.reserve_up_to(self.buf.capacity() + 16);
        }

        let b = self.buf.len();
        unsafe {
            // safe because it's within the buffer's limits
            // and we won't be reading uninitialized memory
            self.buf.set_len(self.buf.capacity());
        }
        let buf = &mut self.buf[b..];

        match self.inner.read(buf) {
            Ok(o) => {
                // take off the unwritten portion
                self.buf.truncate(b + o);

                Ok(&self.buf[self.consumed..])
            }
            Err(e) => Err(e),
        }
    }

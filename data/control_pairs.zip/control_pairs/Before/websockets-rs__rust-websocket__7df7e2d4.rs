	fn from_str(accept: &str) -> WebSocketResult<WebSocketAccept> {
		match accept.from_base64() {
			Ok(vec) => {
				if vec.len() != 20 {
					return Err(WebSocketError::ProtocolError(
						"Sec-WebSocket-Accept must be 20 bytes".to_string()
					));
				}
				let mut array = [0u8; 20];
				copy_memory(&mut array, &vec[..]);
				Ok(WebSocketAccept(array))
			}
			Err(_) => {
				return Err(WebSocketError::ProtocolError(
					"Invalid Sec-WebSocket-Accept ".to_string()
				));
			}
		}
	}
	pub fn new(key: &WebSocketKey) -> WebSocketAccept {
		let serialized = key.serialize();
		let mut concat_key = String::with_capacity(serialized.len() + 36);
		concat_key.push_str(&serialized[..]);
		concat_key.push_str(MAGIC_GUID);
		let output = hash(hash::Type::SHA1, concat_key.as_bytes());
		let mut bytes = [0u8; 20];
		copy_memory(&mut bytes, &output[..]);
		WebSocketAccept(bytes)
	}
	fn from_str(key: &str) -> WebSocketResult<WebSocketKey> {
		match key.from_base64() {
			Ok(vec) => {
				if vec.len() != 16 {
					return Err(WebSocketError::ProtocolError(
						"Sec-WebSocket-Key must be 16 bytes".to_string()
					));
				}
				let mut array = [0u8; 16];
				copy_memory(&mut array, &vec[..]);
				Ok(WebSocketKey(array))
			}
			Err(_) => {
				return Err(WebSocketError::ProtocolError(
					"Invalid Sec-WebSocket-Accept".to_string()
				));
			}
		}
	}

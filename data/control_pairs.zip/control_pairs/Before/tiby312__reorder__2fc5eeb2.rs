pub fn reorder<'a,A:Copy,B:HasIndex>(arr:&'a mut [A],index:&mut [B])->&'a mut [A]{
	assert_eq!(arr.len(),index.len());

	for i in 0..arr.len(){
		while index[i].get()!=i{
			let old_target_i = index[index[i].get()].get();
			let old_target_e = arr[index[i].get()];

			arr[index[i].get()]=arr[i];
			index[index[i].get()].set(index[i].get());

			index[i].set(old_target_i);
			arr[i] = old_target_e;
		}
	}
	arr
}

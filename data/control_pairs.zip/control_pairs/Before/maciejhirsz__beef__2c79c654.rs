    unsafe fn owned_ptr(owned: &mut Vec<T>) -> NonNull<[T]> {
        NonNull::new_unchecked(owned.as_mut_slice() as *mut [T])
    }
    pub fn owned(mut val: B::Owned) -> Self {
        let capacity = B::capacity(&val);
        let inner = unsafe { B::owned_ptr(&mut val) };

        mem::forget(val);

        Cow {
            inner,
            capacity,
            marker: PhantomData,
        }
    }

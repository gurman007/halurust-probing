impl<'a, const VERSION: u8> TryFrom<Vec<Item<'a, VERSION>>>
    for crate::format_description::__private::FormatDescriptionV3Inner<'a>
{
    type Error = Error;

    #[inline]
    fn try_from(items: Vec<Item<'a, VERSION>>) -> Result<Self, Self::Error> {
        assert_version!();
        match <[_; 1]>::try_from(items) {
            Ok([item]) => item.try_into(),
            Err(vec) => Ok(Self::OwnedCompound(
                vec.into_iter()
                    .map(Self::try_from)
                    .collect::<Result<_, _>>()?,
            )),
        }
    }
}
    fn parse_owned(s: &str) -> Result<Self::OwnedOutput, error::InvalidFormatDescription> {
        Ok(FormatDescriptionV3Inner::OwnedCompound(
            Lexer::<3>::new(s)
                .map(|res| res.and_then(TryInto::try_into))
                .collect::<Result<_, _>>()?,
        )
        .into_opaque()
        .to_owned())
    }

    fn fmt(&self, f: &mut core::fmt::Formatter) -> core::fmt::Result {
        match self {
            //#[cfg(feature = "std")]
            Self::Io(err) => write!(f, "{}", err),
            Self::UnsupportedCode(code) => write!(f, "Unsupported multihash code {}.", code),
            Self::InvalidSize(size) => write!(f, "Invalid multihash size {}.", size),
            Self::Varint(err) => write!(f, "{}", err),
        }
    }
    pub fn to_bytes(&self) -> Vec<u8> {
        let mut bytes: Vec<u8> = Vec::with_capacity(self.size().into());
        self.write(&mut bytes)
            .expect("writing to a vec should never fail");
        bytes
    }
pub fn read_multihash<R, S>(mut r: R) -> Result<(u64, u8, GenericArray<u8, S>), Error>
where
    R: io::Read,
    S: Size,
{
    let code = match read_u64(&mut r) {
        Ok(c) => c,
        Err(e) => return Err(e.into()),
    };
    let size = match read_u64(&mut r) {
        Ok(s) => s,
        Err(e) => return Err(e.into()),
    };

    if size > S::to_u64() || size > u8::MAX as u64 {
        return Err(Error::InvalidSize(size));
    }

    let mut digest = GenericArray::default();
    r.read_exact(&mut digest[..size as usize])?;
    Ok((code, size as u8, digest))
}

    pub fn eigenvalues(&self) -> OVector<Complex<T>, D>
    where
        DefaultAllocator: Allocator<Complex<T>, D>,
    {
        let mut out = Matrix::zeros_generic(self.vsl.shape_generic().0, Const::<1>);

        for i in 0..out.len() {
            out[i] = if self.beta[i].clone().abs() < T::RealField::default_epsilon() {
                Complex::zero()
            } else {
                Complex::new(self.alphar[i].clone(), self.alphai[i].clone())
                    * (Complex::new(self.beta[i].clone(), T::RealField::zero()).inv())
            }
        }

        out
    }

fn test_transcode<N>(n: N, rounds: usize)
where
    N: Random + Serialize + DeserializeOwned + PartialEq + Debug,
{
    for _ in 0..rounds {
        let n_json = serde_json::to_string(&n).unwrap();
        let n_dec = serde_json::from_str(&n_json).unwrap();
        assert_eq!(n, n_dec);
    }
}
fn transcode_float_serde_json() {
    test_transcode(f32::random(), 10000);
    test_transcode(f64::random(), 10000);
}
fn transcode_vec_float_serde_json() {
    test_transcode(Vec::<f32>::random(), 1000);
    test_transcode(Vec::<f64>::random(), 1000);
}

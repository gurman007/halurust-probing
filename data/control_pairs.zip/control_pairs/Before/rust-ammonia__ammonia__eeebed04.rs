    pub fn clean(&self, src: &'a str) -> String {
        let mut dom: RcDom = html::parse_fragment(std::iter::once(format_tendril!("{}", src)), Atom::from_slice("div"), html::ParseOpts::default());
        let mut stack = Vec::new();
        let body = {
            let document = dom.document.borrow_mut();
            document.children[0].clone()
        };
        stack.push(body.clone());
        while stack.len() != 0 {
            let node_handle = stack.pop().unwrap();
            let mut has_children = {
                let node = node_handle.borrow_mut();
                match &node.node {
                    &NodeEnum::Comment(_) | &NodeEnum::Text(_) | &NodeEnum::Doctype(_, _, _) => false,
                    &NodeEnum::Document | &NodeEnum::Element(_, _) => true,
                }
            };
            while has_children {
                let mut children = Vec::new();
                {
                    let mut node = node_handle.borrow_mut();
                    swap(&mut node.children, &mut children);
                }
                for child in &mut children {
                    self.clean_child(&mut dom, child, node_handle.clone());
                }
                {
                    let node = node_handle.borrow_mut();
                    has_children = node.children.len() != children.len();
                }
            }
            let node = node_handle.borrow_mut();
            stack.extend(node.children.clone());
        }
        let mut ret_val = Vec::new();
        let opts = SerializeOpts{
            traversal_scope: TraversalScope::ChildrenOnly,
            .. SerializeOpts::default()
        };
        serialize(&mut ret_val, &body, opts).unwrap();
        String::from_utf8(ret_val).unwrap()
    }
    fn clean_child(&self, dom: &mut RcDom, child: &mut Handle, parent: Handle) {
        let pass = {
            let mut child = child.borrow_mut();
            let mut child = &mut *child;
            match &mut child.node {
                &mut NodeEnum::Text(_) => true,
                &mut NodeEnum::Comment(_) => !self.strip_comments,
                &mut NodeEnum::Doctype(_, _, _) |
                &mut NodeEnum::Document => false,
                &mut NodeEnum::Element(ref name, ref attrs) => {
                    let safe_tag = {
                        if self.tags.contains(&*name.local) {
                            attrs.iter().skip_while(|attr| {
                                let whitelisted = self.generic_attributes.contains(&*attr.name.local) ||
                                    self.tag_attributes.get(&*name.local).map(|ta| ta.contains(&*attr.name.local)) == Some(true);
                                if !whitelisted {
                                    false
                                } else if &*attr.name.local == "href" || &*attr.name.local == "src" {
                                    let url = Url::parse(&*attr.value);
                                    if let Ok(url) = url {
                                        self.url_schemes.contains(&*url.scheme)
                                    } else {
                                        false
                                    }
                                } else {
                                    true
                                }
                            }).next().is_none()
                        } else {
                            false
                        }
                    };
                    if !safe_tag {
                        if !self.strip {
                            dom.append(parent.clone(), NodeOrText::AppendText(format_tendril!("<{}", &*name.local)));
                            for attr in attrs {
                                dom.append(parent.clone(), NodeOrText::AppendText(format_tendril!(" {}=\"{}\"", &*attr.name.local, attr.value)))
                            }
                            dom.append(parent.clone(), NodeOrText::AppendText(format_tendril!(">")));
                        }
                        for sub in &mut child.children {
                            {
                                let mut sub = sub.borrow_mut();
                                sub.parent = None;
                            }
                            dom.append(parent.clone(), NodeOrText::AppendNode(sub.clone()));
                        }
                        if !self.strip {
                            dom.append(parent.clone(), NodeOrText::AppendText(format_tendril!("</{}>", &*name.local)))
                        }
                    }
                    safe_tag
                },
            }
        };
        if pass {
            {
                let mut child = child.borrow_mut();
                child.parent = None;
            }
            dom.append(parent, NodeOrText::AppendNode(child.clone()));
        }
    }

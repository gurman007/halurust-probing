    fn copy_from_toodee(&mut self, src: &impl TooDeeOps<T>) where T : Copy {
        assert_eq!(self.size(), src.size());
        // Data is copied row by row.
        for (d, s) in self.rows_mut().zip(src.rows()) {
            d.copy_from_slice(s);
        }
    }
    fn clone_from_toodee(&mut self, src: &impl TooDeeOps<T>) where T : Clone {
        assert_eq!(self.size(), src.size());
        // Data is copied row by row.
        for (d, s) in self.rows_mut().zip(src.rows()) {
            d.clone_from_slice(s);
        }
    }
    fn is_empty(&self) -> bool {
        self.num_cols() * self.num_rows() == 0
    }
    fn swap_cols(&mut self, c1: usize, c2: usize) {
        assert!(c1 < self.num_cols());
        assert!(c2 < self.num_cols());
        for r in self.rows_mut() {
            r.swap(c1, c2);
        }
    }
    fn swap_rows(&mut self, r1: usize, r2: usize) {
        assert!(r1 < self.num_rows());
        assert!(r2 < self.num_rows());
        match r1.cmp(&r2) {
            Ordering::Less => {
                let mut iter = self.rows_mut();
                let tmp = iter.nth(r1).unwrap();
                tmp.swap_with_slice(iter.nth(r2-r1-1).unwrap());
            },
            Ordering::Greater => {
                let mut iter = self.rows_mut();
                let tmp = iter.nth(r2).unwrap();
                tmp.swap_with_slice(iter.nth(r1-r2-1).unwrap());
            },
            Ordering::Equal => {},
        }
    }
    fn row_pair_mut(&mut self, r1: usize, r2: usize) -> (&mut [T], &mut [T]) {
        assert!(r1 < self.num_rows());
        assert!(r2 < self.num_rows());
        assert!(r1 != r2);
        match r1.cmp(&r2) {
            Ordering::Less => {
                let mut iter = self.rows_mut();
                let tmp = iter.nth(r1).unwrap();
                (tmp, iter.nth(r2-r1-1).unwrap())
            },
            Ordering::Greater => {
                let mut iter = self.rows_mut();
                let tmp = iter.nth(r2).unwrap();
                (iter.nth(r1-r2-1).unwrap(), tmp)
            },
            Ordering::Equal => {
                unreachable!("r1 != r2");
            },
        }
    }
    fn zero_size_toodee() {
        let mut toodee = TooDee::init(0, 0, 0u32);
        assert_eq!(toodee.rows_mut().next(), None);
        assert_eq!(toodee.rows().next(), None);
        assert_eq!(toodee.cells().next(), None);
        assert_eq!(toodee.cells_mut().next(), None);
    }
    fn zero_size_view() {
        let mut toodee = TooDee::init(10, 10, 0u32);
        let mut view = toodee.view_mut((5, 5), (5, 5));
        assert_eq!(view.rows_mut().next(), None);
        assert_eq!(view.rows().next(), None);
        assert_eq!(view.cells().next(), None);
        assert_eq!(view.cells_mut().next(), None);
        view = toodee.view_mut((5, 5), (6, 5));
        assert_eq!(view.rows_mut().next(), None);
        assert_eq!(view.rows().next(), None);
        assert_eq!(view.cells().next(), None);
        assert_eq!(view.cells_mut().next(), None);
        view = toodee.view_mut((5, 5), (5, 6));
        assert_eq!(view.rows_mut().next(), None);
        assert_eq!(view.rows().next(), None);
        assert_eq!(view.cells().next(), None);
        assert_eq!(view.cells_mut().next(), None);
    }
mod toodee_tests_copy {

    use crate::*;

    #[test]
    fn copy_within_1() {
        let mut toodee = TooDee::from_vec(10, 10, (0u32..100).collect());
        toodee.copy_within(((0, 0), (2, 2)), (8, 8));
        let orig = (100*100 - 100) / 2;
        assert_eq!(toodee.data().iter().sum::<u32>(), orig - 98-99-88-89+1+10+11);
    }
    
    #[test]
    fn copy_within_2() {
        let mut toodee = TooDee::from_vec(10, 10, (0u32..100).collect());
        toodee.copy_within(((8, 8), (10, 10)), (0, 0));
        let orig = (100*100 - 100) / 2;
        assert_eq!(toodee.data().iter().sum::<u32>(), orig +98+99+88+89-1-10-11);
    }

    #[test]
    fn copy_within_overlap_1() {
        let mut toodee = TooDee::from_vec(10, 10, (0u32..100).collect());
        toodee.copy_within(((0, 0), (2, 2)), (1, 1));
        let orig = (100*100 - 100) / 2;
        assert_eq!(toodee.data().iter().sum::<u32>(), orig -11-12-21-22 +1+10+11);
    }

    #[test]
    fn copy_within_overlap_2() {
        let mut toodee = TooDee::from_vec(10, 10, (0u32..100).collect());
        toodee.copy_within(((1, 1), (3, 3)), (0, 0));
        let orig = (100*100 - 100) / 2;
        assert_eq!(toodee.data().iter().sum::<u32>(), orig +11+12+21+22 -1-10-11);
    }

}

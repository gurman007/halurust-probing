unsafe impl<T, B: Buffer<T>> Sync for MPMCProducer<T, B> {}
unsafe impl<T, B: Buffer<T>> Sync for MPSCProducer<T, B> {}
unsafe impl<T, B: Buffer<T>> Sync for SPMCProducer<T, B> {}
unsafe impl<T, B: Buffer<T>> Send for SPSCProducer<T, B> {}

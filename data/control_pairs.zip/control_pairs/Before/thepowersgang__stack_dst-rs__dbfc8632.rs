    pub fn retain<Cb>(&mut self, mut cb: Cb)
    where
        Cb: FnMut(&mut T)->bool
    {
        let orig_write_pos = self.write_pos;
        self.write_pos = self.read_pos;
        let mut ofs = self.read_pos;
        let mut writeback_pos = ofs;
        while ofs < orig_write_pos
        {
            let v: &mut T = unsafe {
                let meta = &mut self.data.as_mut()[ofs..];
                let mw = Self::meta_words();
                let (meta, data) = meta.split_at_mut(mw);
                &mut *super::make_fat_ptr(data.as_mut_ptr() as *mut (), meta)
                };
            let words = Self::meta_words() + D::round_to_words(mem::size_of_val(v));
            if cb(v) {
                if writeback_pos != ofs {
                    let src: *const _ = self.data.as_ref()[ofs..].as_ptr();
                    let dst: *mut _ = self.data.as_mut()[writeback_pos..].as_mut_ptr();
                    // SAFE: Pointers are valid, length is correct
                    unsafe { ptr::copy(src, dst, words); }
                }
                writeback_pos += words;
            }
            else {
                // Don't update `writeback_pos`
                // SAFE: Valid pointer, won't be accessed again
                unsafe {
                    ptr::drop_in_place(v);
                }
            }
            ofs += words;
        }
        assert!(ofs == orig_write_pos);
        self.write_pos = writeback_pos;
    }

    fn eq(&self, other: &NSMutableString) -> bool {
        self.eq(other as &NSString)
    }
    fn partial_cmp(&self, other: &NSMutableString) -> Option<Ordering> {
        Some(NSString::cmp(self, other))
    }

    fn check_spec(d: &DateTime<Utc>, s: String) {
        let b = ASN1Block::GeneralizedTime(0, d.clone());
        match to_der(&b) {
            Err(_) => assert_eq!(format!("Broken: {}", d), s),
            Ok(ref vec) => {
                let mut resvec = vec.clone();
                resvec.remove(0);
                resvec.remove(0);
                assert_eq!(String::from_utf8(resvec).unwrap(), s);
            }
        }
    }

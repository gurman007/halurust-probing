fn parse_contents(contents: String) -> Result<Vec<Hotkey>, Error> {
    let key_to_evdev_key: HashMap<&str, evdev::Key> = HashMap::from([
        ("q", evdev::Key::KEY_Q),
        ("w", evdev::Key::KEY_W),
        ("e", evdev::Key::KEY_E),
        ("r", evdev::Key::KEY_R),
        ("t", evdev::Key::KEY_T),
        ("y", evdev::Key::KEY_Y),
        ("u", evdev::Key::KEY_U),
        ("i", evdev::Key::KEY_I),
        ("o", evdev::Key::KEY_O),
        ("p", evdev::Key::KEY_P),
        ("a", evdev::Key::KEY_A),
        ("s", evdev::Key::KEY_S),
        ("d", evdev::Key::KEY_D),
        ("f", evdev::Key::KEY_F),
        ("g", evdev::Key::KEY_G),
        ("h", evdev::Key::KEY_H),
        ("j", evdev::Key::KEY_J),
        ("k", evdev::Key::KEY_K),
        ("l", evdev::Key::KEY_L),
        ("z", evdev::Key::KEY_Z),
        ("x", evdev::Key::KEY_X),
        ("c", evdev::Key::KEY_C),
        ("v", evdev::Key::KEY_V),
        ("b", evdev::Key::KEY_B),
        ("n", evdev::Key::KEY_N),
        ("m", evdev::Key::KEY_M),
        ("1", evdev::Key::KEY_1),
        ("2", evdev::Key::KEY_2),
        ("3", evdev::Key::KEY_3),
        ("4", evdev::Key::KEY_4),
        ("5", evdev::Key::KEY_5),
        ("6", evdev::Key::KEY_6),
        ("7", evdev::Key::KEY_7),
        ("8", evdev::Key::KEY_8),
        ("9", evdev::Key::KEY_9),
        ("0", evdev::Key::KEY_0),
    ]);

    let lines: Vec<&str> = contents.split('\n').collect();
    let mut hotkeys: Vec<Hotkey> = Vec::new();

    let mut lines_to_skip: u32 = 0;

    // Parse file line-by-line
    for i in 0..lines.len() {
        if lines_to_skip > 0 {
            lines_to_skip -= 1;
            continue;
        }

        // Ignore blank lines and comments starting with #
        if lines[i].trim().is_empty() || lines[i].trim().starts_with('#') {
            continue;
        }

        // We need to get the real line number for errors
        // because arrays in Rust are zero-index while lines
        // in a file are of course counted from 1
        let real_line_no: u32 = (i + 1).try_into().unwrap();

        let mut keysyms: Vec<evdev::Key> = Vec::new();

        if key_to_evdev_key.contains_key(lines[i].trim()) {
            // If the keybind line is at the very last line,
            // it's impossible for there to be a command
            if i >= lines.len() - 1 {
                return Err(Error::InvalidConfig(ParseError::MissingCommand(real_line_no)));
            }

            // Translate keypress into evdev key
            let keysym = key_to_evdev_key.get(lines[i].trim()).unwrap();
            keysyms.push(*keysym);

            //// Find the command
            if lines[i + 1].trim().is_empty() {
                return Err(Error::InvalidConfig(ParseError::MissingCommand(real_line_no + 1)));
            }

            let command = lines[i + 1];

            // Error if the command doesn't start with whitespace
            if !command.starts_with(' ') && !command.starts_with('\t') {
                return Err(Error::InvalidConfig(ParseError::CommandWithoutWhitespace(
                    real_line_no + 1,
                )));
            }

            // Push a new hotkey to the hotkeys vector
            hotkeys.push(Hotkey::new(keysyms, String::from(command.trim())));

            // Skip trying to parse the next line (command)
            // because we already dealt with it
            lines_to_skip += 1;
        } else {
            return Err(Error::InvalidConfig(ParseError::UnknownSymbol(real_line_no)));
        }
    }

    Ok(hotkeys)
}
    fn test_multiline_command() -> std::io::Result<()> {
        let contents = "
k
    mpc ls | dmenu | \\
    sed -i 's/foo/bar/g'
                    ";

        let expected_keybind = Hotkey::new(
            vec![evdev::Key::KEY_K],
            String::from("mpc ls | dmenu | sed -i 's/foo/bar/g'"),
        );

        let real_keybind = parse_contents(contents.to_string());

        assert!(real_keybind.is_ok());

        let real_keybind = real_keybind.unwrap();

        assert_eq!(real_keybind.len(), 1);

        assert_eq!(real_keybind[0].keysyms, expected_keybind.keysyms);
        assert_eq!(real_keybind[0].command, expected_keybind.command);

        Ok(())
    }

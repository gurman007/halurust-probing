    fn country_id(
        #[case] number: PhoneNumber,
        #[case] country: Option<country::Id>,
        #[case] _type: Type,
    ) -> anyhow::Result<()> {
        assert_eq!(country, number.country().id());

        Ok(())
    }

fn compute_singular_size(proto_type: Type, field_number: u32, v: &ReflectValueRef) -> u64 {
    match proto_type {
        Type::TYPE_ENUM => {
            let enum_v = v.to_enum_value().unwrap();
            value_size(field_number, enum_v, WireType::Varint)
        }
        Type::TYPE_MESSAGE => {
            let msg_v = v.to_message().unwrap();
            let len = msg_v.compute_size_dyn();
            tag_size(field_number) + compute_raw_varint64_size(len) + len
        }
        Type::TYPE_GROUP => {
            unimplemented!()
        }
        Type::TYPE_UINT32 => {
            let typed_v = v.to_u32().unwrap();
            value_size(field_number, typed_v, WireType::Varint)
        }
        Type::TYPE_UINT64 => {
            let typed_v = v.to_u64().unwrap();
            value_size(field_number, typed_v, WireType::Varint)
        }
        Type::TYPE_INT32 => {
            let typed_v = v.to_i32().unwrap();
            value_size(field_number, typed_v, WireType::Varint)
        }
        Type::TYPE_INT64 => {
            let typed_v = v.to_i64().unwrap();
            value_size(field_number, typed_v, WireType::Varint)
        }
        Type::TYPE_SINT32 => {
            let typed_v = v.to_i32().unwrap();
            tag_size(field_number) + sint32_size_no_tag(typed_v)
        }
        Type::TYPE_SINT64 => {
            let typed_v = v.to_i64().unwrap();
            tag_size(field_number) + sint64_size_no_tag(typed_v)
        }
        Type::TYPE_FIXED32 => tag_size(field_number) + 4,
        Type::TYPE_FIXED64 => tag_size(field_number) + 8,
        Type::TYPE_SFIXED32 => tag_size(field_number) + 4,
        Type::TYPE_SFIXED64 => tag_size(field_number) + 8,
        Type::TYPE_BOOL => {
            let typed_v = v.to_bool().unwrap();
            value_size(field_number, typed_v, WireType::Varint)
        }
        Type::TYPE_STRING => {
            let typed_v = v.to_str().unwrap();
            string_size(field_number, typed_v)
        }
        Type::TYPE_BYTES => {
            let typed_v = v.to_bytes().unwrap();
            bytes_size(field_number, typed_v)
        }
        Type::TYPE_FLOAT => tag_size(field_number) + 4,
        Type::TYPE_DOUBLE => tag_size(field_number) + 8,
    }
}
pub fn value_size<T: ProtobufVarint>(field_number: u32, value: T, wt: WireType) -> u64 {
    tag_size(field_number) + value_size_no_tag(value, wt)
}

        pub struct UserExtras {
            pub extras: super::unix::UserExtras,
        }
            pub unsafe fn from_passwd(passwd: c_passwd) -> UserExtras {
                UserExtras {
                    extras: super::unix::UserExtras::from_passwd(passwd),
                }
            }
            fn default() -> UserExtras {
                UserExtras {
                    extras: super::unix::UserExtras::default(),
                }
            }
            fn home_dir(&self) -> &Path {
                Path::new(&self.extras.home_dir)
            }
            fn with_home_dir(mut self, home_dir: &str) -> User {
                self.extras.home_dir = home_dir.to_owned();
                self
            }
            fn shell(&self) -> &Path {
                Path::new(&self.extras.shell)
            }
            fn with_shell(mut self, shell: &str) -> User {
                self.extras.shell = shell.to_owned();
                self
            }

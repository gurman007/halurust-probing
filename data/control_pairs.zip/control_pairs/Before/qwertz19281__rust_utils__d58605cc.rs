    pub fn push(&mut self, v: T) where T: Clone {
        let (vec,slice) = self._make_mut_with_capacity(self.len() + 1);
        vec.truncate(slice.end);
        vec.push(v);
        self.slice.end += 1;
    }
    pub fn pop(&mut self) -> Option<T> where T: Clone {
        (self.slice.end > self.slice.start)
            .map(|| {
                let x = self.remove(self.len()-1);
                self.slice.end -= 1;
                x
            })
    }
fn ultrion() {
    let mut a = ArcSlice::from(&b"abcd"[..]);
    assert_eq!(a,&b"abcd"[..]);
    assert_eq!(&a[..],&b"abcd"[..]);
    assert_eq!(&a[2..],&b"cd"[..]);
    assert_eq!(&a[1..3],&b"bc"[..]);
    assert_eq!(&a[2..2],&b""[..]);

    a.extend_from_slice(&b"gh"[..]);
    a.insert_slice(4, &b"ef"[..]);
    assert_eq!(&a[..],&b"abcdefgh"[..]);

    let mut b = a.slice(2..4);
    assert_eq!(&b[..],&b"cd"[..]);
    b.extend_from_slice(&b"io"[..]);
    assert_eq!(&b[..],&b"cdio"[..]);

    assert_eq!(&a[..],&b"abcdefgh"[..]);

    a.remove(2);
    assert_eq!(&a[..],&b"abdefgh"[..]);
    a.swap_remove(2);
    assert_eq!(&a[..],&b"abhefg"[..]);

    let mut c = a.refc();
    c.push(b'f');
    c.retain(|&c| c == b'h' || c == b'f' );
    assert_eq!(&c[..],&b"hff"[..]);
    assert_eq!(&a[..],&b"abhefg"[..]);
}

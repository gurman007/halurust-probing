pub fn uumain(args: impl uucore::Args) -> UResult<()> {
    // GNU `cut` supports `-d=` to set the delimiter to `=`.
    // Clap parsing is limited in this situation, see:
    // https://github.com/uutils/coreutils/issues/2424#issuecomment-863825242
    let args = args.into_iter().map(|x| {
        if x == "-d=" {
            "--delimiter==".into()
        } else {
            x
        }
    });

    let matches = uucore::clap_localization::handle_clap_result(uu_app(), args)?;

    let complement = matches.get_flag(options::COMPLEMENT);
    let only_delimited = matches.get_flag(options::ONLY_DELIMITED);

    let (delimiter, out_delimiter) = get_delimiters(&matches)?;
    let line_ending = LineEnding::from_zero_flag(matches.get_flag(options::ZERO_TERMINATED));
    let suppress_split = matches.get_flag(options::NOTHING);

    // Only one, and only one of cutting mode arguments, i.e. `-b`, `-c`, `-f`,
    // is expected. The number of those arguments is used for parsing a cutting
    // mode and handling the error cases.
    let mode_args_and_counts: Vec<_> = [options::BYTES, options::CHARACTERS, options::FIELDS]
        .into_iter()
        .filter_map(|arg| {
            let count = matches.indices_of(arg)?.count();
            (count > 0).then(|| (arg, count))
        })
        .collect();

    let _selected_mode_arg = match mode_args_and_counts.as_slice() {
        [(arg, 1)] => *arg,
        [] => {
            return Err(USimpleError::new(
                1,
                translate!("cut-error-missing-mode-arg"),
            ));
        }
        _ => {
            return Err(USimpleError::new(
                1,
                translate!("cut-error-multiple-mode-args"),
            ));
        }
    };

    let mode_parse = match (
        matches.get_one::<String>(options::BYTES),
        matches.get_one::<String>(options::CHARACTERS),
        matches.get_one::<String>(options::FIELDS),
    ) {
        (Some(byte_ranges), None, None) => list_to_ranges(byte_ranges, complement).map(|ranges| {
            Mode::Bytes(
                ranges,
                Options {
                    out_delimiter,
                    line_ending,
                    field_opts: None,
                    suppress_split,
                },
            )
        }),

        (None, Some(char_ranges), None) => list_to_ranges(char_ranges, complement).map(|ranges| {
            Mode::Characters(
                ranges,
                Options {
                    out_delimiter,
                    line_ending,
                    field_opts: None,
                    suppress_split,
                },
            )
        }),

        (None, None, Some(field_ranges)) => {
            list_to_ranges(field_ranges, complement).map(|ranges| {
                Mode::Fields(
                    ranges,
                    Options {
                        out_delimiter,
                        line_ending,
                        field_opts: Some(FieldOptions {
                            delimiter,
                            only_delimited,
                        }),
                        suppress_split,
                    },
                )
            })
        }
        _ => unreachable!(),
    };

    let mode_parse = match mode_parse {
        Err(_) => mode_parse,
        Ok(mode) => match mode {
            Mode::Bytes(_, _) | Mode::Characters(_, _)
                if matches.contains_id(options::DELIMITER) =>
            {
                Err(translate!("cut-error-delimiter-only-with-fields"))
            }
            Mode::Bytes(_, _) | Mode::Characters(_, _)
                if matches.get_flag(options::WHITESPACE_DELIMITED) =>
            {
                Err(translate!("cut-error-whitespace-only-with-fields"))
            }
            Mode::Bytes(_, _) | Mode::Characters(_, _)
                if matches.get_flag(options::ONLY_DELIMITED) =>
            {
                Err(translate!("cut-error-only-delimited-only-with-fields"))
            }
            _ => Ok(mode),
        },
    };

    let mode = mode_parse.map_err(|e| USimpleError::new(1, e))?;
    #[allow(clippy::unwrap_used, reason = "clap provides '-' by default")]
    let files = matches.get_many::<OsString>(options::FILE).unwrap();

    cut_files(files, &mode);

    Ok(())
}

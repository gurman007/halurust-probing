    fn from(Buffer(offset, mut vec): Buffer) -> Self {
        vec.copy_within(offset.., 0);
        vec.truncate(vec.len() - offset);
        vec
    }
    pub fn expand(&mut self) {
        if self.1.len() == self.1.capacity() {
            self.1.reserve(32);
        }
        self.fill_capacity();
    }

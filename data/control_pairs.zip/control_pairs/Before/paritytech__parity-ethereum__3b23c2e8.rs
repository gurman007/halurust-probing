	fn visit_str<E>(self, value: &str) -> Result<Self::Value, E> where E: Error {
		if value.len() >= 2 && &value[0..2] == "0x" && value.len() & 1 == 0 {
			Ok(Bytes::new(FromHex::from_hex(&value[2..]).map_err(|e| Error::custom(format!("Invalid hex: {}", e)))?))
		} else {
			Err(Error::custom("Invalid bytes format. Expected a 0x-prefixed hex string with even length"))
		}
	}
	fn test_bytes_deserialize() {
		let bytes1: Result<Bytes, serde_json::Error> = serde_json::from_str(r#""""#);
		let bytes2: Result<Bytes, serde_json::Error> = serde_json::from_str(r#""0x123""#);
		let bytes3: Result<Bytes, serde_json::Error> = serde_json::from_str(r#""0xgg""#);

		let bytes4: Bytes = serde_json::from_str(r#""0x""#).unwrap();
		let bytes5: Bytes = serde_json::from_str(r#""0x12""#).unwrap();
		let bytes6: Bytes = serde_json::from_str(r#""0x0123""#).unwrap();

		assert!(bytes1.is_err());
		assert!(bytes2.is_err());
		assert!(bytes3.is_err());
		assert_eq!(bytes4, Bytes(vec![]));
		assert_eq!(bytes5, Bytes(vec![0x12]));
		assert_eq!(bytes6, Bytes(vec![0x1, 0x23]));
	}
					fn visit_str<E>(self, value: &str) -> Result<Self::Value, E> where E: serde::de::Error {

						if value.len() < 2 || &value[0..2] != "0x" {
							return Err(E::custom("expected a hex-encoded hash with 0x prefix"));
						}
						if value.len() != 2 + $size * 2 {
							return Err(E::invalid_length(value.len() - 2, &self));
						}

						match value[2..].from_hex() {
							Ok(ref v) => {
								let mut result = [0u8; $size];
								result.copy_from_slice(v);
								Ok($name(result))
							},
							Err(e) => Err(E::custom(format!("invalid hex value: {:?}", e))),
						}
					}
					fn visit_str<E>(self, value: &str) -> Result<Self::Value, E> where E: serde::de::Error {
						if value.len() < 2  || &value[0..2] != "0x" {
							return Err(E::custom("expected a hex-encoded numbers with 0x prefix"))
						}

						// 0x + len
						if value.len() > 2 + $size * 16 {
							return Err(E::invalid_length(value.len() - 2, &self));
						}

						$other::from_str(&value[2..]).map($name).map_err(|e| E::custom(&format!("invalid hex value: {:?}", e)))
					}
	fn should_fail_to_deserialize_decimals() {
		let deserialized1: Res = serde_json::from_str(r#""""#);
		let deserialized2: Res = serde_json::from_str(r#""0""#);
		let deserialized3: Res = serde_json::from_str(r#""10""#);
		let deserialized4: Res = serde_json::from_str(r#""1000000""#);
		let deserialized5: Res = serde_json::from_str(r#""1000000000000000000""#);

		assert!(deserialized1.is_err());
		assert!(deserialized2.is_err());
		assert!(deserialized3.is_err());
		assert!(deserialized4.is_err());
		assert!(deserialized5.is_err());
	}

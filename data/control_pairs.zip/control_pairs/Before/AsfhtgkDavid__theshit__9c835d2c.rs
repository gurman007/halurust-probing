    fn test_get_aliases_with_double_quotes() {
        unsafe {
            env::set_var("SH_SHELL_ALIASES", "alias grep=\"grep --color=auto\"");
        }
        let aliases = get_aliases();
        assert_eq!(aliases.get("grep"), Some(&"\"grep --color".to_string()));
        unsafe {
            env::remove_var("SH_SHELL_ALIASES");
        }
    }
    fn test_get_aliases_with_double_quotes() {
        unsafe {
            env::set_var("SH_SHELL_ALIASES", "grep=\"grep --color=auto\"");
        }
        let aliases = get_aliases();
        assert_eq!(aliases.get("grep"), Some(&"\"grep --color".to_string()));
        unsafe {
            env::remove_var("SH_SHELL_ALIASES");
        }
    }

fn write_console(mountpoint: &Path, platform: Option<&str>, consoles: &[Console]) -> Result<()> {
    // read platforms table
    let platforms = match fs::read_to_string(mountpoint.join("coreos/platforms.json")) {
        Ok(json) => serde_json::from_str::<HashMap<String, PlatformSpec>>(&json)
            .context("parsing platform table")?,
        // no table for this image?
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Default::default(),
        Err(e) => return Err(e).context("reading platform table"),
    };

    let mut kargs = Vec::new();
    let mut grub_commands = Vec::new();
    if !consoles.is_empty() {
        // custom console settings completely override platform-specific
        // defaults
        let mut grub_terminals = Vec::new();
        for console in consoles {
            kargs.push(console.karg());
            if let Some(cmd) = console.grub_command() {
                grub_commands.push(cmd);
            }
            grub_terminals.push(console.grub_terminal());
        }
        grub_terminals.sort_unstable();
        grub_terminals.dedup();
        for direction in ["input", "output"] {
            grub_commands.push(format!("terminal_{direction} {}", grub_terminals.join(" ")));
        }
    } else if let Some(platform) = platform {
        // platform-specific defaults
        if platform == "metal" {
            // we're just being asked to apply the defaults which are already
            // applied
            return Ok(());
        }
        let spec = platforms.get(platform).cloned().unwrap_or_default();
        kargs.extend(spec.kernel_arguments);
        grub_commands.extend(spec.grub_commands);
    } else {
        // nothing to do and the caller shouldn't have called us
        unreachable!();
    }

    // set kargs, removing any metal-specific ones
    let metal_spec = platforms.get("metal").cloned().unwrap_or_default();
    visit_bls_entry_options(mountpoint, |orig_options: &str| {
        KargsEditor::new()
            .append(&kargs)
            .delete(&metal_spec.kernel_arguments)
            .maybe_apply_to(orig_options)
            .context("setting platform kernel arguments")
    })?;

    // set grub commands
    if grub_commands != metal_spec.grub_commands {
        let path = mountpoint.join("grub2/grub.cfg");
        let grub_cfg = fs::read_to_string(&path).context("reading grub.cfg")?;
        let new_grub_cfg = update_grub_cfg_console_settings(&grub_cfg, &grub_commands)
            .context("updating grub.cfg")?;
        fs::write(&path, new_grub_cfg).context("writing grub.cfg")?;
    }
    Ok(())
}

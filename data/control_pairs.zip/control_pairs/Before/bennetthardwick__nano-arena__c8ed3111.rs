    fn split_at() {
        let (mut arena, john, julia, jane, jake) = setup_arena();

        let (j, mut arena) = arena.split_at(&julia).unwrap();

        assert_eq!(j, "Julia");
        assert!(arena.get_mut(john).is_some());
        assert!(arena.get_mut(jane).is_some());
        assert!(arena.get_mut(jake).is_some());

        assert!(arena.get_mut(julia).is_none());
    }

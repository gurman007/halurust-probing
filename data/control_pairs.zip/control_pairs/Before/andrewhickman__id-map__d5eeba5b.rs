    pub fn insert(&mut self, val: T) -> Id {
        if self.space == self.values.len() {
            self.values.push(val)
        } else {
            unsafe {
                ptr::write(self.values.get_unchecked_mut(self.space), val)
            }
        }
        let id = self.space;
        self.ids.insert(id);

        // Find the next empty space.
        self.space += 1;
        while self.ids.contains(self.space) {
            self.space += 1;
        }

        Id(id)
    }
    fn next(&mut self) -> Option<Self::Item> {
        self.ids.next().map(|id| (Id(id), unsafe { self.values.get_unchecked(id) }))
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.min, self.ids.size_hint().1)
    }

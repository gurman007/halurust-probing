    fn fmt(&self, fmt: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt.debug_struct("Slab")
            .field("len", &self.len)
            .field("cap", &self.capacity())
            .finish()
    }

pub enum ASN1DecodeErr {
    EmptyBuffer,
    BadBooleanLength,
    LengthTooLarge,
    UTF8DecodeFailure,
    PrintableStringDecodeFailure,
    InvalidDateValue(String)
}
fn from_der_(i: &[u8], start_offset: usize)
    -> Result<Vec<ASN1Block>,ASN1DecodeErr>
{
    let mut result: Vec<ASN1Block> = Vec::new();
    let mut index:  usize          = 0;
    let     len                    = i.len();

    while index < len {
        let soff = start_offset + index;
        let (tag, class) = decode_tag(i, &mut index);
        let len = decode_length(i, &mut index)?;
        let body = &i[index .. (index + len)];

        match tag.to_u8() {
            // BOOLEAN
            Some(0x01) => {
                if len != 1 {
                    return Err(ASN1DecodeErr::BadBooleanLength);
                }
                result.push(ASN1Block::Boolean(class, soff, body[0] != 0));
            }
            // INTEGER
            Some(0x02) => {
                let res = BigInt::from_signed_bytes_be(&body);
                result.push(ASN1Block::Integer(class, soff, res));
            }
            // BIT STRING
            Some(0x03) if body.len() == 0 => {
                result.push(ASN1Block::BitString(class, soff, 0, Vec::new()))
            }
            Some(0x03) => {
                let bits = (&body[1..]).to_vec();
                let nbits = (bits.len() * 8) - (body[0] as usize);
                result.push(ASN1Block::BitString(class, soff, nbits, bits))
            }
            // OCTET STRING
            Some(0x04) => {
                result.push(ASN1Block::OctetString(class, soff, body.to_vec()))
            }
            // NULL
            Some(0x05) => {
                result.push(ASN1Block::Null(class, soff));
            }
            // OBJECT IDENTIFIER
            Some(0x06) => {
                let mut value1 = BigUint::zero();
                let mut value2 = BigUint::from_u8(body[0]).unwrap();
                let mut oidres = Vec::new();
                let mut bindex = 1;

                if body[0] >= 40 {
                    if body[0] < 80 {
                        value1 = BigUint::one();
                        value2 = value2 - BigUint::from_u8(40).unwrap();
                    } else {
                        value1 = BigUint::from_u8(2).unwrap();
                        value2 = value2 - BigUint::from_u8(80).unwrap();
                    }
                }

                oidres.push(value1);
                oidres.push(value2);
                while bindex < body.len() {
                    oidres.push(decode_base127(body, &mut bindex));
                }
                let res = OID(oidres);

                result.push(ASN1Block::ObjectIdentifier(class, soff, res))
            }
            // UTF8STRING
            Some(0x0C) => {
                match String::from_utf8(body.to_vec()) {
                    Ok(v) =>
                        result.push(ASN1Block::UTF8String(class, soff, v)),
                    Err(_) =>
                        return Err(ASN1DecodeErr::UTF8DecodeFailure)
                }
            }
            // SEQUENCE
            Some(0x10) => {
                match from_der_(body, start_offset + index) {
                    Ok(items) =>
                        result.push(ASN1Block::Sequence(class, soff, items)),
                    Err(e) =>
                        return Err(e)
                }
            }
            // SET
            Some(0x11) => {
                match from_der_(body, start_offset + index) {
                    Ok(items) =>
                        result.push(ASN1Block::Set(class, soff, items)),
                    Err(e) =>
                        return Err(e)
                }
            }
            // PRINTABLE STRING
            Some(0x13) => {
                let mut res = String::new();
                let mut val = body.iter().map(|x| *x as char);

                for c in val {
                    if PRINTABLE_CHARS.contains(c) {
                        res.push(c);
                    } else {
                        return Err(ASN1DecodeErr::PrintableStringDecodeFailure);
                    }
                }
                result.push(ASN1Block::PrintableString(class, soff, res));
            }
            // TELETEX STRINGS
            Some(0x14) => {
                match String::from_utf8(body.to_vec()) {
                    Ok(v) =>
                        result.push(ASN1Block::TeletexString(class, soff, v)),
                    Err(_) =>
                        return Err(ASN1DecodeErr::UTF8DecodeFailure)
                }
            }
            // IA5 (ASCII) STRING
            Some(0x16) => {
                let val = body.iter().map(|x| *x as char);
                let res = String::from_iter(val);
                result.push(ASN1Block::IA5String(class, soff, res))
            }
            // UTCTime
            Some(0x17) => {
                if body.len() != 13 {
                    return Err(ASN1DecodeErr::InvalidDateValue(format!("{}",body.len())));
                }

                let v = String::from_iter(body.iter().map(|x| *x as char));
                match Utc.datetime_from_str(&v, "%y%m%d%H%M%SZ") {
                    Err(_) =>
                        return Err(ASN1DecodeErr::InvalidDateValue(v)),
                    Ok(t) => {
                        result.push(ASN1Block::UTCTime(class, soff, t))
                    }
                }
            }
            // GeneralizedTime
            Some(0x18) => {
                if body.len() < 15 {
                    return Err(ASN1DecodeErr::InvalidDateValue(format!("{}",body.len())));
                }

                let mut v = String::from_iter(body.iter().map(|x| *x as char));
                // We need to add padding back to the string if it's not there.
                if v.find('.').is_none() {
                    v.insert(15, '.')
                }
                while v.len() < 25 {
                    let idx = v.len() - 1;
                    v.insert(idx, '0');
                }
                match Utc.datetime_from_str(&v, "%Y%m%d%H%M%S.%fZ") {
                    Err(_) =>
                        return Err(ASN1DecodeErr::InvalidDateValue(v)),
                    Ok(t) => {
                        result.push(ASN1Block::GeneralizedTime(class, soff, t))
                    }
                }
            }
            // UNIVERSAL STRINGS
            Some(0x1C) => {
                match String::from_utf8(body.to_vec()) {
                    Ok(v) =>
                        result.push(ASN1Block::UniversalString(class, soff, v)),
                    Err(_) =>
                        return Err(ASN1DecodeErr::UTF8DecodeFailure)
                }
            }
            // UNIVERSAL STRINGS
            Some(0x1E) => {
                match String::from_utf8(body.to_vec()) {
                    Ok(v) =>
                        result.push(ASN1Block::BMPString(class, soff, v)),
                    Err(_) =>
                        return Err(ASN1DecodeErr::UTF8DecodeFailure)
                }
            }
            // Dunno.
            _ => {
                result.push(ASN1Block::Unknown(class, soff, tag, body.to_vec()));
            }
        }
        index += len;
    }

    if result.is_empty() {
        Err(ASN1DecodeErr::EmptyBuffer)
    } else {
        Ok(result)
    }
}
fn decode_length(i: &[u8], index: &mut usize) -> Result<usize,ASN1DecodeErr> {
    let startbyte = i[*index];

    // NOTE: Technically, this size can be much larger than a usize.
    // However, our whole universe starts to break down if we get
    // things that big. So we're boring, and only accept lengths
    // that fit within a usize.
    *index += 1;
    if startbyte >= 0x80 {
        let mut lenlen = (startbyte & 0x7f) as usize;
        let mut res = 0;

        if lenlen > size_of::<usize>() {
            return Err(ASN1DecodeErr::LengthTooLarge);
        }

        while lenlen > 0 {
            res = (res << 8) + (i[*index] as usize);

            *index += 1;
            lenlen -= 1;
        }

        Ok(res)
    } else {
        Ok(startbyte as usize)
    }
}
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str(self.description())
    }
    fn description(&self) -> &str {
        match self {
            ASN1EncodeErr::ObjectIdentHasTooFewFields =>
                "ASN1 object identifier has too few fields.",
            ASN1EncodeErr::ObjectIdentVal1TooLarge =>
                "First value in ASN1 OID is too big.",
            ASN1EncodeErr::ObjectIdentVal2TooLarge =>
                "Second value in ASN1 OID is too big."
        }
    }
    fn cause(&self) -> Option<&Error> {
        None
    }
    fn source(&self) -> Option<&(Error + 'static)> {
        None
    }

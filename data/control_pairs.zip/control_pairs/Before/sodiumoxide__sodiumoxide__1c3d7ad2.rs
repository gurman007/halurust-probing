  pub fn crypto_stream_aes128ctr_xor(c: *mut u8,
                                     m: *const u8,
                                     mlen: c_ulonglong,
                                     n: *const u8,
                                     k: *const u8) -> c_int;
  pub fn crypto_stream_salsa20_xor(c: *mut u8,
                                   m: *const u8,
                                   mlen: c_ulonglong,
                                   n: *const u8,
                                   k: *const u8) -> c_int;                              
  pub fn crypto_stream_salsa208_xor(c: *mut u8,
                                    m: *const u8,
                                    mlen: c_ulonglong,
                                    n: *const u8,
                                    k: *const u8) -> c_int;
  pub fn crypto_stream_salsa2012_xor(c: *mut u8,
                                     m: *const u8,
                                     mlen: c_ulonglong,
                                     n: *const u8,
                                     k: *const u8) -> c_int;
  pub fn crypto_stream_xsalsa20_xor(c: *mut u8,
                                    m: *const u8,
                                    mlen: c_ulonglong,
                                    n: *const u8,
                                    k: *const u8) -> c_int;

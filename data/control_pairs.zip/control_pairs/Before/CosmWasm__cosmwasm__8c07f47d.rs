fn check_api_integrity<T: QueryResponses + ?Sized>(
    generated_queries: BTreeSet<String>,
) -> Result<(), IntegrityError> {
    let schema = crate::schema_for!(T);

    // something more readable below?

    let schema_queries: BTreeSet<_> = match schema.schema.subschemas {
        Some(subschemas) => subschemas
            .one_of
            .ok_or(IntegrityError::InvalidQueryMsgSchema)?
            .into_iter()
            .map(|s| {
                s.into_object()
                    .object
                    .ok_or(IntegrityError::InvalidQueryMsgSchema)?
                    .required
                    .into_iter()
                    .next()
                    .ok_or(IntegrityError::InvalidQueryMsgSchema)
            })
            .collect::<Result<_, _>>()?,
        None => BTreeSet::new(),
    };

    if schema_queries != generated_queries {
        return Err(IntegrityError::InconsistentQueries {
            query_msg: schema_queries,
            responses: generated_queries,
        });
    }

    Ok(())
}
    pub enum GoodMsg {
        BalanceFor { account: String },
        Supply {},
    }
        fn response_schemas_impl() -> BTreeMap<String, RootSchema> {
            BTreeMap::from([
                ("balance_for".to_string(), schema_for!(u128)),
                ("supply".to_string(), schema_for!(u128)),
            ])
        }
    fn good_msg_works() {
        let response_schemas = GoodMsg::response_schemas().unwrap();
        assert_eq!(
            response_schemas,
            BTreeMap::from([
                ("balance_for".to_string(), schema_for!(u128)),
                ("supply".to_string(), schema_for!(u128))
            ])
        );
    }

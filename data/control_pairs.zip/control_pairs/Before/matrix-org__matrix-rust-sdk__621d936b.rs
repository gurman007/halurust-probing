    async fn get_utds(
        &self,
        room_id: &RoomId,
        session_id: SessionId<'_>,
    ) -> Result<Vec<(OwnedEventId, Raw<AnySyncTimelineEvent>)>, EventCacheError> {
        let map_timeline_event = |event: TimelineEvent| {
            let event_id = event.event_id();

            // Only pick out events that are UTDs, get just the Raw event as this is what
            // the OlmMachine needs.
            let event =
                as_variant!(event.kind, TimelineEventKind::UnableToDecrypt { event, .. } => event);
            // Zip the event ID and event together so we don't have to pick out the event ID
            // again. We need the event ID to replace the event in the cache.
            event_id.zip(event)
        };

        // Load the relevant events from the event cache store and attempt to redecrypt
        // things.
        let store = self.inner.store.lock().await?;
        let events =
            store.get_room_events(room_id, Some("m.room.encrypted"), Some(session_id)).await?;

        Ok(events.into_iter().filter_map(map_timeline_event).collect())
    }
    async fn subscribe_to_room_key_stream(
        cache: &Weak<EventCacheInner>,
    ) -> Option<impl Stream<Item = Result<Vec<RoomKeyInfo>, BroadcastStreamRecvError>>> {
        let event_cache = cache.upgrade()?;
        let client = event_cache.client().ok()?;
        let machine = client.olm_machine().await;

        machine.as_ref().map(|m| m.store().room_keys_received_stream())
    }
    async fn redecryption_loop(
        cache: &Weak<EventCacheInner>,
        decryption_request_stream: &mut Pin<&mut impl Stream<Item = DecryptionRetryRequest>>,
    ) -> bool {
        let Some(room_key_stream) = Self::subscribe_to_room_key_stream(cache).await else {
            return false;
        };

        pin_mut!(room_key_stream);

        loop {
            tokio::select! {
                // An explicit request, presumably from the timeline, has been received to decrypt
                // events that were encrypted with a certain room key.
                Some(request) = decryption_request_stream.next() => {
                        let Some(cache) = Self::upgrade_event_cache(cache) else {
                            break false;
                        };

                        for session_id in request.utd_session_ids {
                            let _ = cache
                                .retry_decryption(&request.room_id, &session_id)
                                .await
                                .inspect_err(|e| warn!("Error redecrypting after an explicit request was received {e:?}"));
                        }

                        // TODO: Deal with encryption info updating as well.
                }
                // The room key stream from the OlmMachine. Needs to be recreated every time we
                // receive a `None` from the stream.
                room_keys = room_key_stream.next() => {
                    match room_keys {
                        Some(Ok(room_keys)) => {
                            // Alright, some room keys were received and persisted in our store,
                            // let's attempt to redecrypt events that were encrypted using these
                            // room keys.
                            let Some(cache) = Self::upgrade_event_cache(cache) else {
                                break false;
                            };

                            for key in room_keys {
                                let _ = cache
                                    .retry_decryption(&key.room_id, &key.session_id)
                                    .await
                                    .inspect_err(|e| warn!("Error redecrypting {e:?}"));
                            }

                            // TODO: Deal with encryption info updating as well.
                        },
                        Some(Err(_)) => {
                            // We missed some room keys, we need to report this in case a listener
                            // has and idea which UTDs we should attempt to redecrypt.
                            //
                            // This would most likely be the timeline. The timeline might attempt
                            // to redecrypt all UTDs it is showing to the user.
                            let Some(cache) = Self::upgrade_event_cache(cache) else {
                                break false;
                            };

                            let message = RedecryptorReport::Lagging;
                            let _ = cache.inner.redecryption_channels.utd_reporter.send(message);
                        },
                        // The stream got closed, this could mean that our OlmMachine got
                        // regenerated, let's return true and try to recreate the stream.
                        None => {
                            break true
                        }
                    }
                }
                else => break false,
            }
        }
    }

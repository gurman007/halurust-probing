    fn clone(&self) -> Self {
        // We implement `Clone` manually for `StringInterner` to go around the
        // issue of shallow closing the self-referential pinned strs.
        // This was an issue with former implementations. Visit the following
        // link for more information:
        // https://github.com/Robbepop/string-interner/issues/9
        let values = self.values.clone();
        let mut map =
            HashMap::with_capacity_and_hasher(values.len(), self.map.hasher().clone());
        // Recreate `InternalStrRef` from the newly cloned `Box<str>`s.
        // Use `extend()` to avoid `H: Default` trait bound required by `FromIterator for HashMap`.
        map.extend(values.iter().enumerate().map(|(i, s)| {
            (
                PinnedStr::from_str(s),
                S::try_from_usize(i).expect("encountered invalid symbol"),
            )
        }));
        Self { values, map }
    }
    fn next_symbol(&self) -> S {
        S::try_from_usize(self.len()).expect("encountered invalid symbol")
    }
    fn next(&mut self) -> Option<Self::Item> {
        self.iter.next().map(|(num, boxed_str)| {
            (
                S::try_from_usize(num).expect("encountered invalid symbol"),
                Pin::into_inner(boxed_str).into_string(),
            )
        })
    }

    pub fn contains(&self, id: SourceId) -> bool {
        self.map.contains_key(&id)
    }
    pub fn get_by_package_id(&self, pkg_id: PackageId) -> Option<&(dyn Source + 'src)> {
        self.get(pkg_id.source_id())
    }
    pub fn is_empty(&self) -> bool {
        self.map.is_empty()
    }
    pub fn sources<'a>(&'a self) -> impl Iterator<Item = &'a Box<dyn Source + 'src>> {
        self.map.values()
    }

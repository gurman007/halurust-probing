fn read_length<T: io::Read>(reader: &mut T) -> Option<io::Result<u32>> {
    let mut b1: [u8; 1] = unsafe { std::mem::uninitialized() };
    match reader.read_exact(&mut b1[..]) {
        Ok(()) => (),
        Err(ref x) if x.kind() == io::ErrorKind::UnexpectedEof
            => return None,
        Err(x) => return Some(Err(x)),
    }
    if b1[0] & 0x80 != 0 {
        // it is a 31-bit length
        let mut b2: [u8; 3] = unsafe { std::mem::uninitialized() };
        match reader.read_exact(&mut b2[..]) {
            Ok(()) => (),
            Err(x) => return Some(Err(x)),
        }
        Some(Ok((((b1[0] & 0x80) as u32) << 24)
                | ((b2[0] as u32) << 16)
                | ((b2[1] as u32) << 8)
                | ((b2[2] as u32))))
    }
    else {
        // it is a 7-bit length
        Some(Ok(b1[0] as u32))
    }
}
    pub fn new(sock: TcpStream, options: &'a Options) -> Instance<'a, 'z> {
        Instance {
            sock,
            current_reqid: NULL_REQUEST_ID,
            current_input: 0,
            receiver: LowLevelReceiver {
                recvbuf: unsafe { std::mem::uninitialized() },
                recvbufpos: 0,
                recvbufend: 0,
            },
            options,
            keep_conn: true,
            input_has_ended: true,
            remaining_slice_in_input: &[],
            sendbuf: unsafe { std::mem::uninitialized() },
            stdout_pos: 0,
        }
    }

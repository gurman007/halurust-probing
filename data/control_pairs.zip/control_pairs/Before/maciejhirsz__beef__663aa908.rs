    unsafe fn owned_ptr(mut owned: String) -> NonNull<str> {
        let ptr = owned.as_mut_str() as *mut str;

        mem::forget(owned);

        NonNull::new_unchecked(ptr)
    }

    fn next(&mut self) -> Option<Self::Item> {
        self.inner.as_mut().and_then(|c| c.next())
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner
            .as_ref()
            .map_or((0, Some(0)), |ch| ch.size_hint())
    }
    fn next_back(&mut self) -> Option<Self::Item> {
        self.inner.as_mut().and_then(|c| c.next_back())
    }

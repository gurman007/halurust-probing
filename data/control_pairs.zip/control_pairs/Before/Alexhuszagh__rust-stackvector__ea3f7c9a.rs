pub struct StackVec<A: Array> {
    // The capacity field is used for iteration and other optimizations.
    // Publicly expose the fields, so they may be used in constant
    // initialization.
    pub length: usize,
    pub data: mem::ManuallyDrop<A>,
}
    pub fn new() -> StackVec<A> {
        unsafe {
            StackVec {
                length: 0,
                data: mem::uninitialized(),
            }
        }
    }
    pub unsafe fn from_vec_unchecked(mut vec: Vec<A::Item>) -> StackVec<A> {
        let mut data: A = mem::uninitialized();
        let len = vec.len();
        vec.set_len(0);
        ptr::copy_nonoverlapping(vec.as_ptr(), data.ptr_mut(), len);

        StackVec {
            length: len,
            data: mem::ManuallyDrop::new(data),
        }
    }
    pub fn from_buf(buf: A) -> StackVec<A> {
        StackVec {
            length: A::size(),
            data: mem::ManuallyDrop::new(buf),
        }
    }
    pub unsafe fn from_buf_and_len_unchecked(buf: A, len: usize) -> StackVec<A> {
        StackVec {
            length: len,
            data: mem::ManuallyDrop::new(buf),
        }
    }
    pub fn into_inner(self) -> Result<A, Self> {
        if self.len() != A::size() {
            Err(self)
        } else {
            unsafe {
                let data = ptr::read(&self.data);
                mem::forget(self);
                Ok(mem::ManuallyDrop::into_inner(data))
            }
        }
    }
    pub fn from_slice(slice: &[A::Item]) -> Self {
        assert!(slice.len() <= A::size());
        StackVec {
            length: slice.len(),
            data: unsafe {
                let mut data: A = mem::uninitialized();
                ptr::copy_nonoverlapping(slice.as_ptr(), data.ptr_mut(), slice.len());
                mem::ManuallyDrop::new(data)
            }
        }
    }
    fn deref(&self) -> &[A::Item] {
        unsafe {
            slice::from_raw_parts(self.data.ptr(), self.len())
        }
    }
    fn deref_mut(&mut self) -> &mut [A::Item] {
        unsafe {
            slice::from_raw_parts_mut(self.data.ptr_mut(), self.len())
        }
    }
    fn issue_5() {
        assert!(Some(StackVec::<[&u32; 2]>::new()).is_some());
    }

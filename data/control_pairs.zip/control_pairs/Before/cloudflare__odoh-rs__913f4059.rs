    fn identifier(&self) -> Result<Vec<u8>> {
        let buf = compose(self)?;

        let key_id_info = LABEL_KEY_ID.to_vec();
        let prk = Hkdf::<<Kdf as KdfTrait>::HashImpl>::new(None, &buf);
        let mut key_id = [0; KDF_OUTPUT_SIZE];
        prk.expand(&key_id_info, &mut key_id)
            .map_err(|_| Error::from(HpkeError::InvalidKdfLength))?;
        Ok(key_id.to_vec())
    }

    fn copy_from_toodee(&mut self, src: &impl TooDeeOps<T>) where T : Copy {
        assert_eq!(self.size(), src.size());
        let num_cols = self.num_cols();
        let mut v = self.data_mut();
        for r in src.rows() {
            let (fst, snd) = v.split_at_mut(num_cols);
            fst.copy_from_slice(r);
            v = snd;
        }
    }
    fn clone_from_toodee(&mut self, src: &impl TooDeeOps<T>) where T : Clone {
        assert_eq!(self.size(), src.size());
        let num_cols = self.num_cols();
        let mut v = self.data_mut();
        for r in src.rows() {
            let (fst, snd) = v.split_at_mut(num_cols);
            fst.clone_from_slice(r);
            v = snd;
        }
    }
    fn is_empty(&self) -> bool {
        self.num_cols() == 0 || self.num_rows() == 0
    }
    fn swap_cols(&mut self, c1: usize, c2: usize) {
        let num_cols = self.num_cols();
        assert!(c1 < num_cols);
        assert!(c2 < num_cols);
        for r in self.rows_mut() {
            r.swap(c1, c2);
        }
    }
    fn swap_rows(&mut self, r1: usize, r2: usize) {
        let num_rows = self.num_rows();
        assert!(r1 < num_rows);
        assert!(r2 < num_rows);
        match r1.cmp(&r2) {
            Ordering::Less => {
                let mut iter = self.rows_mut();
                let tmp = iter.nth(r1).unwrap();
                tmp.swap_with_slice(iter.nth(r2-r1-1).unwrap());
            },
            Ordering::Greater => {
                let mut iter = self.rows_mut();
                let tmp = iter.nth(r2).unwrap();
                tmp.swap_with_slice(iter.nth(r1-r2-1).unwrap());
            },
            Ordering::Equal => {},
        }
    }
    fn row_pair_mut(&mut self, r1: usize, r2: usize) -> (&mut [T], &mut [T]) {
        let num_rows = self.num_rows();
        assert!(r1 < num_rows);
        assert!(r2 < num_rows);
        assert!(r1 != r2);
        match r1.cmp(&r2) {
            Ordering::Less => {
                let mut iter = self.rows_mut();
                let tmp = iter.nth(r1).unwrap();
                (tmp, iter.nth(r2-r1-1).unwrap())
            },
            Ordering::Greater => {
                let mut iter = self.rows_mut();
                let tmp = iter.nth(r2).unwrap();
                (iter.nth(r1-r2-1).unwrap(), tmp)
            },
            Ordering::Equal => {
                unreachable!("r1 != r2");
            },
        }
    }
    fn zero_size_toodee() {
        let mut toodee = TooDee::init(0, 0, 0u32);
        assert!(toodee.is_empty());
        assert_eq!(toodee.rows_mut().next(), None);
        assert_eq!(toodee.rows().next(), None);
        assert_eq!(toodee.cells().next(), None);
        assert_eq!(toodee.cells_mut().next(), None);
    }
    fn zero_size_view() {
        let mut toodee = TooDee::init(10, 10, 0u32);
        let mut view = toodee.view_mut((5, 5), (5, 5));
        assert!(view.is_empty());
        assert_eq!(view.rows_mut().next(), None);
        assert_eq!(view.rows().next(), None);
        assert_eq!(view.cells().next(), None);
        assert_eq!(view.cells_mut().next(), None);
        view = toodee.view_mut((5, 5), (6, 5));
        assert_eq!(view.rows_mut().next(), None);
        assert_eq!(view.rows().next(), None);
        assert_eq!(view.cells().next(), None);
        assert_eq!(view.cells_mut().next(), None);
        view = toodee.view_mut((5, 5), (5, 6));
        assert_eq!(view.rows_mut().next(), None);
        assert_eq!(view.rows().next(), None);
        assert_eq!(view.cells().next(), None);
        assert_eq!(view.cells_mut().next(), None);
    }
    fn copy_from_toodee() {
        let toodee = TooDee::from_vec(10, 10, (0u32..100).collect());
        let mut dest : TooDee<u32> = TooDee::new(10, 10);
        dest.copy_from_toodee(&toodee);
        assert_eq!(dest.data().iter().sum::<u32>(), (100*100 - 100) / 2);
    }
    fn clone_from_toodee() {
        let toodee = TooDee::from_vec(10, 10, (0u32..100).collect());
        let mut dest : TooDee<u32> = TooDee::new(10, 10);
        dest.clone_from_toodee(&toodee);
        assert_eq!(dest.data().iter().sum::<u32>(), (100*100 - 100) / 2);
    }
    fn view_copy_from_toodee() {
        let toodee = TooDee::from_vec(10, 10, (0u32..100).collect());
        let mut dest : TooDee<u32> = TooDee::new(10, 10);
        dest.view_mut((0, 0), (10, 10)).copy_from_toodee(&toodee);
        assert_eq!(dest.data().iter().sum::<u32>(), (100*100 - 100) / 2);
    }
    fn view_clone_from_toodee() {
        let toodee = TooDee::from_vec(10, 10, (0u32..100).collect());
        let mut dest : TooDee<u32> = TooDee::new(10, 10);
        dest.view_mut((0, 0), (10, 10)).clone_from_toodee(&toodee);
        assert_eq!(dest.data().iter().sum::<u32>(), (100*100 - 100) / 2);
    }

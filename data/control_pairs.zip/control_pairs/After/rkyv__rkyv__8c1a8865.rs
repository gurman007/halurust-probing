    fn partial_ord_option() {
        use core::cmp::Ordering;

        use super::ArchivedOption;

        let a: ArchivedOption<u8> = ArchivedOption::Some(42);
        let b = Some(42);
        assert_eq!(Some(Ordering::Equal), a.partial_cmp(&b));
        #[cfg(feature = "extra_traits")]
        assert_eq!(Some(Ordering::Equal), b.partial_cmp(&a));

        let a: ArchivedOption<u8> = ArchivedOption::Some(1);
        let b = Some(2);
        assert_eq!(Some(Ordering::Less), a.partial_cmp(&b));
        #[cfg(feature = "extra_traits")]
        assert_eq!(Some(Ordering::Greater), b.partial_cmp(&a));

        let a: ArchivedOption<u8> = ArchivedOption::Some(2);
        let b = Some(1);
        assert_eq!(Some(Ordering::Greater), a.partial_cmp(&b));
        #[cfg(feature = "extra_traits")]
        assert_eq!(Some(Ordering::Less), b.partial_cmp(&a));
    }
impl<T, U, E, F> PartialEq<ArchivedResult<T, E>> for Result<U, F>
where
    T: PartialEq<U>,
    E: PartialEq<F>,
{
    #[inline]
    fn eq(&self, other: &ArchivedResult<T, E>) -> bool {
        other.eq(self)
    }
}
impl<T, U: PartialEq<T>, E, F: PartialEq<E>> PartialEq<Result<T, E>>
    for ArchivedResult<U, F>
{
    #[inline]
    fn eq(&self, other: &Result<T, E>) -> bool {
        match self {
            ArchivedResult::Ok(self_value) => {
                if let Ok(other_value) = other {
                    self_value.eq(other_value)
                } else {
                    false
                }
            }
            ArchivedResult::Err(self_err) => {
                if let Err(other_err) = other {
                    self_err.eq(other_err)
                } else {
                    false
                }
            }
        }
    }
}

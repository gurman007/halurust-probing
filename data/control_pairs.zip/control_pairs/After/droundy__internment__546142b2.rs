struct RcI<T: Hash+Eq+PartialEq> {
    data: HashSet<Box<T>>,
    counts: HashMap<Intern<T>, usize>,
}
    pub fn new(val: T) -> ArcIntern<T> {
        let mymutex = match CONTAINER.try_get::<Mutex<RcI<T>>>() {
            Some(m) => m,
            None => {
                CONTAINER.set::<Mutex<RcI<T>>>(Mutex::new(
                    RcI {
                        data: HashSet::<Box<T>>::new(),
                        counts: HashMap::<Intern<T>,usize>::new(),
                    }));
                CONTAINER.get::<Mutex<RcI<T>>>()
            },
        };
        let mut m = mymutex.lock().unwrap();
        let mut result = None;
        if let Some(b) = m.data.get(&val) {
            result = Some( ArcIntern { pointer: b.borrow() } );
            // need to increment the count for this!
        }
        if let Some(ai) = result {
            if let Some(mc) = m.counts.get_mut(&Intern{ pointer: ai.pointer }) {
                *mc += 1;
            }
            return ai;
        }
        let b = Box::new(val);
        let p: *const T = b.borrow();
        m.counts.insert(Intern { pointer: p }, 1);
        m.data.insert(b);
        ArcIntern { pointer: p }
    }
    fn drop(&mut self) {
        let mut m = CONTAINER.get::<Mutex<RcI<T>>>().lock().unwrap();
        let mut am_finished = false;
        if let Some(mc) = m.counts.get_mut(&Intern{ pointer: self.pointer }) {
            *mc -= 1;
            if *mc == 0 {
                am_finished = true;
            }
        }
        if am_finished {
            m.data.remove(&**self);
            m.counts.remove(&Intern{ pointer: self.pointer });
        }
    }

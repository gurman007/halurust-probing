    unsafe fn owned_ptr(mut owned: Vec<T>) -> NonNull<[T]> {
        let ptr = owned.as_mut_ptr();
        let len = owned.len();

        mem::forget(owned);

        NonNull::new_unchecked(slice_from_raw_parts_mut(ptr, len))
    }
    pub fn owned(val: B::Owned) -> Self {
        let capacity = B::capacity(&val);
        let inner = unsafe { B::owned_ptr(val) };

        Cow {
            inner,
            capacity,
            marker: PhantomData,
        }
    }

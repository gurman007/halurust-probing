pub(crate) fn utf8_decode(bytes: &[u8]) -> Option<Result<char, u8>> {
    if bytes.is_empty() {
        return None;
    }
    match core::str::from_utf8(&bytes[..core::cmp::min(4, bytes.len())]) {
        Ok(s) => Some(Ok(s.chars().next().unwrap())),
        Err(_) => Some(Err(bytes[0])),
    }
}
    pub fn alternation(hirs: Vec<Hir>) -> Hir {
        // We rebuild the alternation by simplifying it. We proceed similarly
        // as the concatenation case. But in this case, there's no literal
        // simplification happening. We're just flattening alternations.
        let mut new = vec![];
        for hir in hirs {
            let (kind, props) = hir.into_parts();
            match kind {
                HirKind::Alternation(hirs2) => {
                    new.extend(hirs2);
                }
                kind => {
                    new.push(Hir { kind, props });
                }
            }
        }
        if new.is_empty() {
            return Hir::fail();
        } else if new.len() == 1 {
            return new.pop().unwrap();
        }
        // Now that it's completely flattened, look for the special case of
        // 'char1|char2|...|charN' and collapse that into a class. Note that we
        // look for 'char' first and then bytes. The issue here is that if we
        // find both non-ASCII codepoints and non-ASCII singleton bytes, then
        // it isn't actually possible to smush them into a single class. So we
        // look for all chars and then all bytes, and don't handle anything
        // else.
        if let Some(singletons) = singleton_chars(&new) {
            let it = singletons
                .into_iter()
                .map(|ch| ClassUnicodeRange { start: ch, end: ch });
            return Hir::class(Class::Unicode(ClassUnicode::new(it)));
        }
        if let Some(singletons) = singleton_bytes(&new) {
            let it = singletons
                .into_iter()
                .map(|b| ClassBytesRange { start: b, end: b });
            return Hir::class(Class::Bytes(ClassBytes::new(it)));
        }
        let props = Properties::alternation(&new);
        Hir { kind: HirKind::Alternation(new), props }
    }
fn singleton_chars(hirs: &[Hir]) -> Option<Vec<char>> {
    let mut singletons = vec![];
    for hir in hirs.iter() {
        let literal = match *hir.kind() {
            HirKind::Literal(Literal(ref bytes)) => bytes,
            _ => return None,
        };
        let ch = match crate::debug::utf8_decode(literal) {
            None => return None,
            Some(Err(_)) => return None,
            Some(Ok(ch)) => ch,
        };
        if literal.len() != ch.len_utf8() {
            return None;
        }
        singletons.push(ch);
    }
    Some(singletons)
}
fn singleton_bytes(hirs: &[Hir]) -> Option<Vec<u8>> {
    let mut singletons = vec![];
    for hir in hirs.iter() {
        let literal = match *hir.kind() {
            HirKind::Literal(Literal(ref bytes)) => bytes,
            _ => return None,
        };
        if literal.len() != 1 {
            return None;
        }
        singletons.push(literal[0]);
    }
    Some(singletons)
}
    fn print_alternation() {
        roundtrip("|", "(?:|)");
        roundtrip("||", "(?:||)");

        roundtrip("a|b", "[ab]");
        roundtrip("ab|cd", "(?:(?:ab)|(?:cd))");
        roundtrip("a|b|c", "[a-c]");
        roundtrip("ab|cd|ef", "(?:(?:ab)|(?:cd)|(?:ef))");
        roundtrip("foo|bar|quux", "(?:(?:foo)|(?:bar)|(?:quux))");
    }
    fn regression_repetition_alternation() {
        let expr = Hir::concat(alloc::vec![
            Hir::literal("ab".as_bytes()),
            Hir::repetition(hir::Repetition {
                min: 1,
                max: None,
                greedy: true,
                hir: Box::new(Hir::alternation(alloc::vec![
                    Hir::literal("cd".as_bytes()),
                    Hir::literal("ef".as_bytes()),
                ])),
            }),
            Hir::literal("gh".as_bytes()),
        ]);
        assert_eq!(r"(?:(?:ab)(?:(?:cd)|(?:ef))+(?:gh))", expr.to_string());

        let expr = Hir::concat(alloc::vec![
            Hir::look(hir::Look::Start),
            Hir::repetition(hir::Repetition {
                min: 1,
                max: None,
                greedy: true,
                hir: Box::new(Hir::alternation(alloc::vec![
                    Hir::look(hir::Look::Start),
                    Hir::look(hir::Look::End),
                ])),
            }),
            Hir::look(hir::Look::End),
        ]);
        assert_eq!(r"(?:\A(?:\A|\z)+\z)", expr.to_string());
    }
    fn regression_alternation_concat() {
        let expr = Hir::concat(alloc::vec![
            Hir::literal("ab".as_bytes()),
            Hir::alternation(alloc::vec![
                Hir::literal("mn".as_bytes()),
                Hir::literal("xy".as_bytes()),
            ]),
        ]);
        assert_eq!(r"(?:(?:ab)(?:(?:mn)|(?:xy)))", expr.to_string());

        let expr = Hir::concat(alloc::vec![
            Hir::look(hir::Look::Start),
            Hir::alternation(alloc::vec![
                Hir::look(hir::Look::Start),
                Hir::look(hir::Look::End),
            ]),
        ]);
        assert_eq!(r"(?:\A(?:\A|\z))", expr.to_string());
    }
    fn analysis_is_alternation_literal() {
        // Positive examples.
        assert!(props(r"a").is_alternation_literal());
        assert!(props(r"ab").is_alternation_literal());
        assert!(props(r"abc").is_alternation_literal());
        assert!(props(r"(?m)abc").is_alternation_literal());
        assert!(props(r"foo|bar").is_alternation_literal());
        assert!(props(r"foo|bar|baz").is_alternation_literal());
        assert!(props(r"[a]").is_alternation_literal());
        assert!(props(r"(?:ab)|cd").is_alternation_literal());
        assert!(props(r"ab|(?:cd)").is_alternation_literal());

        // Negative examples.
        assert!(!props(r"").is_alternation_literal());
        assert!(!props(r"^").is_alternation_literal());
        assert!(!props(r"(a)").is_alternation_literal());
        assert!(!props(r"a+").is_alternation_literal());
        assert!(!props(r"foo(a)").is_alternation_literal());
        assert!(!props(r"(a)foo").is_alternation_literal());
        assert!(!props(r"[ab]").is_alternation_literal());
        assert!(!props(r"[ab]|b").is_alternation_literal());
        assert!(!props(r"a|[ab]").is_alternation_literal());
        assert!(!props(r"(a)|b").is_alternation_literal());
        assert!(!props(r"a|(b)").is_alternation_literal());
        assert!(!props(r"a|b").is_alternation_literal());
        assert!(!props(r"a|b|c").is_alternation_literal());
        assert!(!props(r"[a]|b").is_alternation_literal());
        assert!(!props(r"a|[b]").is_alternation_literal());
        assert!(!props(r"(?:a)|b").is_alternation_literal());
        assert!(!props(r"a|(?:b)").is_alternation_literal());
    }
    fn smart_alternation() {
        assert_eq!(
            t("(?:foo)|(?:bar)"),
            hir_alt(vec![hir_lit("foo"), hir_lit("bar")])
        );
        assert_eq!(
            t("quux|(?:abc|def|xyz)|baz"),
            hir_alt(vec![
                hir_lit("quux"),
                hir_lit("abc"),
                hir_lit("def"),
                hir_lit("xyz"),
                hir_lit("baz"),
            ])
        );
        assert_eq!(
            t("quux|(?:abc|(?:def|mno)|xyz)|baz"),
            hir_alt(vec![
                hir_lit("quux"),
                hir_lit("abc"),
                hir_lit("def"),
                hir_lit("mno"),
                hir_lit("xyz"),
                hir_lit("baz"),
            ])
        );
        assert_eq!(
            t("a|b|c|d|e|f|x|y|z"),
            hir_uclass(&[('a', 'f'), ('x', 'z')]),
        );
    }

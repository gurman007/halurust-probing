    pub(super) fn new(
        extra_exts: ServerExtensionsInput,
        ocsp_response: &mut Option<&[u8]>,
        resumedata: Option<&CommonServerSessionValue>,
        hello: &ClientHelloPayload,
        output: &mut dyn Output,
        using_ems: bool,
        config: &ServerConfig,
    ) -> Result<(Tls12Extensions, Box<ServerExtensions<'static>>), Error> {
        let mut ep = ExtensionProcessing::new(extra_exts, Protocol::Tcp, hello, config);
        let (_, alpn_protocol) = ep.process_common(output, ocsp_response, resumedata)?;

        // Renegotiation.
        // (We don't do reneg at all, but would support the secure version if we did.)
        if hello.renegotiation_info.is_some()
            || hello
                .cipher_suites
                .contains(&CipherSuite::TLS_EMPTY_RENEGOTIATION_INFO_SCSV)
        {
            ep.extensions.renegotiation_info = Some(Vec::new().into());
        }

        // Tickets:
        // If we get any SessionTicket extension and have tickets enabled,
        // we send an ack.
        if hello.session_ticket.is_some() && config.ticketer.is_some() {
            ep.send_ticket = true;
            ep.extensions.session_ticket_ack = Some(());
        }

        // Confirm use of EMS if offered.
        if using_ems {
            ep.extensions.extended_master_secret_ack = Some(());
        }

        // Send confirmation of OCSP staple request if we will send one.
        if let Some([_, ..]) = ocsp_response {
            ep.extensions
                .certificate_status_request_ack = Some(());
        }

        let out = Self {
            alpn_protocol,
            send_ticket: ep.send_ticket,
        };

        Ok((out, ep.extensions))
    }

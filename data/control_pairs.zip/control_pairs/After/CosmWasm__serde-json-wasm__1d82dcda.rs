    fn parse_string(&mut self) -> Result<String> {
        let start = self.index;
        let mut contains_backslash = false;
        let mut escaped = false;
        loop {
            match self.peek() {
                Some(b'"') => {
                    if escaped {
                        escaped = false;
                        self.eat_char(); // just continue
                    } else {
                        let end = self.index;
                        self.eat_char();
                        return if contains_backslash {
                            unescape::unescape(&self.slice[start..end])
                        } else {
                            String::from_utf8(Vec::from(&self.slice[start..end]))
                                .map_err(|_| Error::InvalidUnicodeCodePoint)
                        };
                    }
                }
                Some(b'\\') => {
                    contains_backslash = true;
                    escaped = !escaped;
                    self.eat_char()
                }
                Some(_) => {
                    escaped = false;
                    self.eat_char()
                }
                None => return Err(Error::EofWhileParsingString),
            }
        }
    }

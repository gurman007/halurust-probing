pub trait Flatten {
    fn as_u32(&self) -> u32;
}
impl Flatten for u32 {
    fn as_u32(&self) -> u32 {
        *self
    }
}
pub struct LinearFront<K, T> where T: Flatten {
    witness: PhantomData<T>,
    back_end: BackEnd<K>,
    min: u32,
    max: u32, // Invariant: max > min
    buckets: u32 // Invariant: sizeof(u32) <= sizeof(usize)
}
impl<K, T> LinearFront<K, T> where T: Flatten {
    fn get_bucket(&self, value: T) -> u32 {
        let value = value.as_u32();
        if value >= self.max {
            0
        } else if value <= self.min {
            self.buckets - 1 as u32
        } else {
            let num = value as f32 - self.min as f32;
            let den = self.max as f32 - self.min as f32;
            let res = (num / den) * self.buckets as f32;
            res as u32
        }
    }
}
impl<T> LinearSingle<T> where T: Flatten {
    fn new(feature: &Feature, meta: Metadata, min: u32, max: u32, buckets: usize) -> LinearSingle<T> {
        assert!(size_of::<u32>() <= size_of::<usize>());
        assert!(min < max);
        assert!(max - min >= buckets as u32);
        let storage = Box::new(LinearStorage::new(buckets));
        let key = feature.telemetry.register_flat(meta, storage);
        LinearFront {
            witness: PhantomData,
            back_end: BackEnd::new(feature, key),
            min: min,
            max: max,
            buckets: buckets as u32
        }
    }
}
impl<K, T> HistogramMap<K, T> for LinearMap<K, T> where K: ToString, T: Flatten {
    fn record_cb<F>(&self, cb: F) where F: FnOnce() -> Option<(K, T)>  {
        if let Some(k) = self.back_end.get_key() {
            match cb() {
                None => {}
                Some((key, v)) => self.back_end.raw_record(&k, key.to_string(), self.get_bucket(v))
            }
        }
    }
}

        fn call(&mut self, req: Request<()>) -> Self::Future {
            let user_agent = req.headers().get(USER_AGENT).unwrap().to_str().unwrap();
            assert_eq!(user_agent, self.expected_user_agent);
            std::future::ready(Ok(()))
        }
        fn poll_ready(&mut self, _cx: &mut Context<'_>) -> Poll<Result<(), Self::Error>> {
            Poll::Ready(Ok(()))
        }
    async fn sets_default_user_agent_if_none_present() {
        let expected_user_agent = TONIC_USER_AGENT.to_string();
        let mut ua = UserAgent::new(
            TestSvc {
                expected_user_agent,
            },
            None,
        );
        let _ = ua.call(Request::default()).await;
    }
    async fn sets_custom_user_agent_if_none_present() {
        let expected_user_agent = format!("Greeter 1.1 {}", TONIC_USER_AGENT);
        let mut ua = UserAgent::new(
            TestSvc {
                expected_user_agent,
            },
            Some(HeaderValue::from_static("Greeter 1.1")),
        );
        let _ = ua.call(Request::default()).await;
    }
    async fn appends_default_user_agent_to_request_user_agent() {
        let mut req = Request::default();
        req.headers_mut()
            .insert(USER_AGENT, HeaderValue::from_static("request-ua/x.y"));

        let expected_user_agent = format!("request-ua/x.y {}", TONIC_USER_AGENT);
        let mut ua = UserAgent::new(
            TestSvc {
                expected_user_agent,
            },
            None,
        );
        let _ = ua.call(req).await;
    }
    async fn appends_custom_user_agent_to_request_user_agent() {
        let mut req = Request::default();
        req.headers_mut()
            .insert(USER_AGENT, HeaderValue::from_static("request-ua/x.y"));

        let expected_user_agent = format!("request-ua/x.y Greeter 1.1 {}", TONIC_USER_AGENT);
        let mut ua = UserAgent::new(
            TestSvc {
                expected_user_agent,
            },
            Some(HeaderValue::from_static("Greeter 1.1")),
        );
        let _ = ua.call(req).await;
    }
    fn prepends_custom_user_agent_to_default() {
        assert_eq!(
            UserAgent::new(Svc, Some(HeaderValue::from_static("Greeter 1.1"))).user_agent,
            HeaderValue::from_str(&format!("Greeter 1.1 {}", TONIC_USER_AGENT)).unwrap()
        )
    }

    fn extend_desugared<I: Iterator<Item = T>>(&mut self, mut iterator: I) {
        #[cfg_attr(
            feature = "cargo-clippy",
            allow(clippy::while_let_on_iterator)
        )]
        while let Some(element) = iterator.next() {
            let len = self.len();
            let cap = self.capacity();
            if len == cap {
                let (lower, upper) = iterator.size_hint();
                let additional_cap = if let Some(upper) = upper {
                    upper
                } else {
                    lower
                }
                .checked_add(1)
                .expect("overflow");
                self.reserve(additional_cap);
            }
            debug_assert!(self.len() < self.capacity());
            unsafe {
                ptr::write(self.get_unchecked_mut(len), element);
                // NB can't overflow since we would have had to alloc the
                // address space
                self.move_tail_unchecked(1);
            }
        }
    }
    fn from_iter(iterator: IntoIter<T>) -> Self {
        // A common case is passing a deque into a function which immediately
        // re-collects into a deque. We can short circuit this if the IntoIter
        // has not been advanced at all.
        if iterator.buf.as_ptr() as *const _ == iterator.ptr {
            unsafe {
                let deq = Self::from_raw_parts(
                    iterator.buf.as_ptr(),
                    iterator.cap,
                    iterator.head(),
                    iterator.tail(),
                );
                #[cfg_attr(
                    feature = "cargo-clippy", allow(clippy::mem_forget)
                )]
                mem::forget(iterator);
                deq
            }
        } else {
            let mut deque = Self::new();
            deque.spec_extend(iterator);
            deque
        }
    }

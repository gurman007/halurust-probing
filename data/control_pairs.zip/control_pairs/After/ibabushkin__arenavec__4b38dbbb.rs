    pub fn split_off(&mut self, at: usize) -> Self
        where H: Clone,
    {
        let mut ret = Self::with_capacity(self.slice.handle.clone(), self.slice.len - at);
        ret.slice.len = self.slice.len - at;

        unsafe {
            ptr::copy_nonoverlapping(
                self.slice.ptr.as_ptr().add(at),
                ret.slice.ptr.as_ptr(),
                ret.len());
        }

        ret
    }

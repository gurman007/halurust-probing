    pub fn from_conduit<H: conduit::Handler>(
        handler: Arc<H>,
        remote_addr: std::net::SocketAddr,
    ) -> Result<
        impl tower_service::Service<
            Request<Body>,
            Response = Response<Body>,
            Error = hyper::Error,
            Future = impl Future<Output = Result<Response<Body>, hyper::Error>> + Send + 'static,
        >,
        hyper::Error,
    > {
        Ok(service::service_fn(move |request: Request<Body>| {
            blocking_handler(handler.clone(), request, remote_addr)
        }))
    }
fn make_service<H: Handler>(
    handler: H,
) -> impl Service<
    hyper::Body,
    ResBody = hyper::Body,
    Future = impl Future<Output = Result<hyper::Response<hyper::Body>, hyper::Error>> + Send + 'static,
    Error = hyper::Error,
> {
    use hyper::service::service_fn;

    let handler = std::sync::Arc::new(handler);

    service_fn(move |request: hyper::Request<hyper::Body>| {
        let remote_addr = ([0, 0, 0, 0], 0).into();
        super::blocking_handler(handler.clone(), request, remote_addr)
    })
}

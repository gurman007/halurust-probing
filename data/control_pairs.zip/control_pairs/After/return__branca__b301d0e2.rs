pub fn decode(data: &str, key: &[u8], ttl: u32) -> Result<String, BrancaError> {
    let sk: SecretKey = match SecretKey::from_slice(key) {
        Ok(key) => key,
        Err(UnknownCryptoError) => return Err(BrancaError::BadKeyLength),
    };

    if data.len() < 62 {
        return Err(BrancaError::InvalidBase62Token);
    }

    let decoded_data = b62_decode(BASE62, &data).expect("Base62 token is invalid.");

    // After we have decoded the data, the branca token is now represented
    // by the following layout below:

    // Branca( header[0..29] + ciphertext[29..] )
    // Version (&u8) || Timestamp (u32) || Nonce ([u8;24]) || Ciphertext (&[u8]) || Tag ([u8:16])

    // We then obtain the header, ciphertext, version and timestamp with this layout.

    // Check if there is a version mismatch.
    if decoded_data[0] != VERSION {
        return Err(BrancaError::InvalidTokenVersion);
    }

    let header = &decoded_data[0..29];
    let timestamp: u32 = BigEndian::read_u32(&decoded_data[1..5]);

    // TTL check to determine if the token has expired.
    if ttl != 0 {
        let future = timestamp.checked_add(ttl).expect("TTL too high.") as u64;
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("Failed to obtain timestamp from system clock.")
            .as_secs();
        if future < now {
            return Err(BrancaError::ExpiredToken);
        }
    }

    let n: Nonce = Nonce::from_slice(decoded_data[5..29].as_ref()).unwrap();
    let mut buf_crypt = vec![0u8; decoded_data.len() - 16 - 29];

    match open(
        &sk,
        &n,
        decoded_data[29..].as_ref(),
        Some(header),
        &mut buf_crypt,
    ) {
        Ok(()) => (),
        Err(orion::errors::UnknownCryptoError) => return Err(BrancaError::DecryptFailed),
    };

    // Return the plaintext.
    Ok(String::from_utf8_lossy(&buf_crypt).into())
}
    pub fn test_encode_and_decode() {
        let message = "Hello world!";
        let timestamp = 123206400;
        let branca_token = encode(
            message,
            &b"supersecretkeyyoushouldnotcommit".to_vec(),
            timestamp,
        )
        .unwrap();

        assert_eq!(
            decode(
                branca_token.as_str(),
                &b"supersecretkeyyoushouldnotcommit".to_vec(),
                0
            )
            .unwrap(),
            "Hello world!"
        );
    }
    pub fn test_encode_and_decode_random_nonce() {
        let message = "Hello world!";
        let timestamp = 123206400;
        let branca_token = encode(
            message,
            &b"supersecretkeyyoushouldnotcommit".to_vec(),
            timestamp,
        )
        .unwrap();

        assert_eq!(
            decode(
                branca_token.as_str(),
                &b"supersecretkeyyoushouldnotcommit".to_vec(),
                0
            )
            .unwrap(),
            "Hello world!"
        );
    }
    pub fn test_encode_and_decode_json() {
        let literal_json = json!({ "a": "some string", "b": false });
        let message = literal_json.to_string();
        let timestamp = 123206400;
        let branca_token = encode(
            message.as_str(),
            &b"supersecretkeyyoushouldnotcommit".to_vec(),
            timestamp,
        )
        .unwrap();
        let json = decode(
            branca_token.as_str(),
            &b"supersecretkeyyoushouldnotcommit".to_vec(),
            0,
        )
        .unwrap();
        let serialized_json: JSONTest = serde_json::from_str(json.as_str()).unwrap();

        assert_eq!(serialized_json.a, "some string");
        assert_eq!(serialized_json.b, false);
    }

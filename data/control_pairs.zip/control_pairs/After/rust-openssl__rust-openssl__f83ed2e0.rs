        pub struct X509_REVOKED {
            pub serialNumber: *mut ASN1_INTEGER,
            pub revocationDate: *mut ASN1_TIME,
            pub extensions: *mut stack_st_X509_EXTENSION,
            issuer: *mut stack_st_GENERAL_NAME,
            reason: c_int,
            sequence: c_int,
        }
    pub fn X509_REVOKED_dup(rev: *mut X509_REVOKED) -> *mut X509_REVOKED;
    pub fn X509_REVOKED_set_serialNumber(r: *mut X509_REVOKED, serial: *mut ASN1_INTEGER) -> c_int;
    pub fn X509_REVOKED_set_revocationDate(r: *mut X509_REVOKED, tm: *mut ASN1_TIME) -> c_int;
    pub fn X509_REVOKED_free(x: *mut X509_REVOKED);

    pub fn run(&self, opts: &super::RunOpts) -> Result<(), Error> {
        let buf;
        let input = match &self.strkey {
            Some(s) => s.trim(),
            None => {
                let stdin = std::io::stdin();
                if stdin.is_terminal() {
                    return Err(Error::NoInput);
                }
                // Allow some headroom over the longest valid strkey so that
                // common trailing whitespace (e.g. \n, \r\n) is accepted.
                // Anything beyond that is rejected outright rather than
                // silently truncated.
                let max = Strkey::MAX_ENCODED_LEN + 16;
                let mut s = String::new();
                stdin
                    .lock()
                    .take(max as u64 + 1)
                    .read_to_string(&mut s)
                    .map_err(Error::Io)?;
                if s.len() > max {
                    return Err(Error::InputTooLarge { len: s.len(), max });
                }
                buf = s;
                buf.trim()
            }
        };
        let strkey = Strkey::from_str(input).map_err(|e| Error::Decode(input.to_string(), e))?;
        if !opts.quiet {
            super::warn_if_private(&strkey);
        }
        let json = serde_json::to_string_pretty(&Decoded(&strkey)).unwrap();
        println!("{json}");
        Ok(())
    }
    pub fn run(&self, opts: &super::RunOpts) -> Result<(), Error> {
        let buf;
        let input = match &self.json {
            Some(s) => s.as_str(),
            None => {
                let stdin = std::io::stdin();
                if stdin.is_terminal() {
                    return Err(Error::NoInput);
                }
                let mut s = String::new();
                stdin
                    .lock()
                    .take(MAX_JSON_LEN as u64 + 1)
                    .read_to_string(&mut s)
                    .map_err(Error::Io)?;
                buf = s;
                buf.as_str()
            }
        };
        if input.len() > MAX_JSON_LEN {
            return Err(Error::InputTooLarge {
                len: input.len(),
                max: MAX_JSON_LEN,
            });
        }
        let Decoded(strkey): Decoded<Strkey> = serde_json::from_str(input).map_err(Error::Json)?;
        if !opts.quiet {
            super::warn_if_private(&strkey);
        }
        println!("{strkey}");
        Ok(())
    }
pub struct Root {
    #[command(subcommand)]
    cmd: Cmd,
    /// Suppress stderr log and warning output
    #[arg(long, short = 'q', global = true)]
    quiet: bool,
}
pub struct RunOpts {
    pub quiet: bool,
}
    pub fn run(&self) -> Result<(), Error> {
        let opts = RunOpts { quiet: self.quiet };
        match &self.cmd {
            Cmd::Decode(c) => c.run(&opts)?,
            Cmd::Encode(c) => c.run(&opts)?,
            Cmd::Zero(c) => c.run(),
            Cmd::Version => version::Cmd::run(),
        }
        Ok(())
    }
pub(crate) fn warn_if_private(strkey: &Strkey) {
    if matches!(strkey, Strkey::PrivateKeyEd25519(_)) {
        eprintln!(
            "⚠️  Warning: output contains a private key with secret material. Handle with care."
        );
    }
}

pub async fn prompt(_cfg: &Config) -> Result<()> {
    print!("Welcome to the Svix CLI!\n\n");

    let auth_token = prompt_for_auth_token().await?;
    let fp = save_auth_token(auth_token)?;

    println!(
        "All Set! Your config has been written to `{}`",
        fp.display()
    );
    println!(
        "Type `{} --help` to print the Svix CLI documentation!",
        crate::BIN_NAME
    );
    Ok(())
}
pub async fn prompt_for_auth_token() -> Result<String> {
    let selections = &["Login in dashboard.svix.com", "Input token manually"];
    let selection = dialoguer::Select::new()
        .with_prompt("How would you like to authenticate?")
        .items(selections)
        .default(0)
        .interact()?;

    let auth_token = if selection == 0 {
        dashboard_login().await?
    } else {
        Input::new()
            .with_prompt("Auth Token")
            .validate_with({
                move |input: &String| -> Result<()> {
                    if !input.trim().is_empty() {
                        Ok(())
                    } else {
                        Err(anyhow::anyhow!("auth token cannot be empty"))
                    }
                }
            })
            .interact_text()?
            .trim()
            .to_string()
    };

    Ok(auth_token)
}
pub fn save_auth_token(auth_token: String) -> Result<PathBuf> {
    // Load from disk and update the prompted fields.
    // There are other fields (not prompted for) related to "relay" for the `listen` command
    // that we'd rather not wipe out if `login` is invoked.
    let mut cfg = Config::load()?;
    cfg.auth_token = Some(auth_token);
    let fp = config::get_config_file_path()?;
    if let Err(e) = cfg.save_to_disk(&fp) {
        eprintln!("\n{e:#}\n");
        anyhow::bail!(
            "Failed to configure the Svix CLI, please try again or try setting your auth \
             token manually `SVIX_AUTH_TOKEN` environment variable."
        );
    }

    Ok(fp)
}
pub async fn ensure_authenticated() -> Result<Config> {
    if let Ok(cfg) = Config::load() {
        if cfg
            .auth_token
            .as_ref()
            .is_some_and(|t| !t.trim().is_empty())
        {
            return Ok(cfg);
        }
    }

    let auth_token = prompt_for_auth_token().await?;
    let fp = save_auth_token(auth_token)?;
    println!("Your config has been written to `{}`\n", fp.display());

    Config::load()
}

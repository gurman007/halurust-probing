    pub const fn from_static_name(name: &'static str) -> Self {
        Self {
            name: ScopedString::Borrowed(name),
            labels: Vec::new(),
        }
    }

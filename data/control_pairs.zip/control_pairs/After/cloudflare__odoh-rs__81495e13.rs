    pub fn identifier(&self) -> Result<Vec<u8>> {
        let buf = compose(self)?;

        let key_id_info = LABEL_KEY_ID.to_vec();
        let prk = Hkdf::<Hash>::new(None, &buf);
        let mut key_id = [0; KDF_OUTPUT_SIZE];
        prk.expand(&key_id_info, &mut key_id)
            .map_err(|_| Error::from(HpkeError::KdfOutputTooLong))?;
        Ok(key_id.to_vec())
    }
fn derive_secrets(
    odoh_secret: OdohSecret,
    query: &ObliviousDoHMessagePlaintext,
    response_nonce: ResponseNonce,
) -> Result<(AeadKey, AeadNonce)> {
    let buf = compose(query)?;
    let salt = [
        buf.as_ref(),
        &to_u16(response_nonce.len())?.to_be_bytes(),
        &response_nonce,
    ]
    .concat();

    let h_key = Hkdf::<Hash>::new(Some(&salt), &odoh_secret);
    let mut key = AeadKey::default();
    h_key
        .expand(LABEL_KEY, &mut key)
        .map_err(|_| Error::from(HpkeError::KdfOutputTooLong))?;

    let h_nonce = Hkdf::<Hash>::new(Some(&salt), &odoh_secret);
    let mut nonce = AeadNonce::default();
    h_nonce
        .expand(LABEL_NONCE, &mut nonce)
        .map_err(|_| Error::from(HpkeError::KdfOutputTooLong))?;

    Ok((key, nonce))
}

            fn encode_raw<B>(&self, buf: &mut B) where B: ::prost::bytes::BufMut {
                #(#encode)*
            }
            fn merge_field<B>(
                &mut self,
                tag: u32,
                wire_type: ::prost::encoding::WireType,
                buf: &mut B,
                ctx: ::prost::encoding::DecodeContext,
            ) -> ::std::result::Result<(), ::prost::DecodeError>
            where B: ::prost::bytes::Buf {
                #struct_name
                match tag {
                    #(#merge)*
                    _ => ::prost::encoding::skip_field(wire_type, tag, buf),
                }
            }
            pub fn encode<B>(&self, buf: &mut B) where B: ::prost::bytes::BufMut {
                match *self {
                    #(#encode,)*
                }
            }
            pub fn merge<B>(
                field: &mut ::std::option::Option<#ident>,
                tag: u32,
                wire_type: ::prost::encoding::WireType,
                buf: &mut B,
                ctx: ::prost::encoding::DecodeContext,
            ) -> ::std::result::Result<(), ::prost::DecodeError>
            where B: ::prost::bytes::Buf {
                match tag {
                    #(#merge,)*
                    _ => unreachable!(concat!("invalid ", stringify!(#ident), " tag: {}"), tag),
                }
            }

    fn top_raw(&self) -> Option<*mut T> {
        if self.next_ofs == 0 {
            None
        } else {
            let dar = self.data.as_ref();
            let meta = &dar[dar.len() - self.next_ofs..];
            let mw = Self::meta_words();
            // SAFE: Internal consistency maintains the metadata validity
            Some(unsafe { super::make_fat_ptr(meta[mw..].as_ptr() as usize, &meta[..mw]) })
        }
    }
    pub fn push_str(&mut self, v: &str) -> Result<(), ()> {
        self.push_inner(v).map(|d| unsafe {
            ptr::copy(v.as_bytes().as_ptr(), d.as_mut_ptr() as *mut u8, v.len());
        })
    }
    pub fn push_cloned(&mut self, v: &[T]) -> Result<(), ()> {
        self.push_inner(&v).map(|d| unsafe {
            let mut ptr = d.as_mut_ptr() as *mut T;
            for val in v {
                ptr::write(ptr, val.clone());
                ptr = ptr.offset(1);
            }
        })
    }
    fn meta_words() -> usize {
        mem::size_of::<&T>() / mem::size_of::<usize>() - 1
    }
    pub fn new_or_boxed<U>(val: U) -> ValueA<T, D>
    where
        U: marker::Unsize<T>,
        ::alloc::boxed::Box<U>: marker::Unsize<T>,
    {
        Self::new(val).unwrap_or_else(|val| {
            Self::new(Box::new(val))
                .ok()
                .expect("Insufficient space for Box<T>")
        })
    }

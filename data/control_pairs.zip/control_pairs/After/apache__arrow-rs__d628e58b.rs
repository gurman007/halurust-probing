    async fn test_alltypes_with_empty_schema_large_batch() {
        // With an empty reader schema -- should count rows but produce no columns
        let file = arrow_test_data("avro/alltypes_plain.avro");
        let schema = Arc::new(Schema::new(Vec::<Field>::new()));
        let batches = read_async_file(&file, 1024, None, Some(schema), None)
            .await
            .unwrap();
        assert_eq!(batches.len(), 1);
        let batch = &batches[0];

        assert_eq!(batch.num_rows(), 8);
        assert_eq!(batch.num_columns(), 0);
    }
    async fn test_alltypes_with_empty_schema_small_batch() {
        // With an empty reader schema -- should count rows but produce no columns
        let file = arrow_test_data("avro/alltypes_plain.avro");
        let schema = Arc::new(Schema::new(Vec::<Field>::new()));
        let batches = read_async_file(&file, 5, None, Some(schema), None)
            .await
            .unwrap();

        assert_eq!(batches.len(), 2);

        assert_eq!(batches[0].num_rows(), 5);
        assert_eq!(batches[0].num_columns(), 0);
        assert_eq!(batches[1].num_rows(), 3);
        assert_eq!(batches[1].num_columns(), 0);
    }
    async fn test_nested_with_empty_schema() {
        // With an empty reader schema -- should count rows but produce no columns
        let file = arrow_test_data("avro/nested_records.avro");
        let schema = Arc::new(
            Schema::new(Vec::<Field>::new()).with_metadata(HashMap::from([(
                SCHEMA_METADATA_KEY.into(),
                r#"{
                    "type": "record",
                    "namespace": "ns1",
                    "name": "record1",
                    "fields": []
                }"#
pub(crate) struct RecordDecoder {
    schema: SchemaRef,
    fields: Vec<Decoder>,
    projector: Option<Projector>,
    row_count: usize,
}
    pub(crate) fn try_new_with_options(data_type: &AvroDataType) -> Result<Self, AvroError> {
        match data_type.codec() {
            Codec::Struct(reader_fields) => {
                // Build Arrow schema fields and per-child decoders
                let mut arrow_fields = Vec::with_capacity(reader_fields.len());
                let mut encodings = Vec::with_capacity(reader_fields.len());
                let mut field_defaults = Vec::with_capacity(reader_fields.len());
                for avro_field in reader_fields.iter() {
                    arrow_fields.push(avro_field.field());
                    encodings.push(Decoder::try_new(avro_field.data_type())?);

                    if let Some(ResolutionInfo::DefaultValue(lit)) =
                        avro_field.data_type().resolution.as_ref()
                    {
                        field_defaults.push(Some(lit.clone()));
                    } else {
                        field_defaults.push(None);
                    }
                }
                let projector = match data_type.resolution.as_ref() {
                    Some(ResolutionInfo::Record(rec)) => {
                        Some(ProjectorBuilder::try_new(rec, &field_defaults).build()?)
                    }
                    _ => None,
                };
                Ok(Self {
                    schema: Arc::new(ArrowSchema::new(arrow_fields)),
                    fields: encodings,
                    projector,
                    row_count: 0,
                })
            }
            other => Err(AvroError::ParseError(format!(
                "Expected record got {other:?}"
            ))),
        }
    }
    pub(crate) fn decode(&mut self, buf: &[u8], count: usize) -> Result<usize, AvroError> {
        let mut cursor = AvroCursor::new(buf);
        match self.projector.as_mut() {
            Some(proj) => {
                for _ in 0..count {
                    proj.project_record(&mut cursor, &mut self.fields)?;
                }
            }
            None => {
                for _ in 0..count {
                    for field in &mut self.fields {
                        field.decode(&mut cursor)?;
                    }
                }
            }
        }
        self.row_count += count;
        Ok(cursor.position())
    }
    pub(crate) fn flush(&mut self) -> Result<RecordBatch, AvroError> {
        let arrays = self
            .fields
            .iter_mut()
            .map(|x| x.flush(None))
            .collect::<Result<Vec<_>, _>>()?;
        let batch_options = RecordBatchOptions::new().with_row_count(Some(self.row_count));
        self.row_count = 0;
        RecordBatch::try_new_with_options(self.schema.clone(), arrays, &batch_options)
            .map_err(Into::into)
    }

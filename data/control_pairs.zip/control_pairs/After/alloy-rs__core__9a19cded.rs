    unsafe fn decode_many_from<'b>(
        dec: &mut Decoder<'a>,
        out: &'b mut [MaybeUninit<Self>],
    ) -> Result<&'b mut [Self]> {
        let len = out.len();
        let byte_len = len * Word::len_bytes();
        let slice = dec.take_slice(byte_len)?;
        // SAFETY: `MaybeUninit<WordToken>` has the same layout as `WordToken` which is
        // `#[repr(transparent)]` over `Word` (`[u8; 32]`), all with alignment 1.
        // `slice` is exactly `len * 32` bytes, matching the output layout.
        unsafe {
            core::ptr::copy_nonoverlapping(slice.as_ptr(), out.as_mut_ptr().cast::<u8>(), byte_len);
            Ok(core::slice::from_raw_parts_mut(out.as_mut_ptr().cast::<Self>(), len))
        }
    }
    fn decode_sequence(dec: &mut Decoder<'de>) -> Result<Self> {
        let mut arr = crate::impl_core::uninit_array::<T, N>();
        // SAFETY: `arr` is valid writable memory for `N` elements.
        // `decode_many_from` initializes all elements on success.
        unsafe {
            T::decode_many_from(dec, &mut arr)?;
            Ok(Self(crate::impl_core::array_assume_init(arr)))
        }
    }
    fn decode_from(dec: &mut Decoder<'de>) -> Result<Self> {
        let mut child = dec.take_indirection()?;
        let len = child.take_offset()?;
        // This appears to be an unclarity in the Solidity spec. The spec
        // specifies that offsets are relative to the first word of
        // `enc(X)`. But known-good test vectors are relative to the
        // word AFTER the array size
        let mut child = child.raw_child()?;
        let mut tokens = vec_try_with_capacity(len)?;
        // SAFETY: `spare_capacity_mut` returns valid writable memory.
        // `decode_many_from` initializes all `len` elements on success.
        unsafe {
            T::decode_many_from(&mut child, &mut tokens.spare_capacity_mut()[..len])?;
            tokens.set_len(len);
        }
        Ok(Self(tokens))
    }
        fn drop(&mut self) {
            // SAFETY: the first `self.initialized` elements are guaranteed initialized.
            unsafe {
                let ptr = self.buf.as_mut_ptr().cast::<T>();
                ptr::drop_in_place(ptr::slice_from_raw_parts_mut(ptr, self.initialized));
            }
        }
pub trait Token<'de>: Sealed + Sized {
    /// True if the token represents a dynamically-sized type.
    const DYNAMIC: bool;

    /// Decode a token from a decoder.
    fn decode_from(dec: &mut Decoder<'de>) -> Result<Self>;

    /// Decode tokens from a decoder into the given uninitialized buffer.
    ///
    /// On success, returns the initialized slice.
    /// On error, no elements are initialized (partially initialized elements are dropped).
    ///
    /// The default implementation simply loops over [`decode_from`](Self::decode_from).
    /// Implementations may override this to provide a more efficient batch decode,
    /// e.g. a single `memcpy` for [`WordToken`].
    ///
    /// # Safety
    ///
    /// `out` must point to valid, writable memory for `out.len()` elements.
    #[inline]
    unsafe fn decode_many_from<'a>(
        dec: &mut Decoder<'de>,
        out: &'a mut [MaybeUninit<Self>],
    ) -> Result<&'a mut [Self]> {
        try_init_each(out, || Self::decode_from(dec))
    }

    /// Calculate the number of head words.
    fn head_words(&self) -> usize;

    /// Calculate the number of tail words.
    fn tail_words(&self) -> usize;

    /// Calculate the total number of head and tail words.
    #[inline]
    fn total_words(&self) -> usize {
        self.head_words() + self.tail_words()
    }

    /// Append head words to the encoder.
    fn head_append(&self, enc: &mut Encoder);

    /// Append tail words to the encoder.
    fn tail_append(&self, enc: &mut Encoder);
}

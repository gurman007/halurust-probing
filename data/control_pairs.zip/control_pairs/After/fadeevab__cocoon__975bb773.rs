    fn header_deserialize_modified() {
        let header = CocoonHeader::new(CocoonConfig::default(), [1; 16], [2; 12], 50);

        // Corrupt header: one byte per time.
        for i in 0..7 {
            let mut header = header.serialize();
            header[i] = 0xff;
            match CocoonHeader::deserialize(&header) {
                Ok(_) => panic!("Header must not be deserialized on byte #{}", i),
                Err(e) => match e {
                    Error::UnrecognizedFormat => (),
                    _ => panic!("Invalid error, expected Error::UnrecognizedFormat"),
                }
            }
        }

        // Corrupt header: reserved byte is ignored, and random data and length can be any.
        for i in 7..CocoonHeader::SIZE {
            let mut header = header.serialize();
            header[i] = 0xff;
            CocoonHeader::deserialize(&header).expect("Header must be serialized");
        }
    }
    fn header_deserialize() {
        let header = CocoonHeader::new(CocoonConfig::default(), [1; 16], [2; 12], 50);
        let header = match CocoonHeader::deserialize(&header.serialize()) {
            Ok(h) => h,
            Err(e) => panic!("Cannot deserialize serialized: {:?}", e),
        };

        assert_eq!(header.config(), &CocoonConfig::default());
        assert_eq!(header.salt(), [1; 16]);
        assert_eq!(header.nonce(), [2; 12]);
        assert_eq!(header.data_length(), 50);
        assert_eq!(header.version(), CocoonVersion::Version1);
    }

unsafe extern "C" fn global_init_ecall(
    eid: u64,
    path: *const u8,
    path_len: usize,
    env: *const u8,
    env_len: usize,
    args: *const u8,
    args_len: usize,
) {
    INIT.call_once(|| {
        if eid > 0 {
            Enclave::set_id(eid);
        }
        if !path.is_null() && path_len > 0 {
            if let Ok(s) = str::from_utf8(slice::from_raw_parts(path, path_len)) {
                Enclave::set_path_unchecked(s);
            }
        }

        #[cfg(feature = "initenv")]
        {
            let parse_vec = |ptr: *const u8, len: usize| -> Vec<CString> {
                if !ptr.is_null() && len > 0 {
                    let buf = slice::from_raw_parts(ptr, len);
                    buf.split(|&c| c == 0)
                        .filter_map(|bytes| {
                            if !bytes.is_empty() {
                                CString::new(bytes).ok()
                            } else {
                                None
                            }
                        })
                        .collect()
                } else {
                    Vec::new()
                }
            };

            let env = parse_vec(env, env_len);
            let args = parse_vec(args, args_len);
            sys::init(env, args);
        }
    });
}

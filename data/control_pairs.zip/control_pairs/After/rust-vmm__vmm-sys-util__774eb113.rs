pub enum Error {
    /// Couldn't create a sigset.
    CreateSigset(errno::Error),
    /// The wrapped signal has already been blocked.
    SignalAlreadyBlocked(c_int),
    /// Failed to check if the requested signal is in the blocked set already.
    CompareBlockedSignals(errno::Error),
    /// The signal could not be blocked.
    BlockSignal(errno::Error),
    /// The signal mask could not be retrieved.
    RetrieveSignalMask(c_int),
    /// The signal could not be unblocked.
    UnblockSignal(errno::Error),
    /// Failed to wait for given signal.
    ClearWaitPending(errno::Error),
    /// Failed to get pending signals.
    ClearGetPending(errno::Error),
    /// Failed to check if given signal is in the set of pending signals.
    ClearCheckPending(errno::Error),
}
pub unsafe fn register_signal_handler(
    num: c_int,
    handler: SignalHandler,
    for_vcpu: bool,
    flag: c_int,
) -> errno::Result<()> {
    let num = validate_signal_num(num, for_vcpu)?;
    let mut act: sigaction = handler.into();
    SignalHandler::set_flags(&mut act, flag);
    match sigaction(num, &act, null_mut()) {
        0 => Ok(()),
        _ => errno::errno_result(),
    }
}
    fn kill(&self, num: c_int) -> errno::Result<()> {
        let num = validate_signal_num(num, true)?;

        // Safe because we ensure we are using a valid pthread handle,
        // a valid signal number, and check the return result.
        let ret = unsafe { pthread_kill(self.pthread_handle(), num) };
        if ret < 0 {
            return errno::errno_result();
        }
        Ok(())
    }

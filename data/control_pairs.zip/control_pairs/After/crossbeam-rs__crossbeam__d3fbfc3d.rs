    fn drop(&mut self) {
        // Get the tail and head indices.
        let tail_index = self.tail.index.load(Ordering::Relaxed);
        let mut head_index = self.head.index.load(Ordering::Relaxed);

        unsafe {
            let mut head_ptr = self
                .head
                .block
                .load(Ordering::Relaxed, epoch::unprotected());

            // Manually drop all messages between `head_index` and `tail_index` and destroy the
            // heap-allocated nodes along the way.
            while head_index != tail_index {
                let head = head_ptr.deref();
                let offset = head_index.wrapping_sub(head.start_index);

                let slot = head.slots.get_unchecked(offset);
                ManuallyDrop::drop(&mut *(*slot).msg.get());

                if offset + 1 == head.cap {
                    let next = head.next.load(Ordering::Relaxed, epoch::unprotected());
                    Block::dealloc(head_ptr);
                    head_ptr = next;
                }

                head_index = head_index.wrapping_add(1);
            }

            // If there is one last remaining block in the end, destroy it.
            if !head_ptr.is_null() {
                Block::dealloc(head_ptr);
            }
        }
    }

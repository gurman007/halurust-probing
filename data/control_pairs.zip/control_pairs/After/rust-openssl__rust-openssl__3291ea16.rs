            pub fn EVP_KDF_CTX_new(kdf: *mut EVP_KDF) -> *mut EVP_KDF_CTX;
            pub fn EVP_KDF_CTX_free(ctx: *mut EVP_KDF_CTX);
            pub fn EVP_KDF_CTX_reset(ctx: *mut EVP_KDF_CTX);
            pub fn EVP_KDF_CTX_get_kdf_size(ctx: *mut EVP_KDF_CTX) -> size_t;
            pub fn EVP_KDF_derive(ctx: *mut EVP_KDF_CTX, key: *mut u8, keylen: size_t, params: *const OSSL_PARAM) -> c_int;
            pub fn EVP_KDF_fetch(ctx: *mut OSSL_LIB_CTX, algorithm: *const c_char, properties: *const c_char) -> *mut EVP_KDF;
            pub fn EVP_KDF_free(kdf: *mut EVP_KDF);
            pub fn EVP_PKEY_CTX_add1_hkdf_info(
                ctx: *mut EVP_PKEY_CTX,
                info: *const u8,
                infolen: c_int,
            ) -> c_int;
    pub fn OSSL_PARAM_construct_octet_string(
        key: *const c_char,
        buf: *mut c_void,
        bsize: size_t,
    ) -> OSSL_PARAM;
    pub fn OSSL_PARAM_construct_end() -> OSSL_PARAM;
pub enum EVP_KDF {}
pub enum EVP_KDF_CTX {}
pub struct OSSL_PARAM {
    key: *const c_char,
    data_type: c_uchar,
    data: *mut c_void,
    data_size: size_t,
    return_size: size_t,
}

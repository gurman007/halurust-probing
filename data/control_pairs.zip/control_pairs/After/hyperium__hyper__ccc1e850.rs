    pub fn initialize_unfilled(&mut self) -> &mut [u8] {
        self.initialize_unfilled_to(self.remaining())
    }
    pub fn initialize_unfilled_to(&mut self, n: usize) -> &mut [u8] {
        assert!(self.remaining() >= n, "n overflows remaining");

        // This can't overflow as the assert above would have panicked otherwise.
        let end = self.buf.filled + n;

        if self.buf.init < end {
            // SAFETY:
            // 1. The raw pointer is not null and not dangling either as the slice outlives the
            // pointer's usage. The pointer is also properly aligned.
            // 2. Further, `end - self.buf.init` is inbounds and hence safe to write
            // to.
            unsafe {
                self.buf.raw[self.buf.init..end]
                    .as_mut_ptr()
                    .write_bytes(0, end - self.buf.init);
            }
            self.buf.init = end;
        }

        let slice = &mut self.buf.raw[self.buf.filled..end];

        // SAFETY: `MaybeUninit<u8>` has the same memory layout as u8 and we properly initialized
        // the slice above.
        unsafe { &mut *(slice as *mut [MaybeUninit<u8>] as *mut [u8]) }
    }
    pub fn put_slice(&mut self, src: &[u8]) {
        assert!(
            self.buf.remaining() >= src.len(),
            "src.len() must fit in remaining()"
        );

        let amt = src.len();
        // Cannot overflow, asserted above
        let end = self.buf.filled + amt;

        // Safety: the length is asserted above
        unsafe {
            self.buf.raw[self.buf.filled..end]
                .as_mut_ptr()
                .cast::<u8>()
                .copy_from_nonoverlapping(src.as_ptr(), amt);
        }

        if self.buf.init < end {
            self.buf.init = end;
        }
        self.buf.filled = end;
    }

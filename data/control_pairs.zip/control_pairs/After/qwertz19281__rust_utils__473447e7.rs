            fn avg<U>(&self) -> U where T: Clone, U: From<T> + From<u8> + Sum<U> + DivAssign<U>{
                (*self).clone().as_array().avg()
            }
    fn test_it() {
        let tuple = (1u32,2u32,3u32,4u32);
        let arr = tuple.clone().as_array();
        assert_eq!(arr,[1u32,2,3,4]);
        let t = arr.as_tuple();
        assert_eq!(t,tuple);

        assert_eq!((3u32,6u32,8u32,3u32,5u32,2u32).avg::<u32>(), 4u32);
        assert_eq!((3u32,6u32,8u32,3u32,5u32,2u32).avg::<f64>(), 4.5);
    }
impl<T> RefClonable for Rc<T> where T: ?Sized {
    #[inline] fn refc(&self) -> Self {
        Rc::clone(self)
    }
}

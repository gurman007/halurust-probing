    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
        async fn handler(_: WithRejection<UsersShow, MyRejection>) {}
            fn into_response(self) -> Response {
                unimplemented!()
            }
            fn from(_: PathRejection) -> Self {
                unimplemented!()
            }
    fn with_params_called_multiple_times() {
        let path = UsersShow { id: 1 }
            .with_query_params(Params {
                foo: "foo",
                bar: 123,
                baz: true,
            })
            .with_query_params([("qux", 1337)]);

        let uri = path.to_uri();

        assert_eq!(uri, "/users/1?&foo=foo&bar=123&baz=true&qux=1337");
    }

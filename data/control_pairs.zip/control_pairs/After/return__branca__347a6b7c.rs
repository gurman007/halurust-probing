    pub fn build(self, message: &str) -> Result<String, BrancaError> {
        let key = self.key;
        let nonce = self.nonce;
        let mut timestamp = self.timestamp;
        if timestamp <= 0 {
            // Generate a timestamp instead of a zero supplied one.
            let ts = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH).expect("Failed to obtain timestamp from system clock.");
            timestamp = ts.as_secs() as u32;
        }
        let crypted = encode(message, key, nonce, timestamp);
        return Ok(crypted.unwrap());
    }
pub fn decode(data: &str, key: Vec<u8>, ttl: u32) -> Result<String, BrancaError> {

    // The key must be 32 bytes in size.
    if key.len() != 32 {
        return Err(BrancaError::BadKeyLength);
    }

    if data.len() < 62 {
        return Err(BrancaError::InvalidBase62Token);
    }

    let decoded_data = b62_decode(BASE62, &data).expect("Base62 token is invalid.");

    // After we have decoded the data, the branca token is now represented
    // by the following layout below:

    // Branca( header[0..29] + ciphertext[29..] )
    // Version (&u8) || Timestamp (u32) || Nonce ([u8;24]) || Ciphertext (&[u8]) || Tag ([u8:16])

    // We then obtain the header, ciphertext, version and timestamp with this layout.

    let header = &decoded_data[0..29];
    let ciphertext = &decoded_data[29..(decoded_data.len() - 16)];
    let version = vec![header[0]];
    let timestamp = BigEndian::read_u32(&header[1..5]);
    let tag = &decoded_data[(decoded_data.len() - 16)..decoded_data.len()];

    // Create the key given from the input.
    let mut key_bytes = [0u8; 32];
    
    key_bytes.copy_from_slice(key.as_slice());

    // Extract the 24 byte nonce in the header starting
    // from the first 6 bytes.
    let mut nonce_n = [0u8; NONCE_BYTES];
    nonce_n.copy_from_slice(&header[5..]);

    let mut derv_nonce_1 = [0u8; 16];

    // Copy the first 16 bytes from the 24 byte nonce.
    derv_nonce_1.copy_from_slice(&nonce_n[..16]);

    // Encrypt the first 16 bytes of the nonce with our key required by HChaCha20.
    let part_crypted = hchacha20::hchacha20(&key_bytes, &derv_nonce_1);

    let mut derv_nonce_2 =[0u8; 12];

    // Copy the rest of the 12 bytes from the 24 byte nonce.
    // We must offset from the first 4 bytes to later use
    // the remaining 12 bytes later for the ChaCha20 construction.
    derv_nonce_2[4..].copy_from_slice(&nonce_n[16..]);

    // The full nonce is now appended to the timestamp in a vector.
    let mut time_bytes = vec![0x0; 4];
    BigEndian::write_u32(&mut time_bytes, timestamp);
    time_bytes.append(&mut Vec::from(&header[5..]));

    // We now append the version header to the timestamp vector.
    let mut version_header = vec![VERSION];
    version_header.append(&mut time_bytes);

    // Check if there is a version mismatch.
    if &version.as_slice()[0] != &VERSION {
       return Err(BrancaError::InvalidTokenVersion);
    }

    let mut buf_crypt = Vec::with_capacity(ciphertext.len());

    // Retrieve the plaintext using ChaCha20-Poly1305 AEAD (de-attached mode)
    // We use the output of HChaCha20 (part_crypted) as the key with the
    // rest of the 16 byte nonce; i.e decrypting using XChaCha20 instead of ChaCha20.
    let decrypted = chacha20_poly1305_aead::decrypt(&part_crypted, &derv_nonce_2, &version_header, &ciphertext, &tag, &mut buf_crypt);

     if !decrypted.is_ok() {
         return Err(BrancaError::DecryptFailed);
     }

    // TTL check to determine if the token has expired.
     if ttl != 0 {
         let future = (timestamp + ttl) as u64;
         let time_now = SystemTime::now();
         let ts_seconds = time_now.duration_since(UNIX_EPOCH).expect("Failed to obtain timestamp from system clock.");
         let timestamp_now = ts_seconds.as_secs();
         if future < timestamp_now as u64 {
             return Err(BrancaError::ExpiredToken);
         }
    }

    // Return the plaintext.
    return Ok(String::from_utf8(buf_crypt).unwrap());
}

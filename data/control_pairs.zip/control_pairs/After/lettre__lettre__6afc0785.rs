enum InnerAsyncNetworkStream {
    /// Plain Tokio 0.2 TCP stream
    #[cfg(feature = "tokio02")]
    Tokio02Tcp(Tokio02TcpStream),
    /// Encrypted Tokio 0.2 TCP stream
    #[cfg(feature = "tokio02-native-tls")]
    Tokio02NativeTls(Tokio02TlsStream<Tokio02TcpStream>),
    /// Encrypted Tokio 0.2 TCP stream
    #[cfg(feature = "tokio02-rustls-tls")]
    Tokio02RustlsTls(Tokio02RustlsTlsStream<Tokio02TcpStream>),
    /// Plain Tokio 0.3 TCP stream
    #[cfg(feature = "tokio03")]
    Tokio03Tcp(Tokio03TcpStream),
    /// Encrypted Tokio 0.3 TCP stream
    #[cfg(feature = "tokio03-native-tls")]
    Tokio03NativeTls(Tokio03TlsStream<Tokio03TcpStream>),
    /// Encrypted Tokio 0.3 TCP stream
    #[cfg(feature = "tokio03-rustls-tls")]
    Tokio03RustlsTls(Tokio03RustlsTlsStream<Tokio03TcpStream>),
    /// Can't be built
    None,
}
    async fn upgrade_tokio02_tls(
        tcp_stream: Tokio02TcpStream,
        mut tls_parameters: TlsParameters,
    ) -> Result<InnerAsyncNetworkStream, Error> {
        let domain = std::mem::take(&mut tls_parameters.domain);

        match tls_parameters.connector {
            #[cfg(feature = "native-tls")]
            InnerTlsParameters::NativeTls(connector) => {
                #[cfg(not(feature = "tokio02-native-tls"))]
                panic!("built without the tokio02-native-tls feature");

                #[cfg(feature = "tokio02-native-tls")]
                return {
                    use tokio02_native_tls_crate::TlsConnector;

                    let connector = TlsConnector::from(connector);
                    let stream = connector.connect(&domain, tcp_stream).await?;
                    Ok(InnerAsyncNetworkStream::Tokio02NativeTls(stream))
                };
            }
            #[cfg(feature = "rustls-tls")]
            InnerTlsParameters::RustlsTls(config) => {
                #[cfg(not(feature = "tokio02-rustls-tls"))]
                panic!("built without the tokio02-rustls-tls feature");

                #[cfg(feature = "tokio02-rustls-tls")]
                return {
                    use tokio02_rustls::{webpki::DNSNameRef, TlsConnector};

                    let domain = DNSNameRef::try_from_ascii_str(&domain)?;

                    let connector = TlsConnector::from(Arc::new(config));
                    let stream = connector.connect(domain, tcp_stream).await?;
                    Ok(InnerAsyncNetworkStream::Tokio02RustlsTls(stream))
                };
            }
        }
    }
    async fn upgrade_tokio03_tls(
        tcp_stream: Tokio03TcpStream,
        mut tls_parameters: TlsParameters,
    ) -> Result<InnerAsyncNetworkStream, Error> {
        let domain = std::mem::take(&mut tls_parameters.domain);

        match tls_parameters.connector {
            #[cfg(feature = "native-tls")]
            InnerTlsParameters::NativeTls(connector) => {
                #[cfg(not(feature = "tokio03-native-tls"))]
                panic!("built without the tokio03-native-tls feature");

                #[cfg(feature = "tokio03-native-tls")]
                return {
                    use tokio03_native_tls_crate::TlsConnector;

                    let connector = TlsConnector::from(connector);
                    let stream = connector.connect(&domain, tcp_stream).await?;
                    Ok(InnerAsyncNetworkStream::Tokio03NativeTls(stream))
                };
            }
            #[cfg(feature = "rustls-tls")]
            InnerTlsParameters::RustlsTls(config) => {
                #[cfg(not(feature = "tokio03-rustls-tls"))]
                panic!("built without the tokio03-rustls-tls feature");

                #[cfg(feature = "tokio03-rustls-tls")]
                return {
                    use tokio03_rustls::{webpki::DNSNameRef, TlsConnector};

                    let domain = DNSNameRef::try_from_ascii_str(&domain)?;

                    let connector = TlsConnector::from(Arc::new(config));
                    let stream = connector.connect(domain, tcp_stream).await?;
                    Ok(InnerAsyncNetworkStream::Tokio03RustlsTls(stream))
                };
            }
        }
    }
enum InnerNetworkStream {
    /// Plain TCP stream
    Tcp(TcpStream),
    /// Encrypted TCP stream
    #[cfg(feature = "native-tls")]
    NativeTls(TlsStream<TcpStream>),
    /// Encrypted TCP stream
    #[cfg(feature = "rustls-tls")]
    RustlsTls(StreamOwned<ClientSession, TcpStream>),
    /// Mock stream
    Mock(MockStream),
}
    fn upgrade_tls_impl(
        tcp_stream: TcpStream,
        tls_parameters: &TlsParameters,
    ) -> Result<InnerNetworkStream, Error> {
        Ok(match &tls_parameters.connector {
            #[cfg(feature = "native-tls")]
            InnerTlsParameters::NativeTls(connector) => {
                let stream = connector
                    .connect(tls_parameters.domain(), tcp_stream)
                    .map_err(|err| Error::Io(io::Error::new(io::ErrorKind::Other, err)))?;
                InnerNetworkStream::NativeTls(stream)
            }
            #[cfg(feature = "rustls-tls")]
            InnerTlsParameters::RustlsTls(connector) => {
                use webpki::DNSNameRef;

                let domain = DNSNameRef::try_from_ascii_str(tls_parameters.domain())?;
                let stream = StreamOwned::new(
                    ClientSession::new(&Arc::new(connector.clone()), domain),
                    tcp_stream,
                );

                InnerNetworkStream::RustlsTls(stream)
            }
        })
    }

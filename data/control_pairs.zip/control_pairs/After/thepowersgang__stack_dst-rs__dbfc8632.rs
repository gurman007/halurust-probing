    pub fn retain<Cb>(&mut self, mut cb: Cb)
    where
        Cb: FnMut(&mut T)->bool
    {
        let orig_write_pos = self.write_pos;
        self.write_pos = self.read_pos;
        let mut ofs = self.read_pos;
        let mut writeback_pos = ofs;
        while ofs < orig_write_pos
        {
            let v: &mut T = unsafe {
                let meta = &mut self.data.as_mut()[ofs..];
                let mw = Self::meta_words();
                let (meta, data) = meta.split_at_mut(mw);
                &mut *super::make_fat_ptr(data.as_mut_ptr() as *mut (), meta)
                };
            let words = Self::meta_words() + D::round_to_words(mem::size_of_val(v));
            if cb(v) {
                if writeback_pos != ofs {
                    let d = self.data.as_mut();
                    // writeback is always before `ofs`, so this ordering is correct
                    for i in 0..words {
                        let (a,b) = d.split_at_mut(ofs+i);
                        a[writeback_pos+i] = b[0];
                    }
                }
                writeback_pos += words;
            }
            else {
                // Don't update `writeback_pos`
                // SAFE: Valid pointer, won't be accessed again
                unsafe {
                    ptr::drop_in_place(v);
                }
            }
            ofs += words;
        }
        assert!(ofs == orig_write_pos);
        self.write_pos = writeback_pos;
    }

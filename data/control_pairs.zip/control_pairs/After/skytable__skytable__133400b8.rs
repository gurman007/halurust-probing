    fn create_table(handle: &Corestore, con: &mut T, mut act: ActionIter) {
        err_if_len_is!(con, act.len() > 3 || act.len() < 2);
        let (table_entity, model_code) = match parser::parse_table_args(&mut act) {
            Ok(v) => v,
            Err(e) => return con.write_response(e).await,
        };
        let is_volatile = match act.next() {
            Some(maybe_volatile) => {
                if maybe_volatile.eq(VOLATILE) {
                    true
                } else {
                    return conwrite!(con, responses::groups::UNKNOWN_PROPERTY);
                }
            }
            None => false,
        };
        if registry::state_okay() {
            match handle.create_table(table_entity, model_code, is_volatile) {
                Ok(_) => con.write_response(responses::groups::OKAY).await?,
                Err(DdlError::AlreadyExists) => {
                    con.write_response(responses::groups::ALREADY_EXISTS)
                        .await?;
                }
                Err(DdlError::WrongModel) => unsafe {
                    // we have already checked the model ourselves
                    impossible!()
                },
                Err(DdlError::DefaultNotFound) => {
                    con.write_response(responses::groups::DEFAULT_UNSET).await?
                }
                Err(_) => unsafe {
                    // we know that Corestore::create_table won't return anything else
                    impossible!()
                },
            }
        } else {
            conwrite!(con, responses::groups::SERVER_ERR)?;
        }
        Ok(())
    }
    fn create_keyspace(handle: &Corestore, con: &mut T, mut act: ActionIter) {
        err_if_len_is!(act, con, not 1);
        match act.next() {
            Some(ksid) => {
                if !encoding::is_utf8(&ksid) {
                    return con.write_response(responses::groups::ENCODING_ERROR).await;
                }
                let ksid_str = unsafe { str::from_utf8_unchecked(&ksid) };
                if !VALID_CONTAINER_NAME.is_match(ksid_str) {
                    return con.write_response(responses::groups::BAD_EXPRESSION).await;
                }
                if ksid.len() > 64 {
                    return con
                        .write_response(responses::groups::CONTAINER_NAME_TOO_LONG)
                        .await;
                }
                let ksid = unsafe { ObjectID::from_slice(ksid_str) };
                if registry::state_okay() {
                    match handle.create_keyspace(ksid) {
                        Ok(()) => return con.write_response(responses::groups::OKAY).await,
                        Err(DdlError::AlreadyExists) => {
                            return con.write_response(responses::groups::ALREADY_EXISTS).await
                        }
                        Err(_) => unsafe {
                            // we already know that Corestore::create_keyspace doesn't return anything else
                            impossible!()
                        },
                    }
                } else {
                    return conwrite!(con, responses::groups::SERVER_ERR);
                }
            }
            None => return con.write_response(responses::groups::ACTION_ERR).await,
        }
    }
    fn drop_table(handle: &Corestore, con: &mut T, mut act: ActionIter) {
        match act.next() {
            Some(eg) => {
                let entity_group = match parser::get_query_entity(&eg) {
                    Ok(egroup) => egroup,
                    Err(e) => return con.write_response(e).await,
                };
                if registry::state_okay() {
                    let ret = match handle.drop_table(entity_group) {
                        Ok(()) => responses::groups::OKAY,
                        Err(DdlError::DefaultNotFound) => responses::groups::DEFAULT_UNSET,
                        Err(DdlError::ProtectedObject) => responses::groups::PROTECTED_OBJECT,
                        Err(DdlError::ObjectNotFound) => responses::groups::CONTAINER_NOT_FOUND,
                        Err(DdlError::StillInUse) => responses::groups::STILL_IN_USE,
                        Err(_) => unsafe {
                            // we know that Memstore::drop_table won't ever return anything else
                            impossible!()
                        }
                    };
                    con.write_response(ret).await?;
                } else {
                    conwrite!(con, responses::groups::SERVER_ERR)?;
                }
            },
            None => con.write_response(responses::groups::ACTION_ERR).await?,
        }
        Ok(())
    }
    fn drop_keyspace(handle: &Corestore, con: &mut T, mut act: ActionIter) {
        match act.next() {
            Some(ksid) => {
                if ksid.len() > 64 {
                    return con.write_response(responses::groups::CONTAINER_NAME_TOO_LONG).await;
                }
                if registry::state_okay() {
                    let ret = match handle.drop_keyspace(unsafe {ObjectID::from_slice(ksid)}) {
                        Ok(()) => responses::groups::OKAY,
                        Err(DdlError::ProtectedObject) => responses::groups::PROTECTED_OBJECT,
                        Err(DdlError::ObjectNotFound) => responses::groups::CONTAINER_NOT_FOUND,
                        Err(DdlError::StillInUse) => responses::groups::STILL_IN_USE,
                        Err(_) => unsafe {
                            // we know that Memstore::drop_table won't ever return anything else
                            impossible!()
                        }
                    };
                    con.write_response(ret).await?;
                } else {
                    conwrite!(con, responses::groups::SERVER_ERR)?;
                }
            },
            None => con.write_response(responses::groups::ACTION_ERR).await?,
        }
        Ok(())
    }

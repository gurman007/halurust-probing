pub unsafe trait RawStorageMut<T, R: Dim, C: Dim = U1>: RawStorage<T, R, C> {
    /// The matrix mutable data pointer.
    fn ptr_mut(&mut self) -> *mut T;

    /// Gets the mutable address of the i-th matrix component without performing bound-checking.
    ///
    /// # Safety
    /// If the index is out of bounds, dereferencing the result will cause undefined behavior.
    #[inline]
    fn get_address_unchecked_linear_mut(&mut self, i: usize) -> *mut T {
        self.ptr_mut().wrapping_add(i)
    }

    /// Gets the mutable address of the i-th matrix component without performing bound-checking.
    ///
    /// # Safety
    /// If the index is out of bounds, dereferencing the result will cause undefined behavior.
    #[inline]
    fn get_address_unchecked_mut(&mut self, irow: usize, icol: usize) -> *mut T {
        let lid = self.linear_index(irow, icol);
        self.get_address_unchecked_linear_mut(lid)
    }

    /// Retrieves a mutable reference to the i-th element without bound-checking.
    ///
    /// # Safety
    /// If the index is out of bounds, the method will cause undefined behavior.
    unsafe fn get_unchecked_linear_mut(&mut self, i: usize) -> &mut T {
        &mut *self.get_address_unchecked_linear_mut(i)
    }

    /// Retrieves a mutable reference to the element at `(irow, icol)` without bound-checking.
    ///
    /// # Safety
    /// If the index is out of bounds, the method will cause undefined behavior.
    #[inline]
    unsafe fn get_unchecked_mut(&mut self, irow: usize, icol: usize) -> &mut T {
        &mut *self.get_address_unchecked_mut(irow, icol)
    }

    /// Swaps two elements using their linear index without bound-checking.
    ///
    /// # Safety
    /// If the indices are out of bounds, the method will cause undefined behavior.
    /// 
    /// # Validity
    /// The default implementation of this trait function is only guaranteed to be
    /// sound if invocations of `self.ptr_mut()` and `self.get_address_unchecked_linear_mut()`
    /// result in stable references. If any of the data pointed to by these trait methods
    /// moves as a consequence of invoking either of these methods then this default
    /// trait implementation may be invalid or unsound and should be overridden.
    
    #[inline]
    unsafe fn swap_unchecked_linear(&mut self, i1: usize, i2: usize) {
        // we can't just use the pointers returned from `get_address_unchecked_linear_mut` because calling a
        // method taking self mutably invalidates any existing (mutable) pointers. since `get_address_unchecked_linear_mut` can
        // also be overriden by a custom implementation, we can't just use `wrapping_add` assuming that's what the method does.
        // instead, we use `offset_from` to compute the re-calculate the pointers from the base pointer.
        // this is safe as long as this trait is implemented safely
        // (and it's the caller's responsibility to ensure the indices are in-bounds).
        let base = self.ptr_mut();
        let offset1 = self.get_address_unchecked_linear_mut(i1).offset_from(base);
        let offset2 = self.get_address_unchecked_linear_mut(i2).offset_from(base);

        let base = self.ptr_mut();
        let a = base.offset(offset1);
        let b = base.offset(offset2);

        ptr::swap(a, b);
    }

    /// Swaps two elements without bound-checking.
    ///
    /// # Safety
    /// If the indices are out of bounds, the method will cause undefined behavior.
    #[inline]
    unsafe fn swap_unchecked(&mut self, row_col1: (usize, usize), row_col2: (usize, usize)) {
        let lid1 = self.linear_index(row_col1.0, row_col1.1);
        let lid2 = self.linear_index(row_col2.0, row_col2.1);

        self.swap_unchecked_linear(lid1, lid2)
    }

    /// Retrieves the mutable data buffer as a contiguous slice.
    ///
    /// Matrix components may not be contiguous, depending on its strides.    
    ///
    /// # Safety
    /// The matrix components may not be stored in a contiguous way, depending on the strides.
    /// This method is unsafe because this can yield to invalid aliasing when called on some pairs
    /// of matrix slices originating from the same matrix with strides.
    unsafe fn as_mut_slice_unchecked(&mut self) -> &mut [T];
}

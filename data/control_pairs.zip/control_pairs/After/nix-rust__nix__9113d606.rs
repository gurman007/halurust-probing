    pub fn new() -> Result<Self> {
        Self::from_value_and_flags(0, EfdFlags::empty())
    }
    pub fn from_value_and_flags(init_val: u32, flags: EfdFlags) -> Result<Self> {
        let res = unsafe { libc::eventfd(init_val, flags.bits()) };
        Errno::result(res).map(|r| Self(unsafe { OwnedFd::from_raw_fd(r) }))
    }
    pub fn from_flags(flags: EfdFlags) -> Result<Self> {
        Self::from_value_and_flags(0, flags)
    }
    pub fn from_value(init_val: u32) -> Result<Self> {
        Self::from_value_and_flags(init_val, EfdFlags::empty())
    }
    pub fn arm(&self) -> Result<usize> {
        self.write(1)
    }
    pub fn defuse(&self) -> Result<usize> {
        self.write(0)
    }
    pub fn write(&self, value: u64) -> Result<usize> { 
        unistd::write(&self.0,&value.to_ne_bytes())
    }
    pub fn read(&self) -> Result<u64> {
        let mut arr = [0; std::mem::size_of::<u64>()];
        unistd::read(self.0.as_raw_fd(),&mut arr)?;
        Ok(u64::from_ne_bytes(arr))
    }
    fn as_fd(&self) -> BorrowedFd {
        self.0.as_fd()
    }
    fn as_raw_fd(&self) -> RawFd {
        self.0.as_raw_fd()
    }
    fn from(x: EventFd) -> OwnedFd {
        x.0
    }
pub fn eventfd(initval: libc::c_uint, flags: EfdFlags) -> Result<OwnedFd> {
    let res = unsafe { libc::eventfd(initval, flags.bits()) };

    Errno::result(res).map(|r| unsafe { OwnedFd::from_raw_fd(r) })
}

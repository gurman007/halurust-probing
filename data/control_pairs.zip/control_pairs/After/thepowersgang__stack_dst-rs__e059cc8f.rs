mod std {
	pub use core::{ops,mem,slice,marker,ptr};
}
	pub fn new_or_boxed<U>(val: U) -> ValueA<T, D>
	where
		U: marker::Unsize<T>,
		::alloc::boxed::Box<U>: marker::Unsize<T>
	{
		match Self::new(val)
		{
		Ok(v) => v,
		Err(val) => Self::new(Box::new(val)).ok().expect("Insufficient space for Box<T>"),
		}
	}
	pub fn new<U: marker::Unsize<T>>(val: U) -> Result<ValueA<T,D>,U> {
		let rv = unsafe {
			let mut ptr: *const T = &val as &T;
			let words = super::ptr_as_slice(&mut ptr);
			assert!(words[0] == &val as *const _ as usize, "BUG: Pointer layout is not (data_ptr, info...)");
			// - Ensure that Self is aligned same as data requires
			assert!(mem::align_of::<U>() <= mem::align_of::<Self>(), "TODO: Enforce alignment >{} (requires {})",
				mem::align_of::<Self>(), mem::align_of::<U>());
			
			ValueA::new_raw(&words[1..], words[0] as *mut (), mem::size_of::<U>())
			};
		match rv
		{
		Some(r) => {
			// Prevent the destructor from running, now that we've copied it away
			mem::forget(val);
			Ok(r)
			},
		None => {
			Err(val)
			},
		}
	}
	fn poll(self: pin::Pin<&mut Self>, cx: &mut task::Context) -> task::Poll<Self::Output> {
		unsafe {
			pin::Pin::new_unchecked(&mut **self.get_unchecked_mut()).poll(cx)
		}
	}
	fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
		(**self).fmt(f)
	}

    fn blockrng64_generate_and_set() {
        let mut rng = BlockRng64::<DummyRng64>::from_seed([1, 2, 3, 4, 5, 6, 7, 8]);
        assert_eq!(rng.index(), rng.results.as_ref().len());

        rng.generate_and_set(5);
        assert_eq!(rng.index(), 5);
    }
    fn blockrng64_generate_and_set_panic() {
        let mut rng = BlockRng64::<DummyRng64>::from_seed([1, 2, 3, 4, 5, 6, 7, 8]);
        rng.generate_and_set(rng.results.as_ref().len());
    }
    fn blockrng_next_u64() {
        let mut rng = BlockRng::<DummyRng>::from_seed([1, 2, 3, 4]);
        let result_size = rng.results.as_ref().len();
        for _i in 0..result_size / 2 - 1 {
            rng.next_u64();
        }
        rng.next_u32();

        let result = rng.next_u64();
        assert_eq!(rng.index(), 1);
    }
    fn blockrng64_next_u32_vs_next_u64() {
        let mut rng1 = BlockRng64::<DummyRng64>::from_seed([1, 2, 3, 4, 5, 6, 7, 8]);
        let mut rng2 = rng1.clone();
        let mut rng3 = rng1.clone();

        let mut a = [0; 16];
        a[..4].copy_from_slice(&rng1.next_u32().to_le_bytes());
        a[4..12].copy_from_slice(&rng1.next_u64().to_le_bytes());
        a[12..].copy_from_slice(&rng1.next_u32().to_le_bytes());

        let mut b = [0; 16];
        b[..4].copy_from_slice(&rng2.next_u32().to_le_bytes());
        b[4..8].copy_from_slice(&rng2.next_u32().to_le_bytes());
        b[8..].copy_from_slice(&rng2.next_u64().to_le_bytes());
        assert_ne!(a, b);
        assert_eq!(&a[..4], &b[..4]);
        assert_eq!(&a[4..12], &b[8..]);

        let mut c = [0; 16];
        c[..8].copy_from_slice(&rng3.next_u64().to_le_bytes());
        c[8..12].copy_from_slice(&rng3.next_u32().to_le_bytes());
        c[12..].copy_from_slice(&rng3.next_u32().to_le_bytes());
        assert_eq!(b, c);
    }

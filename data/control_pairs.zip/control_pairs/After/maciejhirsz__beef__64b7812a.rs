    unsafe fn owned_from_parts(ptr: NonNull<Self>, capacity: NonZeroUsize) -> Vec<T> {
        let len = ptr.as_ref().len();

        Vec::from_raw_parts(
            ptr.cast().as_ptr(),
            len,
            capacity.get(),
        )
    }

	pub fn access_shared_state<V>(&self, modifier: &Fn(&mut U, V), parameter: V) {
		let mut shared_state_lock = self.shared_state.lock().expect("Failed to lock mutex");
		modifier(&mut *shared_state_lock, parameter);
	}

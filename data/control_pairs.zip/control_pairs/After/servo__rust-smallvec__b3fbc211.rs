    fn index(&self, index: I) -> &I::Output {
        &(**self)[index]
    }
    fn index_mut(&mut self, index: I) -> &mut I::Output {
        &mut (&mut **self)[index]
    }

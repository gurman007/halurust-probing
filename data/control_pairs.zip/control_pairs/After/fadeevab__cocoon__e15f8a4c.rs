    fn header_config_default() {
        let iterations = if cfg!(feature = "debug") {
            2000
        } else {
            100_000
        };

        let config = CocoonConfig::default();
        assert_eq!(config.kdf(), CocoonKdf::Pbkdf2);
        assert_eq!(config.cipher(), CocoonCipher::Chacha20Poly1305);
        assert_eq!(config.kdf_iterations(), iterations);
    }
    fn header_config_modify() {
        let config = CocoonConfig::default().with_cipher(CocoonCipher::Aes256Gcm);
        assert_eq!(config.cipher(), CocoonCipher::Aes256Gcm);
    }
    fn header_config_serialize() {
        let variant = if cfg!(feature = "debug") { 0x02 } else { 0x01 };

        let config = CocoonConfig::default();
        assert_eq!(config.serialize(), [0x01, 0x01, variant, 0x00]);

        let config = config.with_cipher(CocoonCipher::Aes256Gcm);
        assert_eq!(config.serialize(), [0x02, 0x01, variant, 0x00]);
    }
    fn header_new() {
        let header = CocoonHeader::new(CocoonConfig::default(), [0; 16], [0; 12], std::u64::MAX);
        assert_eq!(header.config(), &CocoonConfig::default());
        assert_eq!(header.salt(), [0; 16]);
        assert_eq!(header.nonce(), [0; 12]);
        assert_eq!(header.data_length(), std::u64::MAX);
        assert_eq!(header.version(), CocoonVersion::Version1);
    }
    fn header_serialize() {
        let variant = if cfg!(feature = "debug") { 0x02 } else { 0x01 };

        let header = CocoonHeader::new(
            CocoonConfig::default().with_cipher(CocoonCipher::Aes256Gcm),
            [1; 16],
            [2; 12],
            std::u64::MAX,
        );

        assert_eq!(
            header.serialize()[..],
            [
                0x7f, 0xc0, b'\n', 1, 2, 1, variant, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 255, 255, 255, 255, 255, 255, 255, 255
            ][..]
        );
    }
    fn header_deserialize() {
        let header = CocoonHeader::new(CocoonConfig::default(), [1; 16], [2; 12], 50);
        let header = match CocoonHeader::deserialize(&header.serialize()) {
            Ok(h) => h,
            Err(e) => panic!("Cannot deserialize serialized: {:?}", e),
        };

        assert_eq!(header.config(), &CocoonConfig::default());
        assert_eq!(header.salt(), [1; 16]);
        assert_eq!(header.nonce(), [2; 12]);
        assert_eq!(header.data_length(), 50);
        assert_eq!(header.version(), CocoonVersion::Version1);
    }
    fn header_deserialize_from() {
        let header = CocoonHeader::new(CocoonConfig::default(), [1; 16], [2; 12], 50).serialize();
        let mut header = std::io::Cursor::new(&header[..]);
        let header = CocoonHeader::deserialize_from(&mut header).expect("Deserialized header");

        assert_eq!(header.config(), &CocoonConfig::default());
        assert_eq!(header.salt(), [1; 16]);
        assert_eq!(header.nonce(), [2; 12]);
        assert_eq!(header.data_length(), 50);
        assert_eq!(header.version(), CocoonVersion::Version1);
    }

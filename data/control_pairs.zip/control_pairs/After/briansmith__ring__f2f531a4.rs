    fn gather<M>(table: &[Limb], acc: &mut Elem<M, R>, i: Window5) {
        prefixed_extern! {
            fn LIMBS_select_512_32(
                r: *mut Limb,
                table: *const Limb,
                num_limbs: c::size_t,
                i: Window5,
            ) -> bssl::Result;
        }
        let acc_len = acc.limbs.len();
        let acc = acc.limbs.as_mut().as_mut_ptr();
        Result::from(unsafe { LIMBS_select_512_32(acc, table.as_ptr(), acc_len, i) }).unwrap();
    }
    fn with_potentially_dangling_non_null_pointers_ra<R>(
        self,
        expected_len: usize,
        f: impl FnOnce(*mut T, *const T) -> R,
    ) -> Result<R, LenMismatchError> {
        let r = self;
        if r.len() != expected_len {
            return Err(LenMismatchError::new(r.len()));
        }
        let r = r.as_mut_ptr();
        Ok(f(r, r.cast_const()))
    }

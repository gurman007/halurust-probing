pub struct IntoIter<T, N>
where
    N: ArrayLength<T>,
{
    vec: Vec<T, N>,
    next: usize,
}
    fn next(&mut self) -> Option<Self::Item> {
        if self.next < self.vec.len() {
            let buffer = self.vec.buffer.as_slice();
            let item = unsafe {ptr::read(buffer.get_unchecked(self.next))};
            self.next += 1;
            Some(item)
        } else {
            None
        }
    }
    fn drop() {

        droppable!();

        {
            let mut v: Vec<Droppable, U2> = Vec::new();
            v.push(Droppable::new()).ok().unwrap();
            v.push(Droppable::new()).ok().unwrap();
            v.pop().unwrap();
        }

        assert_eq!(unsafe { COUNT }, 0);

        {
            let mut v: Vec<Droppable, U2> = Vec::new();
            v.push(Droppable::new()).ok().unwrap();
            v.push(Droppable::new()).ok().unwrap();
        }

        assert_eq!(unsafe { COUNT }, 0);
    }
    fn into_iter(self) -> Self::IntoIter {
        IntoIter {
            vec: self,
            next: 0,
        }
    }
                fn new() -> Self {
                    unsafe {
                        COUNT += 1;
                    }
                    Droppable
                }
    fn iter_move_drop() {

        droppable!();

        {
            let mut vec: Vec<Droppable, U2> = Vec::new();
            vec.push(Droppable::new()).ok().unwrap();
            vec.push(Droppable::new()).ok().unwrap();
            let mut items = vec.into_iter();
            // Move all
            let _ = items.next();
            let _ = items.next();
        }

        assert_eq!(unsafe { COUNT }, 0);

        {
            let mut vec: Vec<Droppable, U2> = Vec::new();
            vec.push(Droppable::new()).ok().unwrap();
            vec.push(Droppable::new()).ok().unwrap();
            let _items = vec.into_iter();
            // Move none
        }

        assert_eq!(unsafe { COUNT }, 0);

        {
            let mut vec: Vec<Droppable, U2> = Vec::new();
            vec.push(Droppable::new()).ok().unwrap();
            vec.push(Droppable::new()).ok().unwrap();
            let mut items = vec.into_iter();
            let _ = items.next(); // Move partly
        }

        assert_eq!(unsafe { COUNT }, 0);

    }

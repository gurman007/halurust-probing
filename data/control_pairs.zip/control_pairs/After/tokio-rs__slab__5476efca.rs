pub struct Slab<T, I> {
    // Chunk of memory
    entries: Vec<Slot<T>>,

    // Number of Filled elements currently in the slab
    len: usize,

    // The index offset
    offset: usize,

    // Offset of the next available slot in the slab. Set to the slab's
    // capacity when the slab is full.
    next: usize,

    _marker: PhantomData<I>,
}
    pub fn new(capacity: usize) -> Slab<T, I> {
        Slab::new_starting_at(I::from(0), capacity)
    }
    pub fn new_starting_at(offset: I, capacity: usize) -> Slab<T, I> {
        assert!(capacity <= usize::MAX, "capacity too large");
        let entries = (1..capacity + 1)
            .map(Slot::Empty)
            .collect::<Vec<_>>();

        Slab {
            entries: entries,
            next: 0,
            len: 0,
            offset: offset.into(),
            _marker: PhantomData,
        }
    }
    pub fn retain<F>(&mut self, mut fun: F)
        where F: FnMut(&T) -> bool
    {
        for i in 0..self.len {
            let idx = I::from(i + self.offset);

            let _ = self.replace_with(idx, |x| {
                if fun(&x) {
                    Some(x)
                } else {
                    None
                }
            });
        }
    }
    fn insert_at(&mut self, idx: usize, value: T) -> I {
        let idx = idx - self.offset;

        self.next = match self.entries[idx] {
            Slot::Empty(next) => next,
            Slot::Filled(_) => panic!("Tried to insert into filled index"),
        };

        self.entries[idx] = Slot::Filled(value);
        self.len += 1;

        I::from(idx + self.offset)
    }
    fn local_index(&self, idx: I) -> Option<usize> {
        let idx: usize = idx.into();

        if idx < self.offset {
            return None;
        }

        let idx = idx - self.offset;

        if idx >= self.entries.capacity() {
            return None;
        }

        Some(idx)
    }
pub enum Entry<'slab, I: 'slab, T: 'slab> {
    Vacant(VacantEntry<'slab, I, T>),
    Occupied(OccupiedEntry<'slab, I, T>),
}
pub struct VacantEntry<'slab, I: 'slab, T: 'slab> {
    slab: &'slab mut Slab<T, I>,
    idx: usize,
}
    pub fn index(&self) -> I {
        I::from(self.idx)
    }
pub struct OccupiedEntry<'slab, I: 'slab, T: 'slab> {
    slab: &'slab mut Slab<T, I>,
    idx: usize,
}
pub struct SlabIter<'a, T: 'a, I: 'a> {
    slab: &'a Slab<T, I>,
    cur_idx: usize,
    yielded: usize,
}
pub struct SlabMutIter<'a, T: 'a, I: 'a> {
    iter: SlabIter<'a, T, I>,
}
        fn from(i: usize) -> MyIndex {
            MyIndex(i)
        }
        fn into(self) -> usize {
            self.0
        }

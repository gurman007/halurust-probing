pub fn command(options: Options) -> Result<()> {
  let Options { interactive } = options;

  let frontend_dir = resolve_frontend_dir();
  let tauri_dir = resolve_tauri_dir();

  if tauri_dir.is_some() {
    // safe to initialize
    crate::helpers::app_paths::resolve();
  }

  let package_manager = frontend_dir
    .as_ref()
    .map(packages_nodejs::package_manager)
    .unwrap_or(crate::helpers::npm::PackageManager::Npm);

  let metadata = version_metadata()?;

  let mut environment = Section {
    label: "Environment",
    interactive,
    items: Vec::new(),
  };
  environment.items.extend(env_system::items());
  environment.items.extend(env_rust::items());
  let items = env_nodejs::items(&metadata);
  environment.items.extend(items);

  let mut packages = Section {
    label: "Packages",
    interactive,
    items: Vec::new(),
  };
  packages.items.extend(packages_rust::items(
    frontend_dir.as_ref(),
    tauri_dir.as_deref(),
  ));
  packages.items.extend(packages_nodejs::items(
    frontend_dir.as_ref(),
    package_manager,
    &metadata,
  ));

  let mut plugins = Section {
    label: "Plugins",
    interactive,
    items: plugins::items(frontend_dir.as_ref(), tauri_dir.as_deref(), package_manager),
  };

  let mut app = Section {
    label: "App",
    interactive,
    items: Vec::new(),
  };
  app
    .items
    .extend(app::items(frontend_dir.as_ref(), tauri_dir.as_deref()));

  environment.display();

  packages.display();

  plugins.display();

  if let (Some(frontend_dir), Some(tauri_dir)) = (&frontend_dir, &tauri_dir) {
    if let Err(error) = plugins::check_mismatched_packages(frontend_dir, tauri_dir) {
      println!("\n{}: {error}", "Error".bright_red().bold());
    }
  }

  app.display();

  // iOS
  #[cfg(target_os = "macos")]
  {
    if let Some(p) = &tauri_dir {
      if p.join("gen/apple").exists() {
        let mut ios = Section {
          label: "iOS",
          interactive,
          items: Vec::new(),
        };
        ios.items.extend(ios::items());
        ios.display();
      }
    }
  }

  Ok(())
}
pub fn check_mismatched_packages(frontend_dir: &Path, tauri_path: &Path) -> crate::Result<()> {
  let installed_packages = installed_tauri_packages(
    frontend_dir,
    tauri_path,
    PackageManager::from_project(frontend_dir),
  );
  let mismatched_packages = installed_packages.mismatched();
  if mismatched_packages.is_empty() {
    return Ok(());
  }
  let mismatched_text = mismatched_packages
    .iter()
    .map(
      |InstalledPackage {
         crate_name,
         crate_version,
         npm_name,
         npm_version,
       }| format!("{crate_name} (v{crate_version}) : {npm_name} (v{npm_version})"),
    )
    .collect::<Vec<_>>()
    .join("\n");
  Err(Error::GenericError(format!("Found version mismatched Tauri packages. Make sure the NPM package and Rust crate versions are on the same major/minor releases:\n{mismatched_text}")))
}

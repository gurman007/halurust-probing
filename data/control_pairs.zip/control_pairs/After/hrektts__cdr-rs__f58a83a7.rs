    fn serialize_none(self) -> Result<Self::Ok> {
        Err(Error::TypeNotSupported)
    }
    fn serialize_some<T: ?Sized>(self, _v: &T) -> Result<Self::Ok>
    where
        T: ser::Serialize,
    {
        Err(Error::TypeNotSupported)
    }

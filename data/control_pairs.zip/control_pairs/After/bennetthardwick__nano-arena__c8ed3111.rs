    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> Result<(), std::fmt::Error> {
        formatter.write_str(&format!(
            "{}Idx ( {} )",
            if self.inner.removed.load(Ordering::Relaxed) {
                "Removed "
            } else {
                ""
            },
            self.inner.index.load(Ordering::Relaxed)
        ))
    }
    fn debug_printing() {
        let (mut arena, john, _, _, _) = setup_arena();

        assert_eq!(format!("{:?}", john), "Idx ( 0 )");

        arena.swap_remove(&john);

        assert_eq!(format!("{:?}", john), "Removed Idx ( 0 )");
    }
    fn split_at() {
        let (mut arena, john, julia, jane, jake) = setup_arena();

        let (j, mut arena) = arena.split_at(&julia).unwrap();

        assert_eq!(j, "Julia");
        assert!(arena.get_mut(john).is_some());
        assert!(arena.get_mut(jane).is_some());
        assert!(arena.get_mut(jake).is_some());

        assert!(arena.get_mut(julia).is_none());
    }

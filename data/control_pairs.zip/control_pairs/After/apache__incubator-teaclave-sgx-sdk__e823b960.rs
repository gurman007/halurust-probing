pub extern "C" fn llvm_gcda_start_file(orig_filename: *const c_char, version: u32, checksum: u32) {
    let file_name_str: &CStr = unsafe { CStr::from_ptr(orig_filename) };
    let file_name = file_name_str.to_str().unwrap();

    let mut prefix = String::from(file_name);
    prefix.truncate(file_name.len() - 5);
    let orig_gcno_name = format!("{}.gcno", prefix);
    let rnd = RND.lock().unwrap();
    let new_gcno_name = format!("{}.{:08x}.gcno", prefix, *rnd);
    let new_gcda_name = format!("{}.{:08x}.gcda", prefix, *rnd);

    GCDA_FILE
        .lock()
        .map_or_else(
            |e| panic!("llvm_gcda_emit_function failed {:?}", e),
            |tup| Ok(tup),
        )
        .and_then(|mut tup| {
            copy(orig_gcno_name, new_gcno_name)?;
            let mut file = match OpenOptions::new()
                .write(true)
                .append(false)
                .open(&new_gcda_name)
            {
                Ok(file) => file,
                Err(_) => File::create(&new_gcda_name)?,
            };

            let c3: u8 = ((version >> 24) & 0x000000FF) as u8;
            let c2: u8 = ((version >> 16) & 0x000000FF) as u8;
            let c1: u8 = ((version >> 8) & 0x000000FF) as u8;
            let parsed_gcov_version: u32 = if c3 >= 'A' as u8 {
                ((c3 - 'A' as u8) as u32) * 100
                    + ((c2 - '0' as u8) as u32) * 10
                    + (c1 - '0' as u8) as u32
            } else {
                ((c3 - '0' as u8) as u32) * 10 + (c1 - '0' as u8) as u32
            };

            tup.1 = parsed_gcov_version;

            file.write_all(&GCOV_DATA_MAGIC.to_le_bytes()).unwrap();
            file.write_all(&version.to_le_bytes()).unwrap();
            file.write_all(&checksum.to_le_bytes()).unwrap();

            tup.0 = file.into_raw_fd();

            Ok(())
        })
        .unwrap_or_else(|e: std::io::Error| panic!("llvm_gcda_start_file failed {:?}", e))
}

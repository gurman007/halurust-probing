    fn eq(&self, other: &NSMutableString) -> bool {
        other == self
    }
    fn partial_cmp(&self, other: &NSMutableString) -> Option<Ordering> {
        Some(other.partial_cmp(self)?.reverse())
    }

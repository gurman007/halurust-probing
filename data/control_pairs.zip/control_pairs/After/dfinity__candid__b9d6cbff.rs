pub(crate) fn export_service(path: Option<TokenStream>) -> TokenStream {
    if let Some(meths) = METHODS.lock().unwrap().as_mut() {
        let candid = candid_path(&path);
        let init = if let Some(opt_args) = INIT.lock().unwrap().as_mut() {
            let res = opt_args.as_ref().map(|args| {
                let args = args
                    .iter()
                    .map(|t| generate_arg(quote! { init_args }, t))
                    .collect::<Vec<_>>();
                quote! {
                    let mut init_args = Vec::new();
                    #(#args)*
                }
            });
            *opt_args = None;
            res
        } else {
            unreachable!();
        };
        let gen_tys = meths.iter().map(|(name, Method { args, rets, modes })| {
            let args = args
                .iter()
                .map(|t| generate_arg(quote! { args }, t))
                .collect::<Vec<_>>();
            let rets = rets
                .iter()
                .map(|t| generate_arg(quote! { rets }, t))
                .collect::<Vec<_>>();
            let modes = match modes.as_ref() {
                "query" => quote! { vec![#candid::types::FuncMode::Query] },
                "oneway" => quote! { vec![#candid::types::FuncMode::Oneway] },
                "update" => quote! { vec![] },
                _ => unreachable!(),
            };
            quote! {
                {
                    let mut args = Vec::new();
                    #(#args)*
                    let mut rets = Vec::new();
                    #(#rets)*
                    let func = Function { args, rets, modes: #modes };
                    service.push((#name.to_string(), TypeInner::Func(func).into()));
                }
            }
        });
        let service = quote! {
            use #candid::types::{CandidType, Function, Type, TypeInner};
            let mut service = Vec::<(String, Type)>::new();
            let mut env = #candid::types::internal::TypeContainer::new();
            #(#gen_tys)*
            service.sort_unstable_by_key(|(name, _)| name.clone());
            let ty = TypeInner::Service(service).into();
        };
        let actor = if let Some(init) = init {
            quote! {
                #init
                let actor = Some(TypeInner::Class(init_args, ty).into());
            }
        } else {
            quote! { let actor = Some(ty); }
        };
        let res = quote! {
            fn __export_service() -> String {
                #service
                #actor
                let result = #candid::bindings::candid::compile(&env.env, &actor);
                format!("{}", result)
            }
        };
        meths.clear();
        //panic!(res.to_string());
        res
    } else {
        unreachable!()
    }
}
pub fn export_service(input: TokenStream) -> TokenStream {
    if input.is_empty() {
        func::export_service(None).into()
    } else {
        func::export_service(Some(input.into())).into()
    }
}

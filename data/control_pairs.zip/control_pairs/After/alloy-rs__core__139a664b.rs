    fn accepts(ty: &Type) -> bool {
        matches!(
            *ty,
            Type::BOOL
                | Type::CHAR
                | Type::INT2
                | Type::INT4
                | Type::INT8
                | Type::OID
                | Type::FLOAT4
                | Type::FLOAT8
                | Type::MONEY
                | Type::NUMERIC
                | Type::BYTEA
                | Type::TEXT
                | Type::VARCHAR
                | Type::JSON
                | Type::JSONB
                | Type::BIT
                | Type::VARBIT
        )
    }

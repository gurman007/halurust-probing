    fn find_shell_immediately_at_start_process() {
        let tree = MockProcessTree {
            parents: HashMap::new(),
            names: HashMap::from([(100, "bash".to_string())]),
        };

        let shell = find_shell_in_process_tree(&tree, 100);
        assert!(matches!(shell, Some(Shell::Bash)));
    }
    fn find_shell_deep_in_tree() {
        let tree = MockProcessTree {
            parents: HashMap::from([(300, 200), (200, 100)]),
            names: HashMap::from([
                (100, "bash".to_string()),
                (200, "cargo".to_string()),
                (300, "my_cli_app".to_string()),
            ]),
        };

        let shell = find_shell_in_process_tree(&tree, 300);
        assert!(matches!(shell, Some(Shell::Bash)));
    }
    fn find_shell_skips_non_shell_processes() {
        let tree = MockProcessTree {
            parents: HashMap::from([(400, 300), (300, 200), (200, 100)]),
            names: HashMap::from([
                (100, "zsh".to_string()),
                (200, "node".to_string()),
                (300, "npm".to_string()),
                (400, "my_app".to_string()),
            ]),
        };

        let shell = find_shell_in_process_tree(&tree, 400);
        assert!(matches!(shell, Some(Shell::Zsh)));
    }
    fn no_shell_found_when_no_parent_pid() {
        let tree = MockProcessTree {
            parents: HashMap::new(),
            names: HashMap::from([(100, "cargo".to_string())]),
        };

        let shell = find_shell_in_process_tree(&tree, 100);
        assert!(matches!(shell, None));
    }
    fn no_shell_found_when_parent_pid_is_zero() {
        let tree = MockProcessTree {
            parents: HashMap::from([(100, 0)]),
            names: HashMap::from([
                (100, "cargo".to_string()),
                (0, "init".to_string()),
            ]),
        };

        let shell = find_shell_in_process_tree(&tree, 100);
        assert!(matches!(shell, None));
    }
    fn find_first_matching_shell_in_hierarchy() {
        let tree = MockProcessTree {
            parents: HashMap::from([(500, 400), (400, 300), (300, 200), (200, 100)]),
            names: HashMap::from([
                (100, "bash".to_string()),
                (200, "fish".to_string()),
                (300, "zsh".to_string()),
                (400, "cargo".to_string()),
                (500, "my_app".to_string()),
            ]),
        };

        let shell = find_shell_in_process_tree(&tree, 500);
        assert!(matches!(shell, Some(Shell::Zsh)));
    }
    fn no_shell_found_with_missing_exe_names() {
        let tree = MockProcessTree {
            parents: HashMap::from([(300, 200), (200, 100)]),
            names: HashMap::new(),
        };

        let shell = find_shell_in_process_tree(&tree, 300);
        assert!(matches!(shell, None));
    }
    fn no_shell_found_with_valid_shell_names() {
        let tree = MockProcessTree {
            parents: HashMap::from([(300, 200), (200, 100)]),
            names: HashMap::from([
                (100, "bash_unknown".to_string()),
                (200, "zsh_custom".to_string()),
                (300, "my_cli_app".to_string()),
            ]),
        };

        let shell = find_shell_in_process_tree(&tree, 300);
        assert!(matches!(shell, None));
    }
    fn find_fish_shell_in_process_tree() {
        let tree = MockProcessTree {
            parents: HashMap::from([(200, 100)]),
            names: HashMap::from([
                (100, "fish".to_string()),
                (200, "cargo".to_string()),
            ]),
        };

        let shell = find_shell_in_process_tree(&tree, 200);
        assert!(matches!(shell, Some(Shell::Fish)));
    }
    fn find_zsh_shell_in_process_tree() {
        let tree = MockProcessTree {
            parents: HashMap::from([(200, 100)]),
            names: HashMap::from([
                (100, "zsh".to_string()),
                (200, "cargo".to_string()),
            ]),
        };

        let shell = find_shell_in_process_tree(&tree, 200);
        assert!(matches!(shell, Some(Shell::Zsh)));
    }

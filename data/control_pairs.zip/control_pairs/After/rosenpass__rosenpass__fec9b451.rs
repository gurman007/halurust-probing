    fn test_zeroizing_secret_box_new() {
        struct DummyZeroizing {
            inner_dummy: [u8; 32],
        }
        impl Zeroize for DummyZeroizing {
            fn zeroize(&mut self) {
                self.inner_dummy = [0; 32];
            }
        }
        let dummy = DummyZeroizing {
            inner_dummy: [42; 32],
        };
        secret_policy_try_use_memfd_secrets();
        let mut zsb: ZeroizingSecretBox<DummyZeroizing> = ZeroizingSecretBox::new(dummy);
        zsb.zeroize();
        assert_eq!(zsb.inner_dummy, [0; 32]);
    }
    fn test_debug_secret() {
        secret_policy_try_use_memfd_secrets();
        let my_secret: Secret<32> = Secret::zero();
        assert_eq!(format!("{:?}", my_secret), "<SECRET>");
    }
    pub fn test_init_secret_memory_policy() {
        crate::internal::secret_memory::secret_policy_try_use_memfd_secrets();
    }
    fn test_broker_server() {
        secret_policy_try_use_memfd_secrets();
        let mock_broker = MockWireGuardBroker {
            psk: Secret::zero(),
        };
        let mut broker_server = BrokerServer::new(mock_broker);
        let mut iface_buf: [u8; 255] = [0; 255];
        // These are the utf encoded bytes of the string "wg0".
        iface_buf[0] = 119;
        iface_buf[1] = 103;
        iface_buf[2] = 48;
        let psk_req = SetPskRequest {
            psk: [0; 32],
            peer_id: [0; 32],
            iface_size: 3,
            iface_buf,
        };
        let req: Envelope<SetPskRequest> = Envelope {
            msg_type: 0x01, // The only valid value.
            reserved: [0, 0, 0],
            payload: psk_req,
        };
        let mut res: [u8; msgs::RESPONSE_MSG_BUFFER_SIZE] = [0; msgs::RESPONSE_MSG_BUFFER_SIZE];
        broker_server
            .handle_message(req.as_bytes(), &mut res)
            .unwrap();
    }
    fn smoke_test() -> Result<(), Box<dyn std::error::Error>> {
        secret_policy_try_use_memfd_secrets();
        let result = NetlinkWireGuardBroker::new();
        assert!(result.is_ok());
        let mut broker = result.unwrap();
        let peer_id = Public::zero();
        let psk = Secret::zero();
        let config: SerializedBrokerConfig = NetworkBrokerConfig {
            iface: "wg0",
            peer_id: &peer_id,
            psk: &psk,
        }
        .into();
        let result = broker.set_psk(config);
        assert!(result.is_err());
        Ok(())
    }

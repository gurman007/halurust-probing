pub struct MPSCConsumer<T, B: Buffer<T>> {
    queue: Arc<MPSCQueue<T, B>>,
    _not_sync: PhantomData<std::cell::Cell<()>>
}
pub fn mpsc_queue<T, B: Buffer<T>>(buf: B) -> (MPSCProducer<T, B>, MPSCConsumer<T, B>) {
    let queue = MPSCQueue {
        head: CachePadded::new(AtomicPair::default()),
        tail: CachePadded::new(AtomicUsize::new(0)),
        buf,
        consumer: AtomicBool::new(true),
        _marker: PhantomData,
    };

    let queue = Arc::new(queue);

    (
        MPSCProducer {
            queue: queue.clone(),
        },
        MPSCConsumer { queue, _not_sync: PhantomData },
    )
}
pub struct SPMCProducer<T, B: Buffer<T>> {
    queue: Arc<SPMCQueue<T, B>>,
    _not_sync: PhantomData<std::cell::Cell<()>>
}
pub fn spmc_queue<T, B: Buffer<T>>(buf: B) -> (SPMCProducer<T, B>, SPMCConsumer<T, B>) {
    let queue = SPMCQueue {
        head: CachePadded::new(AtomicUsize::new(0)),
        tail: CachePadded::new(AtomicPair::default()),
        buf,
        producer: AtomicBool::new(true),
        _marker: PhantomData,
    };

    let queue = Arc::new(queue);

    (
        SPMCProducer {
            queue: queue.clone(),
            _not_sync: PhantomData,
        },
        SPMCConsumer { queue },
    )
}
pub struct SPSCConsumer<T, B: Buffer<T>> {
    queue: Arc<SPSCQueue<T, B>>,
    _not_sync: PhantomData<std::cell::Cell<()>>
}
pub struct SPSCProducer<T, B: Buffer<T>> {
    queue: Arc<SPSCQueue<T, B>>,
    _not_sync: PhantomData<std::cell::Cell<()>>
}
pub fn spsc_queue<T, B: Buffer<T>>(buf: B) -> (SPSCProducer<T, B>, SPSCConsumer<T, B>) {
    let queue = SPSCQueue {
        head: CachePadded::new(AtomicUsize::new(0)),
        tail: CachePadded::new(AtomicUsize::new(0)),
        buf,
        _marker: PhantomData,
    };

    let queue = Arc::new(queue);

    (
        SPSCProducer {
            queue: queue.clone(),
            _not_sync: PhantomData,
        },
        SPSCConsumer { queue, _not_sync: PhantomData },
    )
}

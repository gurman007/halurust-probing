fn check_api_integrity<T: QueryResponses + ?Sized>(
    generated_queries: BTreeSet<String>,
) -> Result<(), IntegrityError> {
    let schema = crate::schema_for!(T);

    // something more readable below?

    let schema_queries: BTreeSet<_> = match schema.schema.subschemas {
        Some(subschemas) => subschemas
            .one_of
            .ok_or(IntegrityError::InvalidQueryMsgSchema)?
            .into_iter()
            .map(|s| {
                let s = s.into_object();

                if let Some(SingleOrVec::Single(ty)) = s.instance_type {
                    match *ty {
                        // We'll have an object if the Rust enum variant was C-like or tuple-like
                        InstanceType::Object => s
                            .object
                            .ok_or(IntegrityError::InvalidQueryMsgSchema)?
                            .required
                            .into_iter()
                            .next()
                            .ok_or(IntegrityError::InvalidQueryMsgSchema),
                        // We might have a string here if the Rust enum variant was unit-like
                        InstanceType::String => {
                            let values =
                                s.enum_values.ok_or(IntegrityError::InvalidQueryMsgSchema)?;

                            if values.len() != 1 {
                                return Err(IntegrityError::InvalidQueryMsgSchema);
                            }

                            values[0]
                                .as_str()
                                .map(String::from)
                                .ok_or(IntegrityError::InvalidQueryMsgSchema)
                        }
                        _ => Err(IntegrityError::InvalidQueryMsgSchema),
                    }
                } else {
                    Err(IntegrityError::InvalidQueryMsgSchema)
                }
            })
            .collect::<Result<_, _>>()?,
        None => BTreeSet::new(),
    };

    if schema_queries != generated_queries {
        return Err(IntegrityError::InconsistentQueries {
            query_msg: schema_queries,
            responses: generated_queries,
        });
    }

    Ok(())
}
    pub enum GoodMsg {
        BalanceFor { account: String },
        AccountIdFor { account: String },
        Supply {},
        Liquidity,
        AccountCount(),
    }
        fn response_schemas_impl() -> BTreeMap<String, RootSchema> {
            BTreeMap::from([
                ("balance_for".to_string(), schema_for!(u128)),
                ("account_id_for".to_string(), schema_for!(u128)),
                ("supply".to_string(), schema_for!(u128)),
                ("liquidity".to_string(), schema_for!(u128)),
                ("account_count".to_string(), schema_for!(u128)),
            ])
        }
    fn good_msg_works() {
        let response_schemas = GoodMsg::response_schemas().unwrap();
        assert_eq!(
            response_schemas,
            BTreeMap::from([
                ("balance_for".to_string(), schema_for!(u128)),
                ("account_id_for".to_string(), schema_for!(u128)),
                ("supply".to_string(), schema_for!(u128)),
                ("liquidity".to_string(), schema_for!(u128)),
                ("account_count".to_string(), schema_for!(u128))
            ])
        );
    }

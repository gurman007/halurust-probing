    pub(crate) fn run(&self) -> Result<()> {
        if let Some(jobs) = self.jobs {
            rayon::ThreadPoolBuilder::new()
                .num_threads(usize::from(jobs))
                .build_global()
                .context(error::InitializeThreadPool)?;
        }

        let root_buf = std::fs::read(&self.root).context(error::FileRead { path: &self.root })?;
        let root = serde_json::from_slice::<Signed<Root>>(&root_buf)
            .context(error::FileParseJson { path: &self.root })?
            .signed;
        let mut root_sha256 = [0; SHA256_OUTPUT_LEN];
        root_sha256.copy_from_slice(digest(&SHA256, &root_buf).as_ref());
        let root_length = root_buf.len() as u64;

        CreateProcess {
            args: self,
            keys: keys_for_root(&self.keys, &root)?,
            rng: SystemRandom::new(),
            root,
            root_sha256,
            root_length,
        }
        .run()
    }
struct CreateProcess<'a> {
    args: &'a CreateArgs,
    rng: SystemRandom,
    root: Root,
    root_sha256: [u8; SHA256_OUTPUT_LEN],
    root_length: u64,
    keys: RootKeys,
}
    fn process_target(&self, path: &Path) -> Result<(String, Target)> {
        let target_name = path.strip_prefix(&self.args.indir).context(error::Prefix {
            path,
            base: &self.args.indir,
        })?;
        let target_name = target_name
            .to_str()
            .context(error::PathUtf8 { path: target_name })?
            .to_owned();

        let mut file = File::open(path).context(error::FileOpen { path })?;
        let mut digest = Context::new(&SHA256);
        let mut buf = [0; 8 * 1024];
        let mut length = 0;
        loop {
            match file.read(&mut buf).context(error::FileRead { path })? {
                0 => break,
                n => {
                    digest.update(&buf[..n]);
                    length += n as u64;
                }
            }
        }

        let target = Target {
            length,
            hashes: Hashes {
                sha256: Decoded::from(digest.finish().as_ref().to_vec()),
                _extra: HashMap::new(),
            },
            custom: HashMap::new(),
            _extra: HashMap::new(),
        };

        let dst = if self.root.consistent_snapshot {
            self.args.outdir.join("targets").join(format!(
                "{}.{}",
                hex::encode(&target.hashes.sha256),
                target_name
            ))
        } else {
            self.args.outdir.join("targets").join(&target_name)
        };
        self.copy_action()
            .run(path, &dst)
            .context(error::FileCopy {
                action: self.copy_action(),
                src: path,
                dst,
            })?;

        Ok((target_name, target))
    }
    fn write_metadata<T: Role + Serialize>(
        &self,
        role: T,
        version: NonZeroU64,
        filename: &'static str,
    ) -> Result<([u8; SHA256_OUTPUT_LEN], u64)> {
        let metadir = self.args.outdir.join("metadata");
        std::fs::create_dir_all(&metadir).context(error::FileCreate { path: &metadir })?;

        let path = metadir.join(
            if T::TYPE != RoleType::Timestamp && self.root.consistent_snapshot {
                format!("{}.{}", version, filename)
            } else {
                filename.to_owned()
            },
        );

        let mut role = Signed {
            signed: role,
            signatures: Vec::new(),
        };
        self.sign_metadata(&mut role)?;

        let mut buf =
            serde_json::to_vec_pretty(&role).context(error::FileWriteJson { path: &path })?;
        buf.push(b'\n');
        std::fs::write(&path, &buf).context(error::FileCreate { path: &path })?;

        let mut sha256 = [0; SHA256_OUTPUT_LEN];
        sha256.copy_from_slice(digest(&SHA256, &buf).as_ref());
        Ok((sha256, buf.len() as u64))
    }

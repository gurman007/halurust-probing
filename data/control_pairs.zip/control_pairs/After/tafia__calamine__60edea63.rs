    pub fn worksheet_range(&mut self, name: &str) -> Result<Range> {
        try!(self.read_shared_strings());
        try!(self.read_relationships());
        try!(self.read_sheets_names());
        let strings = &self.strings;
        let z = match self.zip {
            FileType::CFB(_) => return Err("worksheet_range not implemented for CFB files".into()),
            FileType::Zip(ref mut z) => z
        };
        let ws = match self.sheets.get(name) {
            Some(p) => try!(z.by_name(p)),
            None => return Err(format!("Sheet '{}' does not exist", name).into()),
        };
        Range::from_worksheet(ws, strings)
    }
    fn from_worksheet(xml: ZipFile, strings: &[String]) -> Result<Range> {
        let mut xml = XmlReader::from_reader(BufReader::new(xml))
            .with_check(false)
            .trim_text(false);
        let mut data = Range::default();
        while let Some(res_event) = xml.next() {
            match res_event {
                Err(e) => return Err(e.into()),
                Ok(Event::Start(ref e)) => {
                    match e.name() {
                        b"dimension" => {
                            let mut dim = None;
                            for a in e.attributes() {
                                if let (b"ref", rdim) = try!(a) {
                                    dim = Some(rdim);
                                    break;
                                }
                            }
                            match dim {
                                None => return Err(format!("Expecting dimension, got {:?}", e).into()),
                                Some(dim) => {
                                    let (position, size) = try!(get_dimension(dim));
                                    data.position = position;
                                    data.size = (size.0 as usize, size.1 as usize);
                                    data.inner.reserve_exact(data.size.0 * data.size.1);
                                }
                            }
                        },
                        b"sheetData" => try!(data.read_sheet_data(&mut xml, strings)),
                        _ => (),
                    }
                },
                _ => (),
            }
        }
        data.inner.shrink_to_fit();
        Ok(data)
    }
    fn read_sheet_data(&mut self, xml: &mut XmlReader<BufReader<ZipFile>>, strings: &[String]) 
        -> Result<()> 
    {
        while let Some(res_event) = xml.next() {
            match res_event {
                Err(e) => return Err(e.into()),
                Ok(Event::Start(ref c_element)) => {
                    if c_element.name() == b"c" {
                        loop {
                            match xml.next() {
                                Some(Err(e)) => return Err(e.into()),
                                Some(Ok(Event::Start(ref e))) => match e.name() {
                                    b"v" => {
                                        // value
                                        let v = try!(xml.read_text(b"v"));
                                        let value = match c_element.attributes()
                                            .filter_map(|a| a.ok())
                                            .find(|&(k, _)| k == b"t") {
                                                Some((_, b"s")) => {
                                                    // shared string
                                                    let idx: usize = try!(v.parse());
                                                    DataType::String(strings[idx].clone())
                                                },
                                                Some((_, b"str")) => {
                                                    // regular string
                                                    DataType::String(v)
                                                },
                                                Some((_, b"b")) => {
                                                    // boolean
                                                    DataType::Bool(v != "0")
                                                },
                                                Some((_, b"e")) => {
                                                    // error
                                                    DataType::Error(parse_error(v.as_ref()))
                                                },
                                                _ => match v.parse() {
                                                    // TODO: check in styles to know which type is
                                                    // supposed to be used
                                                    Ok(i) => DataType::Int(i),
                                                    Err(_) => try!(v.parse().map(DataType::Float)),
                                                },
                                            };
                                        self.inner.push(value);
                                        break;
                                    },
                                    b"f" => (), // formula, ignore
                                    _name => return Err("not v or f node".into()),
                                },
                                Some(Ok(Event::End(ref e))) => {
                                    if e.name() == b"c" {
                                        self.inner.push(DataType::Empty);
                                        break;
                                    }
                                }
                                None => return Err("End of xml".into()),
                                _ => (),
                            }
                        }
                    }
                },
                Ok(Event::End(ref e)) if e.name() == b"sheetData" => return Ok(()),
                _ => (),
            }
        }
        Err("Could not find </sheetData>".into())
    }
fn get_dimension(dimension: &[u8]) -> Result<((u32, u32), (u32, u32))> {
    let parts: Vec<_> = try!(dimension.split(|c| *c == b':')
        .map(|s| get_row_column(s))
        .collect::<Result<Vec<_>>>());

    match parts.len() {
        0 => Err("dimension cannot be empty".into()),
        1 => Ok((parts[0], (1, 1))),
        2 => Ok((parts[0], (parts[1].0 - parts[0].0 + 1, parts[1].1 - parts[0].1 + 1))),
        len => Err(format!("range dimension has 0 or 1 ':', got {}", len).into()),
    }
}
fn get_row_column(range: &[u8]) -> Result<(u32, u32)> {
    let (mut row, mut col) = (0, 0);
    let mut pow = 1;
    let mut readrow = true;
    for c in range.iter().rev() {
        match *c {
            c @ b'0'...b'9' => {
                if readrow {
                    row += ((c - b'0') as u32) * pow;
                    pow *= 10;
                } else {
                    return Err(format!("Numeric character are only allowed \
                        at the end of the range: {:x}", c).into());
                }
            }
            c @ b'A'...b'Z' => {
                if readrow { 
                    pow = 1;
                    readrow = false;
                }
                col += ((c - b'A') as u32 + 1) * pow;
                pow *= 26;
            },
            c @ b'a'...b'z' => {
                if readrow { 
                    pow = 1;
                    readrow = false;
                }
                col += ((c - b'a') as u32 + 1) * pow;
                pow *= 26;
            },
            _ => return Err(format!("Expecting alphanumeric character, got {:x}", c).into()),
        }
    }
    Ok((row, col))
}
fn test_dimensions() {
    assert_eq!(get_row_column(b"A1").unwrap(), (1, 1));
    assert_eq!(get_row_column(b"C107").unwrap(), (107, 3));
    assert_eq!(get_dimension(b"C2:D35").unwrap(), ((2, 3), (34, 2)));
}
fn test_parse_error() {
    assert_eq!(parse_error("#DIV/0!"), CellErrorType::Div0);
    assert_eq!(parse_error("#N/A"), CellErrorType::NA);
    assert_eq!(parse_error("#NAME?"), CellErrorType::Name);
    assert_eq!(parse_error("#NULL!"), CellErrorType::Null);
    assert_eq!(parse_error("#NUM!"), CellErrorType::Num);
    assert_eq!(parse_error("#REF!"), CellErrorType::Ref);
    assert_eq!(parse_error("#VALUE!"), CellErrorType::Value);
}

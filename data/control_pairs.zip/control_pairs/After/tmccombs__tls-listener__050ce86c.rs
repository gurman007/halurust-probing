pub struct TlsListener<I>
where
    I: Stream,
{
    listener: I,
    tls: TlsAcceptor,
    rcv: Receiver<StreamItem<I::Item>>,
    tx: Sender<StreamItem<I::Item>>,
    max_pending: usize,
    pending_connections: usize,
}
pub enum Error<E> {
    /**
     * An error that occurred during the TLS handshake.
     */
    Tls(native_tls::Error),
    /**
     * An error that occured while accepting a new connection. This
     */
    Accept(E),
}
    fn from(err: native_tls::Error) -> Self {
        Error::Tls(err)
    }
    fn poll(&mut self) -> Poll<Option<Self::Item>, Self::Error> {
        // prioritize ready connections over new connections
        loop {
            match self.rcv.poll().unwrap() {
                Async::Ready(Some(stream)) => {
                    self.pending_connections -= 1;
                    return Ok(Async::Ready(Some(stream?)));
                }
                Async::NotReady => {
                    if self.pending_connections < self.max_pending {
                        if let Some(conn) = try_ready!(self.listener.poll().map_err(Error::Accept))
                        {
                            let accept = self.tls.accept(conn);
                            let tx = self.tx.clone();
                            self.pending_connections += 1;
                            spawn(accept.then(move |result| tx.send(result)).then(|_| Ok(())))
                        } else {
                            // this is unlikely to happen
                            return Ok(Async::Ready(None));
                        }
                    } else {
                        // We've filled up the queue of connections that still need a tls handshake,
                        // so return not-ready
                        return Ok(Async::NotReady);
                    }
                }
                Async::Ready(None) => unreachable!(),
            }
        }
    }
    pub fn new(identity: Identity) -> Self {
        Builder {
            tls: native_tls::TlsAcceptor::builder(identity),
            max_pending: DEFAULT_MAX_PENDING,
        }
    }
    pub fn build<I>(&self, incoming: I) -> native_tls::Result<TlsListener<I>>
    where
        I: Stream,
        I::Item: AsyncRead + AsyncWrite + Send,
    {
        self.tls
            .build()
            .map(|tls| TlsListener::new(incoming, tls.into(), self.max_pending))
    }

    pub struct Codec<Req, Resp> {
        /// Max request size in bytes.
        request_size_maximum: u64,
        /// Max response size in bytes.
        response_size_maximum: u64,
        phantom: PhantomData<(Req, Resp)>,
    }
        fn default() -> Self {
            Codec {
                request_size_maximum: 1024 * 1024,
                response_size_maximum: 10 * 1024 * 1024,
                phantom: PhantomData,
            }
        }
        fn clone(&self) -> Self {
            Self {
                request_size_maximum: self.request_size_maximum,
                response_size_maximum: self.response_size_maximum,
                phantom: PhantomData,
            }
        }
        pub fn set_request_size_maximum(mut self, request_size_maximum: u64) -> Self {
            self.request_size_maximum = request_size_maximum;
            self
        }
        pub fn set_response_size_maximum(mut self, response_size_maximum: u64) -> Self {
            self.response_size_maximum = response_size_maximum;
            self
        }
        async fn read_request<T>(&mut self, _: &Self::Protocol, io: &mut T) -> io::Result<Req>
        where
            T: AsyncRead + Unpin + Send,
        {
            let mut vec = Vec::new();

            io.take(self.request_size_maximum)
                .read_to_end(&mut vec)
                .await?;

            cbor4ii::serde::from_slice(vec.as_slice()).map_err(decode_into_io_error)
        }
        async fn read_response<T>(&mut self, _: &Self::Protocol, io: &mut T) -> io::Result<Resp>
        where
            T: AsyncRead + Unpin + Send,
        {
            let mut vec = Vec::new();

            io.take(self.response_size_maximum)
                .read_to_end(&mut vec)
                .await?;

            cbor4ii::serde::from_slice(vec.as_slice()).map_err(decode_into_io_error)
        }
    pub struct Codec<Req, Resp> {
        /// Max request size in bytes
        request_size_maximum: u64,
        /// Max response size in bytes
        response_size_maximum: u64,
        phantom: PhantomData<(Req, Resp)>,
    }
        fn default() -> Self {
            Codec {
                request_size_maximum: 1024 * 1024,
                response_size_maximum: 10 * 1024 * 1024,
                phantom: PhantomData,
            }
        }
        fn clone(&self) -> Self {
            Self {
                request_size_maximum: self.request_size_maximum,
                response_size_maximum: self.response_size_maximum,
                phantom: self.phantom,
            }
        }
        pub fn set_request_size_maximum(mut self, request_size_maximum: u64) -> Self {
            self.request_size_maximum = request_size_maximum;
            self
        }
        pub fn set_response_size_maximum(mut self, response_size_maximum: u64) -> Self {
            self.response_size_maximum = response_size_maximum;
            self
        }
        async fn read_request<T>(&mut self, _: &Self::Protocol, io: &mut T) -> io::Result<Req>
        where
            T: AsyncRead + Unpin + Send,
        {
            let mut vec = Vec::new();

            io.take(self.request_size_maximum)
                .read_to_end(&mut vec)
                .await?;

            Ok(serde_json::from_slice(vec.as_slice())?)
        }
        async fn read_response<T>(&mut self, _: &Self::Protocol, io: &mut T) -> io::Result<Resp>
        where
            T: AsyncRead + Unpin + Send,
        {
            let mut vec = Vec::new();

            io.take(self.response_size_maximum)
                .read_to_end(&mut vec)
                .await?;

            Ok(serde_json::from_slice(vec.as_slice())?)
        }

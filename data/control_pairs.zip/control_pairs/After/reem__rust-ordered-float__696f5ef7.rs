                fn sample<R: Rng + ?Sized>(&self, rng: &mut R) -> Self::X {
                    OrderedFloat(self.0.sample(rng))
                }
                fn new<B1, B2>(low: B1, high: B2) -> Self
                    where B1: SampleBorrow<Self::X> + Sized,
                        B2: SampleBorrow<Self::X> + Sized
                {
                    UniformOrdered(UniformFloat::<$f>::new(low.borrow().0, high.borrow().0))
                }
                fn new_inclusive<B1, B2>(low: B1, high: B2) -> Self
                    where B1: SampleBorrow<Self::X> + Sized,
                        B2: SampleBorrow<Self::X> + Sized
                {
                    UniformSampler::new(low, high)
                }
    fn sample_fuzz<T>()
    where
        Standard: Distribution<NotNan<T>>,
        Open01: Distribution<NotNan<T>>,
        OpenClosed01: Distribution<NotNan<T>>,
        Standard: Distribution<OrderedFloat<T>>,
        Open01: Distribution<OrderedFloat<T>>,
        OpenClosed01: Distribution<OrderedFloat<T>>,
        T: super::Float,
    {
        let mut rng = rand::thread_rng();
        let f1: NotNan<T> = rng.sample(Standard);
        let f2: NotNan<T> = rng.sample(Open01);
        let f3: NotNan<T> = rng.sample(OpenClosed01);
        let _: OrderedFloat<T> = rng.sample(Standard);
        let _: OrderedFloat<T> = rng.sample(Open01);
        let _: OrderedFloat<T> = rng.sample(OpenClosed01);
        assert!(!f1.into_inner().is_nan());
        assert!(!f2.into_inner().is_nan());
        assert!(!f3.into_inner().is_nan());
    }
    fn sampling_f32_does_not_panic() {
        sample_fuzz::<f32>();
    }
    fn sampling_f64_does_not_panic() {
        sample_fuzz::<f64>();
    }
    fn uniform_sampling_panic_on_infinity_notnan() {
        let (low, high) = (NotNan::new(0f64).unwrap(), NotNan::new(f64::INFINITY).unwrap());
        let uniform = Uniform::new(low,high);
        let _ = uniform.sample(&mut rand::thread_rng());
    }
    fn uniform_sampling_panic_on_infinity_ordered() {
        let (low, high) = (OrderedFloat(0f64), OrderedFloat(f64::INFINITY));
        let uniform = Uniform::new(low,high);
        let _ = uniform.sample(&mut rand::thread_rng());
    }
    fn uniform_sampling_panic_on_nan_ordered() {
        let (low, high) = (OrderedFloat(0f64), OrderedFloat(f64::NAN));
        let uniform = Uniform::new(low,high);
        let _ = uniform.sample(&mut rand::thread_rng());
    }

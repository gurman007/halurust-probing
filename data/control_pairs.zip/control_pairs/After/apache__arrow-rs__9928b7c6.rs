pub fn try_binary<A: ArrayAccessor, B: ArrayAccessor, F, O>(
    a: A,
    b: B,
    op: F,
) -> Result<PrimitiveArray<O>, ArrowError>
where
    O: ArrowPrimitiveType,
    F: Fn(A::Item, B::Item) -> Result<O::Native, ArrowError>,
{
    if a.len() != b.len() {
        return Err(ArrowError::ComputeError(
            "Cannot perform a binary operation on arrays of different length".to_string(),
        ));
    }
    if a.is_empty() {
        return Ok(PrimitiveArray::from(ArrayData::new_empty(&O::DATA_TYPE)));
    }
    let len = a.len();

    // Physical nulls are not the whole story: a `RunArray` or `DictionaryArray` can have
    // logical nulls in its values while its own null buffer is absent. `is_nullable` covers
    // those, but is allowed to be conservative, so the union of the logical nulls can still
    // be empty.
    if !a.is_nullable() && !b.is_nullable() {
        try_binary_no_nulls(len, a, b, op)
    } else {
        let Some(nulls) = NullBuffer::union(a.logical_nulls().as_ref(), b.logical_nulls().as_ref())
        else {
            return try_binary_no_nulls(len, a, b, op);
        };

        let mut buffer = BufferBuilder::<O::Native>::new(len);
        buffer.append_n_zeroed(len);
        let slice = buffer.as_slice_mut();

        nulls.try_for_each_valid_idx(|idx| {
            unsafe {
                *slice.get_unchecked_mut(idx) = op(a.value_unchecked(idx), b.value_unchecked(idx))?
            };
            Ok::<_, ArrowError>(())
        })?;

        let values = buffer.finish().into();
        Ok(PrimitiveArray::new(values, Some(nulls)))
    }
}
pub fn try_binary_mut<T, F>(
    a: PrimitiveArray<T>,
    b: &PrimitiveArray<T>,
    op: F,
) -> Result<Result<PrimitiveArray<T>, ArrowError>, PrimitiveArray<T>>
where
    T: ArrowPrimitiveType,
    F: Fn(T::Native, T::Native) -> Result<T::Native, ArrowError>,
{
    if a.len() != b.len() {
        return Ok(Err(ArrowError::ComputeError(
            "Cannot perform binary operation on arrays of different length".to_string(),
        )));
    }
    let len = a.len();

    if a.is_empty() {
        return Ok(Ok(PrimitiveArray::from(ArrayData::new_empty(
            &T::DATA_TYPE,
        ))));
    }

    // Physical and logical nulls coincide for a `PrimitiveArray`, but gate on `is_nullable` to
    // match `try_binary`. That check is allowed to be conservative, so fall back to the no-nulls
    // path when the union of the logical nulls turns out to be empty, instead of unwrapping it.
    if !a.is_nullable() && !b.is_nullable() {
        try_binary_no_nulls_mut(len, a, b, op)
    } else {
        let Some(nulls) =
            create_union_null_buffer(a.logical_nulls().as_ref(), b.logical_nulls().as_ref())
        else {
            return try_binary_no_nulls_mut(len, a, b, op);
        };

        let mut builder = a.into_builder()?;

        let slice = builder.values_slice_mut();

        let r = nulls.try_for_each_valid_idx(|idx| {
            unsafe {
                *slice.get_unchecked_mut(idx) =
                    op(*slice.get_unchecked(idx), b.value_unchecked(idx))?
            };
            Ok::<_, ArrowError>(())
        });
        if let Err(err) = r {
            return Ok(Err(err));
        }
        let array_builder = builder.finish().into_data().into_builder();
        let array_data = unsafe { array_builder.nulls(Some(nulls)).build_unchecked() };
        Ok(Ok(PrimitiveArray::<T>::from(array_data)))
    }
}
    fn test_try_binary_run_array_logical_nulls() {
        // A `RunArray` has no null buffer of its own, so its logical nulls live in the values.
        let run_ends = Int32Array::from(vec![1, 2, 3]);
        let values = Int32Array::from(vec![Some(10), None, Some(30)]);
        let run = RunArray::<Int32Type>::try_new(&run_ends, &values).expect("valid run array");
        assert_eq!(run.null_count(), 0);
        assert_eq!(run.logical_null_count(), 1);

        let typed = run.downcast::<Int32Array>().expect("Int32 values");
        let other = Int32Array::from(vec![1, 1, 1]);
        let result =
            try_binary::<_, _, _, Int32Type>(typed, &other, |a, b| Ok(a + b)).expect("no overflow");
        assert_eq!(result, Int32Array::from(vec![Some(11), None, Some(31)]));
    }
    fn test_try_binary_mut_all_valid_null_buffers() {
        // Both arrays carry a null buffer with no nulls in it: the no-nulls path must still run.
        let a = Int32Array::new(vec![1, 2].into(), Some(vec![true, true].into()));
        let b = Int32Array::new(vec![10, 20].into(), Some(vec![true, true].into()));
        let c = try_binary_mut(a, &b, |a, b| Ok(a + b))
            .expect("not shared")
            .expect("no overflow");
        assert_eq!(c, Int32Array::from(vec![11, 22]));
        assert_eq!(c.logical_null_count(), 0);
    }

    unsafe fn direct_class() -> &'static Class;
    fn class() -> &'static Class {
        // SAFETY: We're immediately registering this class with the runtime.
        let class = unsafe { <Self as ClassType>::direct_class() };
        class.as_object().class()
    }
            unsafe fn direct_class() -> &'static $crate::objc::Class {
                $crate::_objc_class!(@ $class_symbol)
            }

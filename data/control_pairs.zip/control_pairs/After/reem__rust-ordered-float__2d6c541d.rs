        fn is_valid_bit_pattern(bits: &Self::Bits) -> bool {
            !bits.is_nan()
        }
    fn test_not_nan_bit_pattern() {
        use bytemuck::checked::{try_cast, CheckedCastError};

        let nan = f64::NAN;
        assert_eq!(
            try_cast::<f64, NotNan<f64>>(nan),
            Err(CheckedCastError::InvalidBitPattern),
        );

        let pi = core::f64::consts::PI;
        assert!(try_cast::<f64, NotNan<f64>>(pi).is_ok());
    }

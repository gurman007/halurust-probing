    fn from_pyarrow_bound(value: &Bound<PyAny>) -> PyResult<Self> {
        // Newer versions of PyArrow as well as other libraries with Arrow data implement this
        // method, so prefer it over _export_to_c.
        // See https://arrow.apache.org/docs/format/CDataInterface/PyCapsuleInterface.html
        if let Some(capsule) =
            call_capsule_method_if_exists(value, intern!(value.py(), "__arrow_c_stream__"))?
        {
            let stream_ptr =
                extract_capsule(&capsule, c"arrow_array_stream", "__arrow_c_stream__")?;
            let stream = unsafe { FFI_ArrowArrayStream::from_raw(stream_ptr.as_ptr()) };

            let stream_reader = ArrowArrayStreamReader::try_new(stream)
                .map_err(|err| PyValueError::new_err(err.to_string()))?;

            return Ok(stream_reader);
        }

        validate_class(record_batch_reader_class(value.py())?, value)?;

        // prepare the stream struct to receive the content
        let mut stream = FFI_ArrowArrayStream::empty();

        // make the conversion through PyArrow's private API
        // this changes the pointer's memory and is thus unsafe.
        // In particular, `_export_to_c` can go out of bounds
        value.call_method1(
            intern!(value.py(), "_export_to_c"),
            (&raw mut stream as Py_uintptr_t,),
        )?;

        ArrowArrayStreamReader::try_new(stream)
            .map_err(|err| PyValueError::new_err(err.to_string()))
    }
    fn to_pyarrow<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyAny>> {
        // Workaround apache/arrow#37669 by returning RecordBatchIterator
        let reader = RecordBatchIterator::new(vec![Ok(self.clone())], self.schema());
        let reader: Box<dyn RecordBatchReader + Send> = Box::new(reader);
        let py_reader = reader.into_pyarrow(py)?;
        py_reader.call_method0(intern!(py, "read_next_batch"))
    }
    fn into_pyarrow<'py>(self, py: Python<'py>) -> PyResult<Bound<'py, PyAny>> {
        let stream = FFI_ArrowArrayStream::new(self);
        record_batch_reader_class(py)?.call_method1(
            intern!(py, "_import_from_c"),
            (&raw const stream as Py_uintptr_t,),
        )
    }
fn call_capsule_method_if_exists<'py>(
    object: &Bound<'py, PyAny>,
    method_name: &Bound<'py, PyString>,
) -> PyResult<Option<Bound<'py, PyCapsule>>> {
    let Some(method) = object.getattr_opt(method_name)? else {
        return Ok(None);
    };
    Ok(Some(method.call0()?.extract().map_err(
        |e: CastError| {
            wrapping_type_error(
                object.py(),
                e.into(),
                format!("Expected {method_name} to return a capsule."),
            )
        },
    )?))
}
fn call_arrow_c_array_method_if_exists<'py>(
    object: &Bound<'py, PyAny>,
) -> PyResult<Option<(Bound<'py, PyCapsule>, Bound<'py, PyCapsule>)>> {
    let Some(method) = object.getattr_opt(intern!(object.py(), "__arrow_c_array__"))? else {
        return Ok(None);
    };
    Ok(Some(method.call0()?.extract().map_err(|e| {
        wrapping_type_error(
            object.py(),
            e,
            "Expected __arrow_c_array__ to return a tuple of (schema, array) capsules.".into(),
        )
    })?))
}
fn record_batch_reader_class(py: Python<'_>) -> PyResult<&Bound<'_, PyType>> {
    static TYPE: PyOnceLock<Py<PyType>> = PyOnceLock::new();
    TYPE.import(py, "pyarrow", "RecordBatchReader")
}

    pub fn append_clone<'marker, T, U, IntoIteratorT, IteratorT, RefT>(
        &'marker self,
        allocation: Allocation<'marker, U>,
        values: IntoIteratorT,
    ) -> Result<Allocation<'marker, [T]>, Error<(Allocation<'marker, U>,)>>
    where
        T: Clone,
        U: ?Sized,
        Allocation<'marker, U>: IntoSliceAllocation<'marker, T>,
        IntoIteratorT: IntoIterator<Item = RefT, IntoIter = IteratorT>,
        IteratorT: ExactSizeIterator<Item = RefT>,
        RefT: Borrow<T>,
    {
        // Verify that the allocation is at the end of the marker.
        if !self.is_allocation_at_end(&allocation) {
            return Err(Error::new(ErrorKind::NotAtEnd, (allocation,)));
        }

        // Create a new allocation for the value given and merge the two
        // allocations. This will also perform all remaining validity checks.
        let source = values.into_iter();
        let source_len = source.len();
        match unsafe { self.allocate_array_uninitialized(source_len) } {
            Err(e) => Err(e.map(|()| (allocation,))),
            Ok(mut val_alloc) => unsafe {
                let mut index = 0;
                for source_val in source {
                    ptr::write(
                        &mut val_alloc[index],
                        source_val.borrow().clone(),
                    );
                    index += 1;
                }

                assert_eq!(index, source_len);

                Ok(allocation.concat_unchecked::<T, [T]>(val_alloc))
            },
        }
    }
    pub fn append_copy<'marker, T, U, IntoIteratorT, IteratorT, RefT>(
        &'marker self,
        allocation: Allocation<'marker, U>,
        values: IntoIteratorT,
    ) -> Result<Allocation<'marker, [T]>, Error<(Allocation<'marker, U>,)>>
    where
        T: Copy,
        U: ?Sized,
        Allocation<'marker, U>: IntoSliceAllocation<'marker, T>,
        IntoIteratorT: IntoIterator<Item = RefT, IntoIter = IteratorT>,
        IteratorT: ExactSizeIterator<Item = RefT>,
        RefT: Borrow<T>,
    {
        // Verify that the allocation is at the end of the marker.
        if !self.is_allocation_at_end(&allocation) {
            return Err(Error::new(ErrorKind::NotAtEnd, (allocation,)));
        }

        // Create a new allocation for the value given and merge the two
        // allocations. This will also perform all remaining validity checks.
        let source = values.into_iter();
        let source_len = source.len();
        match unsafe { self.allocate_array_uninitialized(source_len) } {
            Err(e) => Err(e.map(|()| (allocation,))),
            Ok(mut val_alloc) => unsafe {
                let mut index = 0;
                for source_val in source {
                    ptr::write(&mut val_alloc[index], *source_val.borrow());
                    index += 1;
                }

                assert_eq!(index, source_len);
                Ok(allocation.concat_unchecked::<T, [T]>(val_alloc))
            },
        }
    }
    pub fn prepend_clone<'marker, T, U, IntoIteratorT, IteratorT, RefT>(
        &'marker self,
        allocation: Allocation<'marker, U>,
        values: IntoIteratorT,
    ) -> Result<Allocation<'marker, [T]>, Error<(Allocation<'marker, U>,)>>
    where
        T: Clone,
        U: ?Sized,
        Allocation<'marker, U>: IntoSliceAllocation<'marker, T>,
        IntoIteratorT: IntoIterator<Item = RefT, IntoIter = IteratorT>,
        IteratorT: ExactSizeIterator<Item = RefT>,
        RefT: Borrow<T>,
    {
        // Verify that the allocation is at the end of the marker.
        if !self.is_allocation_at_end(&allocation) {
            return Err(Error::new(ErrorKind::NotAtEnd, (allocation,)));
        }

        // Create a new allocation for the value given and merge the two
        // allocations. This will also perform all remaining validity checks.
        let source = values.into_iter();
        let source_len = source.len();
        match unsafe { self.allocate_array_uninitialized(source_len) } {
            Err(e) => Err(e.map(|()| (allocation,))),
            Ok(mut val_alloc) => unsafe {
                let mut index = 0;
                for source_val in source {
                    ptr::write(
                        &mut val_alloc[index],
                        source_val.borrow().clone(),
                    );
                    index += 1;
                }

                assert_eq!(index, source_len);

                Ok(val_alloc.concat_unchecked::<T, U>(allocation))
            },
        }
    }
    pub fn prepend_copy<'marker, T, U, IntoIteratorT, IteratorT, RefT>(
        &'marker self,
        allocation: Allocation<'marker, U>,
        values: IntoIteratorT,
    ) -> Result<Allocation<'marker, [T]>, Error<(Allocation<'marker, U>,)>>
    where
        T: Copy,
        U: ?Sized,
        Allocation<'marker, U>: IntoSliceAllocation<'marker, T>,
        IntoIteratorT: IntoIterator<Item = RefT, IntoIter = IteratorT>,
        IteratorT: ExactSizeIterator<Item = RefT>,
        RefT: Borrow<T>,
    {
        // Verify that the allocation is at the end of the marker.
        if !self.is_allocation_at_end(&allocation) {
            return Err(Error::new(ErrorKind::NotAtEnd, (allocation,)));
        }

        // Create a new allocation for the value given and merge the two
        // allocations. This will also perform all remaining validity checks.
        let source = values.into_iter();
        let source_len = source.len();
        match unsafe { self.allocate_array_uninitialized(source_len) } {
            Err(e) => Err(e.map(|()| (allocation,))),
            Ok(mut val_alloc) => unsafe {
                let mut index = 0;
                for source_val in source {
                    ptr::write(&mut val_alloc[index], *source_val.borrow());
                    index += 1;
                }

                assert_eq!(index, source_len);

                Ok(val_alloc.concat_unchecked::<T, U>(allocation))
            },
        }
    }

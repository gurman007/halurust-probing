    fn vec_move_items_zero_sized() {
        let deq = sdeq![(), (), ()];
        let mut deq2 = sdeq![];
        for i in deq {
            deq2.push_back(i);
        }
        assert_eq!(deq2, [(), (), ()]);
    }
    fn vec_splice_items_zero_sized() {
        let mut deq = sdeq![(), (), ()];
        let deq2 = sdeq![];
        let t: SliceDeque<_> =
            deq.splice(1..2, deq2.iter().cloned()).collect();
        assert_eq!(deq, &[(), ()]);
        assert_eq!(t, &[()]);
    }
    fn vecdeque_drop() {
        static mut DROPS: i32 = 0;
        #[derive(Clone)]
        struct Elem(i32);
        impl Drop for Elem {
            fn drop(&mut self) {
                unsafe {
                    println!("dropping: {} += 1 = {}", DROPS, DROPS + 1);
                    DROPS += 1;
                }
            }
        }

        let mut ring = SliceDeque::new();
        ring.push_back(Elem(0));
        ring.push_front(Elem(1));
        ring.push_back(Elem(2));
        ring.push_front(Elem(3));
        ::std::mem::drop(ring);

        assert_eq!(unsafe { DROPS }, 4);
    }

    pub fn insert(&mut self, val: T) -> Id {
        if self.space == self.values.len() {
            self.values.push(val)
        } else {
            unsafe { ptr::write(self.values.get_unchecked_mut(self.space), val) }
        }
        let id = self.space;
        self.ids.insert(id);

        // Find the next empty space.
        self.space += 1;
        while self.ids.contains(self.space) {
            self.space += 1;
        }

        Id(id)
    }
    pub fn values_mut(&mut self) -> ValuesMut<T> {
        ValuesMut {
            ids: self.ids.iter(),
            values: &mut self.values,
            min: self.space,
        }
    }
    pub fn iter_mut(&mut self) -> IterMut<T> {
        IterMut {
            ids: self.ids.iter(),
            values: &mut self.values,
            min: self.space,
        }
    }
    fn next(&mut self) -> Option<Self::Item> {
        self.ids.next().map(|id| {
                                (Id(id),
                                 unsafe { &mut *(self.values.get_unchecked_mut(id) as *mut T) })
                            })
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.min, self.ids.size_hint().1)
    }
fn iter_mut() {
    let mut ids = IdMap::from_iter(0..5);

    let mut refs: Vec<&mut u32> = ids.values_mut().collect();

    refs.sort();
    refs.dedup_by(|l, r| *l as *mut u32 == *r as *mut u32);

    assert_eq!(refs.len(), 5)
}

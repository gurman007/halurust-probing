    fn check_spec(d: &DateTime<Utc>, s: String) {
        let b = ASN1Block::GeneralizedTime(0, d.clone());
        match to_der(&b) {
            Err(_) => assert_eq!(format!("Broken: {}", d), s),
            Ok(ref vec) => {
                let mut resvec = vec.clone();
                resvec.remove(0);
                resvec.remove(0);
                assert_eq!(String::from_utf8(resvec).unwrap(), s);
                match from_der_(vec, 0) {
                    Err(_) =>
                        assert_eq!(format!("Broken [reparse]: {}", d), s),
                    Ok(mut vec) => {
                        assert_eq!(vec.len(), 1);
                        match vec.pop() {
                            None =>
                                assert!(false, "The world's gone mad again."),
                            Some(ASN1Block::GeneralizedTime(_, d2)) =>
                                assert_eq!(&d2, d),
                            Some(_) =>
                                assert!(false, "Bad reparse of GeneralizedTime.")
                        }
                    }
                }
            }
        }
    }

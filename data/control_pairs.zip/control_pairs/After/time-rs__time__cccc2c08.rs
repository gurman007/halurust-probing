pub(super) fn items_into_owned_v3<const VERSION: u8>(
    items: Vec<Item<'_, VERSION>>,
) -> Result<FormatDescriptionV3Inner<'static>, Error> {
    assert_version!();
    match <[_; 1]>::try_from(items) {
        Ok([item]) => item.into_owned_v3(),
        Err(vec) => Ok(FormatDescriptionV3Inner::OwnedCompound(
            vec.into_iter()
                .map(Item::into_owned_v3)
                .collect::<Result<_, _>>()?,
        )),
    }
}
    pub(super) fn into_owned_v3(self) -> Result<FormatDescriptionV3Inner<'static>, Error> {
        assert_version!();
        match self {
            Item::Literal(literal) => Ok(FormatDescriptionV3Inner::OwnedLiteral(
                literal.to_owned().into_boxed_str(),
            )),
            Item::Component(component) => Ok(component.try_into()?),
            Item::Optional {
                value,
                format,
                span: _,
            } => Ok(FormatDescriptionV3Inner::OwnedOptional {
                format: *format,
                item: Box::new(items_into_owned_v3(value)?),
            }),
            Item::First { value, span: _ } => Ok(FormatDescriptionV3Inner::OwnedFirst(
                value
                    .into_iter()
                    .map(items_into_owned_v3)
                    .collect::<Result<_, _>>()?,
            )),
        }
    }
    fn parse_owned(s: &str) -> Result<Self::OwnedOutput, error::InvalidFormatDescription> {
        let items = Lexer::<3>::new(s).collect::<Result<Vec<_>, _>>()?;
        let inner = match <[_; 1]>::try_from(items) {
            Ok([item]) => item.into_owned_v3()?,
            Err(vec) => FormatDescriptionV3Inner::OwnedCompound(
                vec.into_iter()
                    .map(format_item::Item::into_owned_v3)
                    .collect::<Result<_, _>>()?,
            ),
        };

        Ok(inner.into_opaque())
    }

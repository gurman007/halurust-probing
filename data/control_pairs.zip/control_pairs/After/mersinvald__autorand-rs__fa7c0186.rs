fn impl_random(ast: &syn::DeriveInput) -> proc_macro2::TokenStream {
    let name = &ast.ident;
    let (impl_generics, ty_generics, ..) = ast.generics.split_for_impl();
    let type_params: Vec<Ident> = ast
        .generics
        .type_params()
        .map(|t| t.ident.clone())
        .collect();

    let where_clause = if type_params.is_empty() {
        ast.generics
            .where_clause
            .clone()
            .map(WhereClause::into_token_stream)
    } else {
        let where_clause = ast.generics.where_clause.as_ref();
        if let Some(where_clause) = where_clause {
            let predicates = &where_clause.predicates;
            Some(quote!(
                where #(#predicates,)* #(#type_params: autorand::Random,)*
            ))
        } else {
            Some(quote!(
                where #(#type_params: autorand::Random,)*
            ))
        }
    };

    let body = match ast.data {
        Data::Struct(ref data) => expand_struct_random_body(data),
        Data::Enum(ref data) => expand_enum_random_body(name, data),
        Data::Union(_) => panic!("Random derive is not supported for Union types"),
    };

    let tokens = quote! {
        impl #impl_generics autorand::Random for #name #ty_generics #where_clause {
            fn random() -> Self {
                #body
            }
        }
    };

    //panic!("{}", tokens);

    tokens
}

pub struct Select<'a, R> {
    /// A list of senders and receivers participating in selection.
    handles: SmallVec<[(&'a SelectHandle, usize, *const u8); 4]>,

    /// A list of callbacks, one per handle.
    callbacks: SmallVec<[Callback<'a, R>; 4]>,

    /// Callback for the default case.
    default: Option<Callback<'a, R>>,
}
    pub fn recv<T, C>(mut self, r: &'a Receiver<T>, cb: C) -> Select<'a, R>
    where
        C: FnOnce(Option<T>) -> R + 'a,
    {
        let i = self.handles.len() + 1;
        let ptr = r as *const Receiver<_> as *const u8;
        self.handles.push((r, i, ptr));

        self.callbacks.push(Callback::new(move |token| {
            let msg = unsafe { channel::read(r, token) };
            cb(msg)
        }));

        self
    }
    pub fn send<T, M, C>(mut self, s: &'a Sender<T>, msg: M, cb: C) -> Select<'a, R>
    where
        M: FnOnce() -> T + 'a,
        C: FnOnce() -> R + 'a,
    {
        let i = self.handles.len() + 1;
        let ptr = s as *const Sender<_> as *const u8;
        self.handles.push((s, i, ptr));

        self.callbacks.push(Callback::new(move |token| {
            let _guard = utils::AbortGuard(
                "a send case triggered a panic while evaluating its message"
            );
            let msg = msg();

            ::std::mem::forget(_guard);
            unsafe { channel::write(s, token, msg); }

            cb()
        }));

        self
    }
    pub fn default<C>(mut self, cb: C) -> Select<'a, R>
    where
        C: FnOnce() -> R + 'a,
    {
        self.default = Some(Callback::new(move |_| cb()));
        self
    }
    pub fn wait(mut self) -> R {
        let (mut token, index, _) = main_loop(&mut self.handles, self.default.is_some());

        let cb = if index == 0 {
            self.default.as_mut().unwrap()
        } else {
            &mut self.callbacks[index - 1]
        };
        cb.call(&mut token)
    }
    pub fn call(&mut self, token: &mut Token) -> R {
        self.call_option(Some(token)).unwrap()
    }
        unsafe fn dummy<R>(_raw: *mut u8, _token: Option<&mut Token>) -> Option<R> {
            None
        }
    fn drop(&mut self) {
        self.call_option(None);
    }

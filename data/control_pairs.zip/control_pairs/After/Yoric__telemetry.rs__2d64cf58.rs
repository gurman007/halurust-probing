pub struct SingleFlag {
    back_end: BackEnd<Single>,
    cache: AtomicBool,
}
pub struct KeyedFlag<T> {
    back_end: BackEnd<Keyed<T>>
}
struct SingleFlagStorage {
    // `true` once we have called `record`, `false` until then.
    encountered: bool
}
    fn record_cb<F>(&self, cb: F) where F: FnOnce() -> Option<()>  {
        if self.cache.load(Ordering::Relaxed) {
            // Don't bother with dereferencing values or sending
            // messages, the histogram is already full.
            return;
        }
        if let Some(k) = self.back_end.get_key() {
            match cb() {
                None => {}
                Some(()) => self.back_end.raw_record(&k, 0)
            }
        }
    }
    pub fn new(feature: &Feature, meta: Metadata) -> KeyedFlag<K> {
        let storage = Box::new(KeyedFlagStorage { encountered: HashSet::new() });
        let key = feature.telemetry.register_keyed(meta, storage);
        KeyedFlag {
            back_end: BackEnd::new(feature, key),
        }
    }
struct KeyedFlagStorage {
    encountered: HashSet<String>
}

    async fn test_compression_round_trip() {
        // Round trip a batch through Flight with IPC body compression enabled. This exercises
        // the compressed `IpcDataGenerator::encode` path (per-buffer codec output), which the
        // uncompressed Flight tests and the writer-based compression tests do not cover.
        let ints = Int32Array::from_iter_values((0..1024).map(|i| i % 8));
        let strings = StringArray::from_iter_values((0..1024).map(|i| format!("value-{}", i % 8)));
        let batch = RecordBatch::try_from_iter(vec![
            ("ints", Arc::new(ints) as ArrayRef),
            ("strings", Arc::new(strings) as ArrayRef),
        ])
        .unwrap();

        for compression in [CompressionType::LZ4_FRAME, CompressionType::ZSTD] {
            let options = IpcWriteOptions::default()
                .try_with_compression(Some(compression))
                .unwrap();
            verify_flight_round_trip_with_options(vec![batch.clone()], options).await;
        }
    }
    async fn verify_flight_round_trip(batches: Vec<RecordBatch>) {
        verify_flight_round_trip_with_options(batches, IpcWriteOptions::default()).await;
    }
    async fn verify_flight_round_trip_with_options(
        mut batches: Vec<RecordBatch>,
        options: IpcWriteOptions,
    ) {
        let expected_schema = batches.first().unwrap().schema();

        let encoder = FlightDataEncoderBuilder::default()
            .with_options(options)
            .with_dictionary_handling(DictionaryHandling::Resend)
            .build(futures::stream::iter(batches.clone().into_iter().map(Ok)));

        let mut expected_batches = batches.drain(..);

        let mut decoder = FlightDataDecoder::new(encoder);
        while let Some(decoded) = decoder.next().await {
            let decoded = decoded.unwrap();
            match decoded.payload {
                DecodedPayload::None => {}
                DecodedPayload::Schema(s) => assert_eq!(s, expected_schema),
                DecodedPayload::RecordBatch(b) => {
                    let expected_batch = expected_batches.next().unwrap();
                    assert_eq!(b, expected_batch);
                }
            }
        }
    }

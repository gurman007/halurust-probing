    fn size_hint(&self) -> (usize, Option<usize>) {
        (**self).size_hint()
    }
    fn nth(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth(n)
    }
    fn nth_back(&mut self, n: usize) -> Option<Self::Item> {
        (**self).nth_back(n)
    }
    fn len(&self) -> usize { (**self).len() }
    fn next(&mut self) -> Option<Self::Item> {
        (**self).next()
    }
    fn next_back(&mut self) -> Option<Self::Item> {
        (**self).next_back()
    }

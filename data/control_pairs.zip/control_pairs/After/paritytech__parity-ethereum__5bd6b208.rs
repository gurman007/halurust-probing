pub trait BlockLike {
	/// Get the hash of this item - i.e. the header hash.
	fn hash(&self) -> H256;

	/// Get a raw hash of this item - i.e. the hash of the RLP representation.
	fn raw_hash(&self) -> H256;

	/// Get the hash of this item's parent.
	fn parent_hash(&self) -> H256;

	/// Get the difficulty of this item.
	fn difficulty(&self) -> U256;
}
		fn raw_hash(&self) -> H256 { self.hash() }
		fn hash(&self) -> H256 { self.hash() }
	pub fn import(&self, input: K::Input) -> Result<H256, (K::Input, Error)> {
		let hash = input.hash();
		let raw_hash = input.raw_hash();
		{
			if self.processing.read().contains_key(&hash) {
				return Err((input, Error::Import(ImportError::AlreadyQueued).into()));
			}

			let mut bad = self.verification.bad.lock();
			if bad.contains(&hash) || bad.contains(&raw_hash)  {
				return Err((input, Error::Import(ImportError::KnownBad).into()));
			}

			if bad.contains(&input.parent_hash()) {
				bad.insert(hash);
				return Err((input, Error::Import(ImportError::KnownBad).into()));
			}
		}

		match K::create(input, &*self.engine, self.verification.check_seal) {
			Ok(item) => {
				self.verification.sizes.unverified.fetch_add(item.malloc_size_of(), AtomicOrdering::SeqCst);

				self.processing.write().insert(hash, item.difficulty());
				{
					let mut td = self.total_difficulty.write();
					*td = *td + item.difficulty();
				}
				self.verification.unverified.lock().push_back(item);
				self.more_to_verify.notify_all();
				Ok(hash)
			},
			Err((input, err)) => {
				match err {
					// Don't mark future blocks as bad.
					Error::Block(BlockError::TemporarilyInvalid(_)) => {},
					// If the transaction root or uncles hash is invalid, it doesn't necessarily mean
					// that the header is invalid. We might have just received a malformed block body,
					// so we shouldn't put the header hash to `bad`.
					//
					// We still put the entire `Item` hash to bad, so that we can early reject
					// the items that are malformed.
					Error::Block(BlockError::InvalidTransactionsRoot(_)) |
					Error::Block(BlockError::InvalidUnclesHash(_)) => {
						self.verification.bad.lock().insert(raw_hash);
					},
					_ => {
						self.verification.bad.lock().insert(hash);
					}
				}
				Err((input, err))
			}
		}
	}

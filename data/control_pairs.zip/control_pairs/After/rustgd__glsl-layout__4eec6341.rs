            fn std140(&self) ->Self::Std140 {
                Self::Std140::from(self.to_cols_array_2d())
            }
            fn from(value: $glam) -> Self {
                $mat::from(value.to_cols_array_2d())
            }
pub fn test_glam() {
    use crate::uniform::Std140;

    let v3: vec3 = [1.0, 2.0, 3.0].into();
    let gv3_to_v3: vec3 = Vec3::new(1.0, 2.0, 3.0).into();
    let gv3 = Vec3::new(1.0, 2.0, 3.0);
    assert_eq!(v3.std140().as_raw(), gv3.std140().as_raw());
    assert_eq!(gv3.std140().as_raw(), gv3_to_v3.std140().as_raw());

    let m3: mat3 = [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]].into();
    let gm3_to_m3: mat3 = Mat3::IDENTITY.into();
    let gm3 = Mat3::IDENTITY;
    assert_eq!(m3.std140().as_raw(), gm3.std140().as_raw());
    assert_eq!(gm3.std140().as_raw(), gm3_to_m3.std140().as_raw());
}

        fn uninit_global_object();
pub extern "C" fn t_global_init_ecall(id: u64, path: *const u8, len: usize) {
    GLOBAL_INIT_LOCK.lock();
    unsafe { INIT_TCS = thread::rsgx_thread_self() };

    INIT.call_once(|| {
        enclave::set_enclave_id(id as sgx_enclave_id_t);
        let s = unsafe {
            let str_slice = slice::from_raw_parts(path, len);
            str::from_utf8_unchecked(str_slice)
        };
        enclave::set_enclave_path(s);
    });
}
pub extern "C" fn t_global_exit_ecall() {
    extern "C" {
        fn uninit_global_object();
    }

    GLOBAL_INIT_LOCK.lock();
    EXIT.call_once(|| {
        unsafe {
            if INIT_TCS == thread::rsgx_thread_self() {
                if !rsgx_is_supported_EDMM() {
                    uninit_global_object();
                }
            }
        }
    });
}
    pub const fn new() -> SgxSpinlock {
        SgxSpinlock{inner: SgxThreadSpinlock::new()}
    }

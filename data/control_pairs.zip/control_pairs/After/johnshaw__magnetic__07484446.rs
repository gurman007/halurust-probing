unsafe impl<T: Send, B: Buffer<T>> Sync for MPMCProducer<T, B> {}
unsafe impl<T: Send, B: Buffer<T>> Sync for MPSCProducer<T, B> {}
unsafe impl<T: Send, B: Buffer<T>> Sync for SPMCProducer<T, B> {}
unsafe impl<T: Send, B: Buffer<T>> Send for SPSCProducer<T, B> {}

    pub fn verify<D>(&self, message: &[u8], signature: &Signature) -> Result<(), SignatureError>
            where D: Digest<OutputSize = U64> + Default
    {
        let mut h: D = D::default();
        let R: EdwardsPoint;
        let k: Scalar;

        let A: EdwardsPoint = match self.0.decompress() {
            Ok(x) => x,
            Err   => Err(SignatureError(InternalError::PointDecompressionError))),
        };

        h.input(signature.r.as_bytes());
        h.input(self.as_bytes());
        h.input(&message);

        k = Scalar::from_hash(h);
        R = EdwardsPoint::vartime_double_scalar_mul_basepoint(&k, &(-A), &signature.s);

        if R.compress() == signature.r {
            Ok(())
        } else {
            Err(SignatureError(InternalError::VerifyError))
        }
    }
    pub fn verify_prehashed<D>(&self,
                               prehashed_message: D,
                               context: Option<&[u8]>,
                               signature: &Signature) -> Result<(), SignatureError>
        where D: Digest<OutputSize = U64> + Default
    {
        let mut h: D = D::default();
        let R: EdwardsPoint;
        let k: Scalar;

        let ctx: &[u8] = context.unwrap_or(b"");
        debug_assert!(ctx.len() <= 255, "The context must not be longer than 255 octets.");

        let A: EdwardsPoint = match self.0.decompress() {
            Ok(x) => x,
            Err   => Err(SignatureError(InternalError::PointDecompressionError))),
        };

        h.input(b"SigEd25519 no Ed25519 collisions");
        h.input(&[1]); // Ed25519ph
        h.input(&[ctx.len() as u8]);
        h.input(ctx);
        h.input(signature.r.as_bytes());
        h.input(self.as_bytes());
        h.input(prehashed_message.fixed_result().as_slice());

        k = Scalar::from_hash(h);
        R = EdwardsPoint::vartime_double_scalar_mul_basepoint(&k, &(-A), &signature.s);

        if R.compress() == signature.r {
            Ok(())
        } else {
            Err(SignatureError(InternalError::VerifyError))
        }
    }

	pub fn access_shared_state<F: FnOnce(&mut U)>(&self, modifier: F) {
		let mut shared_state_lock = self.0.shared_state.lock().unwrap();
		modifier(&mut *shared_state_lock);
	}
	pub fn access_shared_state_param<V, F: FnOnce(&mut U, V)>(&self, modifier: F, parameter: V) {
		let mut shared_state_lock = self.0.shared_state.lock().unwrap();
		modifier(&mut *shared_state_lock, parameter);
	}

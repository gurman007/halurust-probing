    pub fn add_old_signatures(mut self, old_signatures: Vec<Signature>) -> Result<Self>{

        for old_signature in old_signatures {
            //add only if the signature of the key does not exist
            if  self.signed.signatures.iter().find(|new_sig| new_sig.keyid == old_signature.keyid) == None {
                self.signed.signatures.push(Signature {
                    keyid: old_signature.keyid,
                    sig: old_signature.sig,
                });
            }
        }
        SignedRole::from_signed(self.signed)
    }
    pub fn write<P>(&self, outdir: P, consistent_snapshot: bool) -> Result<()>
    where
        P: AsRef<Path>,
    {
        for targets in &self.roles {
            targets.write(&outdir, consistent_snapshot)?;
        }
        Ok(())
    }
    fn sign(
        path: &PathBuf,
        key_source: &[Box<dyn KeySource>],
        cross_sign: Option<PathBuf>,
    ) -> Result<()> {
        let root: Signed<Root> = load_file(path)?;

        let mut signed_root = match cross_sign {
            // get the keys from current root.json for validation
            None => SignedRole::new(
                root.signed.clone(),
                &KeyHolder::Root(root.signed),
                key_source,
                &SystemRandom::new(),
            )
            .context(error::SignRoot { path })?,

            Some(cross_sign_root) => {
                // get the keys from cross-sign root.json for validation
                let old_root: Signed<Root> = load_file(&cross_sign_root)?;
                SignedRole::new(
                    root.signed,
                    &KeyHolder::Root(old_root.signed),
                    key_source,
                    &SystemRandom::new(),
                )
                .context(error::SignRoot { path })?
            }
        };

        // append the existing signatures if present
        if !root.signatures.is_empty() {
            signed_root = signed_root
                .add_old_signatures(root.signatures)
                .context(error::SignRoot { path })?;
        }

        // Quick check that root is signed by enough key IDs
        for (roletype, rolekeys) in &signed_root.signed().signed.roles {
            if rolekeys.threshold.get() > rolekeys.keyids.len() as u64 {
                return Err(error::Error::UnstableRoot {
                    role: *roletype,
                    threshold: rolekeys.threshold.get(),
                    actual: rolekeys.keyids.len(),
                });
            }
        }

        // Signature check for root
        let threshold = signed_root
            .signed()
            .signed
            .roles
            .get(&RoleType::Root)
            .ok_or_else(|| error::Error::UnstableRoot {
                // The code should never reach this point
                role: RoleType::Root,
                threshold: 0,
                actual: 0,
            })?
            .threshold
            .get();
        let signature_count = signed_root.signed().signatures.len();
        if threshold > signature_count as u64 {
            return Err(error::Error::SignatureRoot {
                threshold,
                signature_count,
            });
        }

        // Use `tempfile::NamedTempFile::persist` to perform an atomic file write.
        let parent = path.parent().context(error::PathParent { path })?;
        let mut writer =
            NamedTempFile::new_in(parent).context(error::FileTempCreate { path: parent })?;
        writer
            .write_all(signed_root.buffer())
            .context(error::FileWrite { path })?;
        writer.persist(path).context(error::FilePersist { path })?;
        Ok(())
    }

    fn maybe_parse_option<'a>(&mut self, arg: &str, it: &mut Iter<String>)
                              -> OptionParseOutcome {
        match arg {
            "--setuid" => {
                let arg = match it.next() {
                    Some(arg) => arg,
                    None => {
                        eprintln!("Missing argument for --setuid");
                        return OptionParseOutcome::Failed
                    },
                };
                match libc::uid_t::from_str_radix(arg, 10) {
                    Err(_) => {
                        eprintln!("Invalid argument for --setuid");
                        return OptionParseOutcome::Failed
                    },
                    Ok(mode) => {
                        self.setuid = Some(nix::unistd::Uid::from_raw(mode));
                        OptionParseOutcome::Consumed
                    }
                }
            },
            "--setgid" => {
                let arg = match it.next() {
                    Some(arg) => arg,
                    None => {
                        eprintln!("Missing argument for --setgid");
                        return OptionParseOutcome::Failed
                    },
                };
                match libc::gid_t::from_str_radix(arg, 10) {
                    Err(_) => {
                        eprintln!("Invalid argument for --setgid");
                        return OptionParseOutcome::Failed
                    },
                    Ok(mode) => {
                        self.setgid = Some(nix::unistd::Gid::from_raw(mode));
                        OptionParseOutcome::Consumed
                    }
                }
            },
            "--chroot" => {
                let arg = match it.next() {
                    Some(arg) => arg,
                    None => {
                        eprintln!("Missing argument for --chroot");
                        return OptionParseOutcome::Failed
                    },
                };
                self.chroot = Some(PathBuf::from(arg));
                OptionParseOutcome::Consumed
            },
            "--syslog" => {
                let arg = match it.next() {
                    Some(arg) => arg,
                    None => {
                        eprintln!("Missing argument for --syslog");
                        return OptionParseOutcome::Failed
                    },
                };
                self.syslog = Some(arg.to_owned());
                OptionParseOutcome::Consumed
            },
            "--daemonize" => {
                self.daemonize = true;
                OptionParseOutcome::Consumed
            },
            _ => OptionParseOutcome::Ignored,
        }
    }

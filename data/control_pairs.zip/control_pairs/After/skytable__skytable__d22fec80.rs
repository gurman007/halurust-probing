    fn parse_next_actiongroup(&mut self) -> ParseResult<Vec<Vec<u8>>> {
        let len = self.parse_dataframe_layout_get_group_size()?;
        let mut elements = Vec::with_capacity(len);
        for _ in 0..len {
            elements.push(self.parse_next_datagroup_element()?);
        }
        Ok(elements)
    }
fn test_parse_actiongroup_single() {
    let actiongroup = "#2\n&2\n#3\nGET\n#5\nsayan\n".as_bytes();
    let mut parser = Parser::new(&actiongroup);
    assert_eq!(
        vec![
            String::from("GET").into_bytes(),
            String::from("sayan").into_bytes()
        ],
        parser.parse_next_actiongroup().unwrap()
    );
    assert_eq!(parser.cursor, actiongroup.len());
}
    fn parse_next_datagroup_element(&mut self) -> ParseResult<Vec<u8>> {
        // So we need to read the sizeline for this element first!
        let element_size = self.read_sizeline()?;
        // Now we want to read the element itself
        let mut ret = Vec::with_capacity(element_size);
        ret.extend_from_slice(self.read_until(element_size)?);
        // Now move the cursor ahead as read_until doesn't do anything with the newline
        self.incr_cursor();
        // We'll just return this since that's all we have to do!
        Ok(ret)
    }
fn test_read_datagroup_element() {
    let element_with_block = "#5\nsayan\n".as_bytes();
    let mut parser = Parser::new(&element_with_block);
    assert_eq!(
        String::from("sayan").into_bytes(),
        parser.parse_next_datagroup_element().unwrap()
    );
    assert_eq!(parser.cursor, element_with_block.len());
}

pub struct Flag {
    shared: Shared,
    // FIXME: We could cache the value to avoid sending messages across threads.
}
pub struct Telemetry {
    // The name of the product.
    product: String,

    // The version of the product. Some histograms may be limited to
    // specific versions of the product.
    version: Version,

    // Has telemetry been activated? `false` by default.
    is_active: bool,

    // A key generator for registration of new histograms. Uses atomic
    // to avoid the use of &mut.
    generator: KeyGenerator,

    // Connection to the thread holding all the storage of this
    // instance of telemetry.
    sender: Sender<Op>,
}

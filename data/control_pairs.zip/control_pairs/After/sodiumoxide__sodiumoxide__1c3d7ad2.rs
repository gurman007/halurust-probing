  pub fn crypto_stream_keybytes() -> size_t;
  pub fn crypto_stream_noncebytes() -> size_t;
  pub fn crypto_stream_primitive() -> *const c_char;                                           
  pub fn crypto_stream_aes128ctr_keybytes() -> size_t;
  pub fn crypto_stream_aes128ctr_noncebytes() -> size_t;
  pub fn crypto_stream_aes128ctr_beforenmbytes() -> size_t;
  pub fn crypto_stream_chacha20_keybytes() -> size_t;
  pub fn crypto_stream_chacha20_noncebytes() -> size_t;
  pub fn crypto_stream_salsa20_xor(c: *mut u8,
                                   m: *const u8,
                                   mlen: c_ulonglong,
                                   n: *const u8,
                                   k: *const u8) -> c_int;   
  pub fn crypto_stream_salsa20_keybytes() -> size_t;
  pub fn crypto_stream_salsa20_noncebytes() -> size_t;
  pub fn crypto_stream_salsa208_keybytes() -> size_t;
  pub fn crypto_stream_salsa208_noncebytes() -> size_t;
  pub fn crypto_stream_salsa2012_keybytes() -> size_t;
  pub fn crypto_stream_salsa2012_noncebytes() -> size_t;
  pub fn crypto_stream_xsalsa20_keybytes() -> size_t;
  pub fn crypto_stream_xsalsa20_noncebytes() -> size_t;
fn test_crypto_stream_keybytes() {
    assert!(unsafe { crypto_stream_keybytes() } == crypto_stream_KEYBYTES)
}
fn test_crypto_stream_noncebytes() {
    assert!(unsafe { crypto_stream_noncebytes() } == crypto_stream_NONCEBYTES)
}
fn test_crypto_stream_primitive() {
    let s = unsafe {
        std::c_str::CString::new(crypto_stream_primitive(), false)
    };
    assert!(s.as_bytes_no_nul() == crypto_stream_PRIMITIVE.as_bytes());
}
fn test_crypto_stream_aes128ctr_keybytes() {
    assert!(unsafe { crypto_stream_aes128ctr_keybytes() } == crypto_stream_aes128ctr_KEYBYTES)
}
fn test_crypto_stream_aes128ctr_noncebytes() {
    assert!(unsafe { crypto_stream_aes128ctr_noncebytes() } == crypto_stream_aes128ctr_NONCEBYTES)
}
fn test_crypto_stream_aes128ctr_beforenmbytes() {
    assert!(unsafe { crypto_stream_aes128ctr_beforenmbytes() } == crypto_stream_aes128ctr_BEFORENMBYTES)
}
fn test_crypto_stream_chacha20_keybytes() {
    assert!(unsafe { crypto_stream_chacha20_keybytes() } == crypto_stream_chacha20_KEYBYTES)
}
fn test_crypto_stream_chacha20_noncebytes() {
    assert!(unsafe { crypto_stream_chacha20_noncebytes() } == crypto_stream_chacha20_NONCEBYTES)
}
fn test_crypto_stream_salsa20_keybytes() {
    assert!(unsafe { crypto_stream_salsa20_keybytes() } == crypto_stream_salsa20_KEYBYTES)
}
fn test_crypto_stream_salsa20_noncebytes() {
    assert!(unsafe { crypto_stream_salsa20_noncebytes() } == crypto_stream_salsa20_NONCEBYTES)
}
fn test_crypto_stream_salsa208_keybytes() {
    assert!(unsafe { crypto_stream_salsa208_keybytes() } == crypto_stream_salsa208_KEYBYTES)
}
fn test_crypto_stream_salsa208_noncebytes() {
    assert!(unsafe { crypto_stream_salsa208_noncebytes() } == crypto_stream_salsa208_NONCEBYTES)
}
fn test_crypto_stream_salsa2012_keybytes() {
    assert!(unsafe { crypto_stream_salsa2012_keybytes() } == crypto_stream_salsa2012_KEYBYTES)
}
fn test_crypto_stream_salsa2012_noncebytes() {
    assert!(unsafe { crypto_stream_salsa2012_noncebytes() } == crypto_stream_salsa2012_NONCEBYTES)
}
fn test_crypto_stream_xsalsa20_keybytes() {
    assert!(unsafe { crypto_stream_xsalsa20_keybytes() } == crypto_stream_xsalsa20_KEYBYTES)
}
fn test_crypto_stream_xsalsa20_noncebytes() {
    assert!(unsafe { crypto_stream_xsalsa20_noncebytes() } == crypto_stream_xsalsa20_NONCEBYTES)
}
  pub fn crypto_stream_aes128ctr_xor(c: *mut u8,
                                     m: *const u8,
                                     mlen: c_ulonglong,
                                     n: *const u8,
                                     k: *const u8) -> c_int;
  pub fn crypto_stream_salsa208_xor(c: *mut u8,
                                    m: *const u8,
                                    mlen: c_ulonglong,
                                    n: *const u8,
                                    k: *const u8) -> c_int;
  pub fn crypto_stream_salsa2012_xor(c: *mut u8,
                                     m: *const u8,
                                     mlen: c_ulonglong,
                                     n: *const u8,
                                     k: *const u8) -> c_int;
  pub fn crypto_stream_xsalsa20_xor(c: *mut u8,
                                    m: *const u8,
                                    mlen: c_ulonglong,
                                    n: *const u8,
                                    k: *const u8) -> c_int;

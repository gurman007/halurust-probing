    fn into_pyobject(self, py: Python<'py>) -> Result<Self::Output, Self::Error> {
        (*self).into_pyobject(py)
    }
    fn extract(ob: Borrowed<'_, '_, PyAny>) -> PyResult<Self> {
        Ok(ob.extract::<Date>()?.iso_week_date())
    }
            fn test_weekdate_roundtrip(
                year in 1i16..=9999i16,
                month in 1i8..=12i8,
                day in 1i8..=31i8
            ) {
                // Test roundtrip conversion rust->python->rust for all allowed
                // python dates (from year 1 to year 9999)
                Python::attach(|py| {
                    let weekdate = try_date(year, month, day)?.iso_week_date();
                    let py_date = weekdate.into_pyobject(py).unwrap();
                    let roundtripped = py_date.extract::<ISOWeekDate>().expect("Round trip");
                    prop_assert_eq!(weekdate, roundtripped);
                    Ok(())
                })?;
            }

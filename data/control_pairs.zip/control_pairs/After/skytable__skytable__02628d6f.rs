    fn lmod(handle: &Corestore, con: &mut T, mut act: ActionIter<'a>) {
        err_if_len_is!(act, con, lt 2);
        let table = get_tbl!(handle, con);
        let listmap = listmap!(table, con);
        // get the list name
        let listname = unsafe { act.next_unchecked() };
        macro_rules! get_numeric_count {
            () => {
                match unsafe { String::from_utf8_lossy(act.next_unchecked()) }.parse::<usize>() {
                    Ok(int) => int,
                    Err(_) => return conwrite!(con, groups::WRONGTYPE_ERR),
                }
            };
        }
        // now let us see what we need to do
        match unsafe { act.next_uppercase_unchecked() }.as_ref() {
            CLEAR => {
                err_if_len_is!(act, con, not 0);
                let list = match listmap.kve_inner_ref().get(listname) {
                    Some(l) => l,
                    _ => return conwrite!(con, groups::NIL),
                };
                let okay = if registry::state_okay() {
                    list.write().clear();
                    true
                } else {
                    false
                };
                if okay {
                    conwrite!(con, groups::OKAY)?;
                } else {
                    conwrite!(con, groups::SERVER_ERR)?;
                }
            }
            PUSH => {
                err_if_len_is!(act, con, not 1);
                let list = match listmap.kve_inner_ref().get(listname) {
                    Some(l) => l,
                    _ => return conwrite!(con, groups::NIL),
                };
                let okay = unsafe {
                    if registry::state_okay() {
                        list.write().push(act.next_unchecked_bytes().into());
                        true
                    } else {
                        false
                    }
                };
                if okay {
                    conwrite!(con, groups::OKAY)?;
                } else {
                    conwrite!(con, groups::SERVER_ERR)?;
                }
            }
            REMOVE => {
                err_if_len_is!(act, con, not 2);
                let idx_to_remove = get_numeric_count!();
                if registry::state_okay() {
                    let maybe_value = listmap.kve_inner_ref().get(listname).map(|list| {
                        let mut wlock = list.write();
                        if idx_to_remove < wlock.len() {
                            wlock.remove(idx_to_remove);
                            true
                        } else {
                            false
                        }
                    });
                    match maybe_value {
                        Some(true) => {
                            // we removed the value
                            conwrite!(con, groups::OKAY)?;
                        }
                        Some(false) => {
                            conwrite!(con, groups::LISTMAP_BAD_INDEX)?;
                        }
                        None => {
                            conwrite!(con, groups::NIL)?;
                        }
                    }
                } else {
                    conwrite!(con, groups::SERVER_ERR)?;
                }
            }
            _ => conwrite!(con, groups::UNKNOWN_ACTION)?,
        }
        Ok(())
    }

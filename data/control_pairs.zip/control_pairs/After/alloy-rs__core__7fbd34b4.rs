pub fn format_units_with<T, K, E>(
    amount: T,
    units: K,
    separator: DecimalSeparator,
) -> Result<String, UnitsError>
where
    T: Into<ParseUnits>,
    K: TryInto<Unit, Error = E>,
    UnitsError: From<E>,
{
    units
        .try_into()
        .map(|units| amount.into().format_units_with(units, separator))
        .map_err(UnitsError::from)
}

    fn write(&mut self, bytes: &[u8]) {
        // This expects to receive one and exactly one 64-bit value
        debug_assert!(bytes.len() == 8);
        unsafe {
            std::ptr::copy_nonoverlapping_memory(&mut self.value,
                                                 std::mem::transmute(&bytes[0]),
                                                 1)
        }
    }
    fn hash<T: Hash<TypeIdState>>(&self, value: &T) -> u64 {
        let mut state = TypeIdState {
            value: 0,
        };
        value.hash(&mut state);
        state.value
    }
pub struct AnyMap {
    data: HashMap<TypeId, Box<Any>:'static, TypeIdHasher>,
}
    pub fn new() -> AnyMap {
        AnyMap {
            data: HashMap::with_hasher(TypeIdHasher),
        }
    }

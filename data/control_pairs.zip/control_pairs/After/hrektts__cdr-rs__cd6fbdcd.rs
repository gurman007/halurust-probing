    fn read_padding_of<T>(&mut self) -> Result<()> {
        // Calculate the required padding to align with 1-byte, 2-byte, 4-byte, 8-byte boundaries
        // Instead of using the slow modulo operation '%', the faster bit-masking is used
        let alignment: usize = std::mem::size_of::<T>();
        let rem_mask: usize = alignment - 1; // mask like 0x0, 0x1, 0x3, 0x7
        let mut padding: [u8; 8] = [0; 8];
        match (self.pos as usize) & rem_mask {
            0 => Ok(()),
            n @ 1...7 => {
                let amt = alignment - n;
                self.read_size(amt as u64)?;
                self.reader
                    .read_exact(&mut padding[..amt])
                    .map_err(Into::into)
            }
            _ => unreachable!(),
        }
    }
    fn write_padding_of<T>(&mut self) -> Result<()> {
        // Calculate the required padding to align with 1-byte, 2-byte, 4-byte, 8-byte boundaries
        // Instead of using the slow modulo operation '%', the faster bit-masking is used
        const PADDING: [u8; 8] = [0; 8];
        let alignment: usize = std::mem::size_of::<T>();
        let rem_mask: usize = alignment - 1; // mask like 0x0, 0x1, 0x3, 0x7
        match (self.pos as usize) & rem_mask {
            0 => Ok(()),
            n @ 1...7 => {
                let amt = alignment - n;
                self.pos += amt as u64;
                self.writer.write_all(&PADDING[..amt]).map_err(Into::into)
            }
            _ => unreachable!(),
        }
    }

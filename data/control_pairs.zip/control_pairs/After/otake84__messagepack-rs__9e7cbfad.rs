    pub fn serialize(&self) -> Result<Vec<u8>, SerializeError> {
        match self {
            Value::Nil => Ok(vec![Marker::Nil.into()]),
            Value::Bool(v) => Ok(if *v { vec![Marker::True.into()] } else { vec![Marker::False.into()] }),
            Value::Float32(v) => {
                let mut w = Vec::with_capacity(1 + 4);
                w.write_u8(Marker::Float32.into()).or(Err(SerializeError::FailedToWrite))?;
                w.write_f32::<BigEndian>(*v).or(Err(SerializeError::FailedToWrite))?;
                Ok(w)
            },
            Value::Float64(v) => {
                let mut w = Vec::with_capacity(1 + 8);
                w.write_u8(Marker::Float64.into()).or(Err(SerializeError::FailedToWrite))?;
                w.write_f64::<BigEndian>(*v).or(Err(SerializeError::FailedToWrite))?;
                Ok(w)
            },
            Value::UInt8(v) => {
                if *v < 0b10000000 {
                    let mut w = Vec::with_capacity(1);
                    w.write_u8(*v).or(Err(SerializeError::FailedToWrite))?;
                    Ok(w)
                } else {
                    let mut w = Vec::with_capacity(1 + 1);
                    w.write_u8(Marker::UInt8.into()).or(Err(SerializeError::FailedToWrite))?;
                    w.write_u8(*v).or(Err(SerializeError::FailedToWrite))?;
                    Ok(w)
                }
            },
            _ => unimplemented!(),
        }
    }

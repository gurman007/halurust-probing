        extern "C" fn call_boxed_closure<F, T>(ctx: *mut sqlite3_context,
                                               argc: c_int,
                                               argv: *mut *mut sqlite3_value)
            where F: FnMut(&Context) -> SqliteResult<T>,
                  T: ToResult
        {
            unsafe {
                let ctx = Context {
                    ctx: ctx,
                    args: slice::from_raw_parts(argv, argc as usize),
                };
                let boxed_f: *mut F = mem::transmute(ffi::sqlite3_user_data(ctx.ctx));
                assert!(!boxed_f.is_null(), "Internal error - null function pointer");
                match (*boxed_f)(&ctx) {
                    Ok(r) => r.set_result(ctx.ctx),
                    Err(e) => {
                        ffi::sqlite3_result_error_code(ctx.ctx, e.code);
                        if let Ok(cstr) = str_to_cstring(&e.message) {
                            ffi::sqlite3_result_error(ctx.ctx, cstr.as_ptr(), -1);
                        }
                    }
                }
            }
        }
    fn regexp_with_auxilliary(ctx: &Context) -> SqliteResult<bool> {
        assert!(ctx.len() == 2, "called with unexpected number of arguments");

        let saved_re: Option<&Regex> = unsafe { ctx.get_aux(0) };
        let new_re = match saved_re {
            None => {
                let s = try!(ctx.get::<String>(0));
                let r = try!(Regex::new(&s).map_err(|e| {
                    SqliteError {
                        code: ffi::SQLITE_ERROR,
                        message: format!("Invalid regular expression: {}", e),
                    }
                }));
                Some(r)
            }
            Some(_) => None,
        };

        let is_match = {
            let re = saved_re.unwrap_or_else(|| new_re.as_ref().unwrap());

            let text = try!(ctx.get::<String>(1));
            re.is_match(&text)
        };

        if let Some(re) = new_re {
            ctx.set_aux(0, re);
        }

        Ok(is_match)
    }
    fn test_function_regexp_with_auxilliary() {
        let db = SqliteConnection::open_in_memory().unwrap();
        db.execute_batch("BEGIN;
                         CREATE TABLE foo (x string);
                         INSERT INTO foo VALUES ('lisa');
                         INSERT INTO foo VALUES ('lXsi');
                         INSERT INTO foo VALUES ('lisX');
                         END;").unwrap();
        db.create_scalar_function("regexp", 2, true, regexp_with_auxilliary).unwrap();

        let result = db.query_row("SELECT regexp('l.s[aeiouy]', 'lisa')",
                                  &[],
                                  |r| r.get::<bool>(0));

        assert_eq!(true, result.unwrap());

        let result = db.query_row("SELECT COUNT(*) FROM foo WHERE regexp('l.s[aeiouy]', x) == 1",
                                  &[],
                                  |r| r.get::<i64>(0));

        assert_eq!(2, result.unwrap());
    }
    fn test_function_regexp_with_hashmap_cache() {
        let db = SqliteConnection::open_in_memory().unwrap();
        db.execute_batch("BEGIN;
                         CREATE TABLE foo (x string);
                         INSERT INTO foo VALUES ('lisa');
                         INSERT INTO foo VALUES ('lXsi');
                         INSERT INTO foo VALUES ('lisX');
                         END;").unwrap();

        // This implementation of a regexp scalar function uses a captured HashMap
        // to keep cached regular expressions around (even across multiple queries)
        // until the function is removed.
        let mut cached_regexes = HashMap::new();
        db.create_scalar_function("regexp", 2, true, move |ctx| {
            assert!(ctx.len() == 2, "called with unexpected number of arguments");

            let regex_s = try!(ctx.get::<String>(0));
            let entry = cached_regexes.entry(regex_s.clone());
            let regex = {
                use std::collections::hash_map::Entry::{Occupied, Vacant};
                match entry {
                    Occupied(occ) => occ.into_mut(),
                    Vacant(vac) => {
                        let r = try!(Regex::new(&regex_s).map_err(|e| SqliteError {
                            code: ffi::SQLITE_ERROR,
                            message: format!("Invalid regular expression: {}", e),
                        }));
                        vac.insert(r)
                    }
                }
            };

            let text = try!(ctx.get::<String>(1));
            Ok(regex.is_match(&text))
        }).unwrap();

        let result = db.query_row("SELECT regexp('l.s[aeiouy]', 'lisa')",
                                  &[],
                                  |r| r.get::<bool>(0));

        assert_eq!(true, result.unwrap());

        let result = db.query_row("SELECT COUNT(*) FROM foo WHERE regexp('l.s[aeiouy]', x) == 1",
                                  &[],
                                  |r| r.get::<i64>(0));

        assert_eq!(2, result.unwrap());
    }

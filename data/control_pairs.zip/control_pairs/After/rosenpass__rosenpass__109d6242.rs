pub struct Peer {
    pub psk: SymKey,
    pub spkt: SPk,
    pub biscuit_used: BiscuitId,
    pub session: Option<Session>,
    pub handshake: Option<InitiatorHandshake>,
    pub initiation_requested: bool,
}
    pub fn zero() -> Self {
        Self {
            psk: SymKey::zero(),
            spkt: SPk::zero(),
            biscuit_used: BiscuitId::zero(),
            session: None,
            initiation_requested: false,
            handshake: None,
        }
    }
pub struct InitiatorHandshake {
    pub created_at: Timing,
    pub next: HandshakeStateMachine,
    pub core: HandshakeState,
    /// Ephemeral Secret Key of Initiator
    pub eski: ESk,
    /// Ephemeral Public Key of Initiator
    pub epki: EPk,

    // Retransmission
    // TODO: Ensure that this is correct by typing
    pub tx_at: Timing,
    pub tx_retry_at: Timing,
    pub tx_count: usize,
    pub tx_len: usize,
    pub tx_buf: MsgBuf,

    // Cookie storage for retransmission
    pub cookie_tau: CookieSecret,
}
    pub fn add_peer(&mut self, psk: Option<SymKey>, pk: SPk) -> Result<PeerPtr> {
        let peer = Peer {
            psk: psk.unwrap_or_else(SymKey::zero),
            spkt: pk,
            biscuit_used: BiscuitId::zero(),
            session: None,
            handshake: None,
            initiation_requested: false,
        };
        let peerid = peer.pidt()?;
        let peerno = self.peers.len();
        match self.index.entry(IndexKey::Peer(peerid)) {
            Occupied(_) => bail!(
                "Cannot insert peer with id {:?}; peer with this id already registered.",
                peerid
            ),
            Vacant(e) => e.insert(peerno),
        };
        self.peers.push(peer);
        Ok(PeerPtr(peerno))
    }
    pub fn new(psk: SymKey, pk: SPk) -> Peer {
        Peer {
            psk,
            spkt: pk,
            biscuit_used: BiscuitId::zero(),
            session: None,
            handshake: None,
            initiation_requested: false,
        }
    }
    pub fn seal_cookie(&mut self, peer: PeerPtr, srv: &CryptoServer) -> Result<()> {
        if let Some(ih) = &peer.get(srv).handshake {
            if let Some(cookie_tau) = ih.cookie_tau.get(PEER_COOKIE_TAU_EXP) {
                let cookie = hash_domains::cookie()?
                    .mix(cookie_tau)?
                    .mix(self.until_cookie())?;
                self.cookie_mut()
                    .copy_from_slice(cookie.into_value()[..16].as_ref());
            }
        }
        Ok(())
    }
    pub fn zero_with_timestamp(srv: &CryptoServer) -> Self {
        InitiatorHandshake {
            created_at: srv.timebase.now(),
            next: HandshakeStateMachine::RespHello,
            core: HandshakeState::zero(),
            eski: ESk::zero(),
            epki: EPk::zero(),
            tx_at: 0.0,
            tx_retry_at: 0.0,
            tx_count: 0,
            tx_len: 0,
            tx_buf: MsgBuf::zero(),
            cookie_tau: CookieSecret::None,
        }
    }
    pub fn handle_cookie_reply(&mut self, cr: CookieReply<&[u8]>) -> Result<PeerPtr> {
        let session_id = SessionId::from_slice(cr.sid());

        let peer_ptr: Option<PeerPtr> = self
            .lookup_session(session_id)
            .map(|v| PeerPtr(v.0))
            .or_else(|| self.lookup_handshake(session_id).map(|v| PeerPtr(v.0)));
        if let Some(peer) = peer_ptr {
            // Get last transmitted handshake message
            if let Some(ih) = &peer.get(self).handshake {
                let mut mac = [0u8; MAC_SIZE];
                match ih.tx_buf[0].try_into() {
                    Ok(MsgType::InitHello) => {
                        match ih.tx_buf.envelope_truncating::<InitHello<&mut [u8]>>() {
                            Ok(t) => {
                                mac.copy_from_slice(t.mac());
                                Ok(())
                            }
                            Err(e) => Err(e),
                        }
                    }
                    Ok(MsgType::InitConf) => {
                        match ih.tx_buf.envelope_truncating::<InitConf<&mut [u8]>>() {
                            Ok(t) => {
                                mac.copy_from_slice(t.mac());
                                Ok(())
                            }
                            Err(e) => Err(e),
                        }
                    }
                    _ => bail!(
                        "No last sent message for peer {pidr:?} to decrypt cookie reply.",
                        pidr = cr.sid()
                    ),
                }?;
                let mut cookie_value = Secret::zero();
                let spkt = peer.get(self).spkt.secret();
                let cookie_key = hash_domains::cookie_key()?.mix(spkt)?.into_value();

                xaead::decrypt(
                    cookie_value.secret_mut(),
                    &cookie_key,
                    &mac,
                    &cr.all_bytes()[4..],
                )?;

                peer.get_mut(self).handshake.as_mut().unwrap().cookie_tau =
                    CookieSecret::Some {
                        value: cookie_value,
                        last_updated: Timebase::default(),
                    };
                Ok(peer)
            } else {
                bail!(
                    "No last sent message for peer {pidr:?} to decrypt cookie reply.",
                    pidr = cr.sid()
                );
            }
        } else {
            bail!("No such peer {pidr:?}.", pidr = cr.sid());
        }
    }
    fn cookie_reply_mechanism_responder_under_load() {
        rosenpass_sodium::init().unwrap();

        stacker::grow(8 * 1024 * 1024, || {
            type MsgBufPlus = Public<MAX_MESSAGE_LEN>;
            let (mut a, mut b) = make_server_pair().unwrap();

            let mut a_to_b_buf = MsgBufPlus::zero();
            let mut b_to_a_buf = MsgBufPlus::zero();

            let ip_a: SocketAddrV4 = "127.0.0.1:8080".parse().unwrap();
            let mut ip_addr_port_a = ip_a.ip().octets().to_vec();
            ip_addr_port_a.extend_from_slice(&ip_a.port().to_be_bytes());

            let _ip_b: SocketAddrV4 = "127.0.0.1:8081".parse().unwrap();

            let init_hello_len = a.initiate_handshake(PeerPtr(0), &mut *a_to_b_buf).unwrap();
            let socket_addr_a = std::net::SocketAddr::V4(ip_a);
            let mut ip_addr_port_a = match socket_addr_a.ip() {
                std::net::IpAddr::V4(ipv4) => ipv4.octets().to_vec(),
                std::net::IpAddr::V6(ipv6) => ipv6.octets().to_vec(),
            };

            ip_addr_port_a.extend_from_slice(&socket_addr_a.port().to_be_bytes());

            //B handles handshake under load, should send cookie reply message with invalid cookie
            let HandleMsgResult { resp, .. } = b
                .handle_msg_under_load(
                    &a_to_b_buf.as_slice()[..init_hello_len],
                    &mut *b_to_a_buf,
                    PeerPtr(0),
                    &ip_addr_port_a,
                )
                .unwrap();

            let cookie_reply_len = resp.unwrap();

            //A handles cookie reply message
            a.handle_msg(&b_to_a_buf[..cookie_reply_len], &mut *a_to_b_buf)
                .unwrap();

            assert!(a.peers[0].handshake.as_ref().unwrap().cookie_tau.is_some());

            let expected_cookie_tau = hash_domains::cookie_tau()
                .unwrap()
                .mix(b.cookie_secret.get(COOKIE_SECRET_EXP).unwrap())
                .unwrap()
                .mix(&ip_addr_port_a)
                .unwrap()
                .into_value()[..16]
                .to_vec();
            assert_eq!(
                a.peers[0].handshake.as_ref().unwrap().cookie_tau.get(PEER_COOKIE_TAU_EXP),
                Some(&expected_cookie_tau[..])
            );

            let retx_init_hello_len = loop {
                match a.poll().unwrap() {
                    PollResult::SendRetransmission(peer) => {
                        break (a.retransmit_handshake(peer, &mut *a_to_b_buf).unwrap());
                    }
                    PollResult::Sleep(time) => {
                        sleep(Duration::from_secs_f64(time));
                    }
                    _ => {}
                }
            };

            let retx_msg_type: MsgType = a_to_b_buf.value[0].try_into().unwrap();
            assert_eq!(retx_msg_type, MsgType::InitHello);

            //B handles retransmitted message
            let HandleMsgResult { resp, .. } = b
                .handle_msg_under_load(
                    &a_to_b_buf.as_slice()[..retx_init_hello_len],
                    &mut *b_to_a_buf,
                    PeerPtr(0),
                    &ip_addr_port_a,
                )
                .unwrap();

            let _resp_hello_len = resp.unwrap();

            let resp_msg_type: MsgType = b_to_a_buf.value[0].try_into().unwrap();
            assert_eq!(resp_msg_type, MsgType::RespHello);
        });
    }

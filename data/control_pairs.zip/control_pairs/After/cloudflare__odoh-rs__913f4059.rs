    pub fn identifier(&self) -> Result<Vec<u8>> {
        let buf = compose(self)?;

        let key_id_info = LABEL_KEY_ID.to_vec();
        let prk = Hkdf::<<Kdf as KdfTrait>::HashImpl>::new(None, &buf);
        let mut key_id = [0; KDF_OUTPUT_SIZE];
        prk.expand(&key_id_info, &mut key_id)
            .map_err(|_| Error::from(HpkeError::InvalidKdfLength))?;
        Ok(key_id.to_vec())
    }
    pub fn key_id(&self) -> &[u8] {
        self.key_id.as_ref()
    }
    pub fn from_parameters(kem_id: u16, kdf_id: u16, aead_id: u16, ikm: &[u8]) -> Self {
        // derive keypair from ikm
        let (private_key, public_key) = Kem::derive_keypair(ikm);
        Self {
            private_key,
            public_key: ObliviousDoHConfigContents {
                kem_id,
                kdf_id,
                aead_id,
                public_key: public_key.to_bytes().to_vec().into(),
            },
        }
    }

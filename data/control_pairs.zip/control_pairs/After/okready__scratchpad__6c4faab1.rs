    pub fn concat<'marker, IntoIteratorT, IteratorT, StrT>(
        &'marker self,
        strings: IntoIteratorT,
    ) -> Result<Allocation<'marker, 'static, str>, Error>
    where
        IntoIteratorT: IntoIterator<Item = StrT, IntoIter = IteratorT>,
        IteratorT: Iterator<Item = StrT> + Clone,
        StrT: AsRef<str>,
    {
        Marker::concat(self, strings)
    }
pub trait Marker {
    /// Allocates space for the given value, moving it into the allocation.
    ///
    /// # Examples
    ///
    /// ```
    /// use scratchpad::Scratchpad;
    ///
    /// let scratchpad = Scratchpad::<[u64; 1], [usize; 1]>::new([0], [0]);
    /// let marker = scratchpad.mark_front().unwrap();
    ///
    /// let x = marker.allocate(3.14159).unwrap();
    /// assert_eq!(*x, 3.14159);
    /// ```
    fn allocate<'marker, 't, T>(
        &'marker self,
        value: T,
    ) -> Result<Allocation<'marker, 't, T>, Error> {
        unsafe {
            self.allocate_uninitialized::<T>()
                .map(|allocation| {
                    ptr::write(allocation.data, value);
                    allocation
                })
        }
    }

    /// Allocates space for a value, initializing it to its default.
    ///
    /// # Examples
    ///
    /// ```
    /// use scratchpad::Scratchpad;
    ///
    /// let scratchpad = Scratchpad::<[u64; 1], [usize; 1]>::new([0], [0]);
    /// let marker = scratchpad.mark_front().unwrap();
    ///
    /// let x = marker.allocate_default::<f64>().unwrap();
    /// assert_eq!(*x, 0.0);
    /// ```
    fn allocate_default<'marker, 't, T: Default>(
        &'marker self,
    ) -> Result<Allocation<'marker, 't, T>, Error> {
        self.allocate(Default::default())
    }

    /// Allocates uninitialized space for the given type.
    ///
    /// # Safety
    ///
    /// Since memory for the allocated data is uninitialized, it can
    /// potentially be in an invalid state for a given type, leading to
    /// undefined program behavior. It is recommended that one of the safe
    /// `allocate*()` methods are used instead if possible.
    ///
    /// # Examples
    ///
    /// ```
    /// use scratchpad::Scratchpad;
    ///
    /// let scratchpad = Scratchpad::<[u64; 1], [usize; 1]>::new([0], [0]);
    /// let marker = scratchpad.mark_front().unwrap();
    ///
    /// let mut x = unsafe { marker.allocate_uninitialized().unwrap() };
    /// *x = 3.14159;
    /// assert_eq!(*x, 3.14159);
    /// ```
    unsafe fn allocate_uninitialized<'marker, 't, T>(
        &'marker self,
    ) -> Result<Allocation<'marker, 't, T>, Error> {
        let data = self.allocate_memory(align_of::<T>(), size_of::<T>(), 1)?;

        Ok(Allocation {
            data: &mut *(data as *mut T),
            _phantom: PhantomData,
        })
    }

    /// Allocates space for an array, initializing each element with the given
    /// value.
    ///
    /// # Examples
    ///
    /// ```
    /// use scratchpad::Scratchpad;
    ///
    /// let scratchpad = Scratchpad::<[u64; 3], [usize; 1]>::new([0; 3], [0]);
    /// let marker = scratchpad.mark_front().unwrap();
    ///
    /// let x = marker.allocate_array(3, 3.14159).unwrap();
    /// assert_eq!(*x, [3.14159, 3.14159, 3.14159]);
    /// ```
    fn allocate_array<'marker, 't, T: Clone>(
        &'marker self,
        len: usize,
        value: T,
    ) -> Result<Allocation<'marker, 't, [T]>, Error> {
        unsafe {
            self.allocate_array_uninitialized(len)
                .map(|allocation| {
                    debug_assert_eq!(allocation.data.len(), len);
                    for element in allocation.data.iter_mut() {
                        ptr::write(element, value.clone());
                    }
                    allocation
                })
        }
    }

    /// Allocates space for an array, initializing each element to its default
    /// value.
    ///
    /// # Examples
    ///
    /// ```
    /// use scratchpad::Scratchpad;
    ///
    /// let scratchpad = Scratchpad::<[u64; 3], [usize; 1]>::new([0; 3], [0]);
    /// let marker = scratchpad.mark_front().unwrap();
    ///
    /// let x = marker.allocate_array_default::<f64>(3).unwrap();
    /// assert_eq!(*x, [0.0, 0.0, 0.0]);
    /// ```
    fn allocate_array_default<'marker, 't, T: Default>(
        &'marker self,
        len: usize,
    ) -> Result<Allocation<'marker, 't, [T]>, Error> {
        unsafe {
            self.allocate_array_uninitialized(len)
                .map(|allocation| {
                    debug_assert_eq!(allocation.data.len(), len);
                    for element in allocation.data.iter_mut() {
                        ptr::write(element, Default::default());
                    }
                    allocation
                })
        }
    }

    /// Allocates space for an array, initializing each element with the
    /// result of a function.
    ///
    /// The function `func` takes a single parameter containing the index of
    /// the element being initialized.
    ///
    /// # Examples
    ///
    /// ```
    /// use scratchpad::Scratchpad;
    ///
    /// let scratchpad = Scratchpad::<[u64; 3], [usize; 1]>::new([0; 3], [0]);
    /// let marker = scratchpad.mark_front().unwrap();
    ///
    /// let x = marker.allocate_array_with(3, |index| index as f64).unwrap();
    /// assert_eq!(*x, [0.0, 1.0, 2.0]);
    /// ```
    fn allocate_array_with<'marker, 't, T, F: FnMut(usize) -> T>(
        &'marker self,
        len: usize,
        mut func: F,
    ) -> Result<Allocation<'marker, 't, [T]>, Error> {
        unsafe {
            self.allocate_array_uninitialized(len)
                .map(|allocation| {
                    debug_assert_eq!(allocation.data.len(), len);
                    for (index, element) in
                        allocation.data.iter_mut().enumerate()
                    {
                        ptr::write(element, func(index));
                    }
                    allocation
                })
        }
    }

    /// Allocates uninitialized space for an array of the given type.
    ///
    /// # Safety
    ///
    /// Since memory for the allocated data is uninitialized, it can
    /// potentially be in an invalid state for a given type, leading to
    /// undefined program behavior. It is recommended that one of the safe
    /// `allocate*()` methods are used instead if possible.
    ///
    /// # Examples
    ///
    /// ```
    /// use scratchpad::Scratchpad;
    ///
    /// let scratchpad = Scratchpad::<[u64; 3], [usize; 1]>::new([0; 3], [0]);
    /// let marker = scratchpad.mark_front().unwrap();
    ///
    /// let mut x = unsafe {
    ///     marker.allocate_array_uninitialized(3).unwrap()
    /// };
    /// x[0] = 3.14159;
    /// x[1] = 4.14159;
    /// x[2] = 5.14159;
    /// assert_eq!(*x, [3.14159, 4.14159, 5.14159]);
    /// ```
    unsafe fn allocate_array_uninitialized<'marker, 't, T>(
        &'marker self,
        len: usize,
    ) -> Result<Allocation<'marker, 't, [T]>, Error> {
        let data =
            self.allocate_memory(align_of::<T>(), size_of::<T>(), len)?;

        Ok(Allocation {
            data: slice::from_raw_parts_mut(data as *mut T, len),
            _phantom: PhantomData,
        })
    }

    /// Combines each of the provided strings into a single string slice
    /// allocated from this marker.
    ///
    /// # Examples
    ///
    /// ```
    /// use scratchpad::Scratchpad;
    ///
    /// let scratchpad = Scratchpad::<[u8; 16], [usize; 1]>::static_new();
    /// let marker = scratchpad.mark_front().unwrap();
    ///
    /// let combined = marker.concat(&["Hello,", " world", "!"]).unwrap();
    /// assert_eq!(&*combined, "Hello, world!");
    /// ```
    fn concat<'marker, IntoIteratorT, IteratorT, StrT>(
        &'marker self,
        strings: IntoIteratorT,
    ) -> Result<Allocation<'marker, 'static, str>, Error>
    where
        IntoIteratorT: IntoIterator<Item = StrT, IntoIter = IteratorT>,
        IteratorT: Iterator<Item = StrT> + Clone,
        StrT: AsRef<str>,
    {
        let iter = strings.into_iter();
        let size = iter.clone()
            .fold(0usize, |sum, item| sum + item.as_ref().len());
        let mut result = unsafe { self.allocate_array_uninitialized(size)? };

        let mut start = 0usize;
        for item in iter {
            let string_ref = item.as_ref();
            let end = start + string_ref.len();
            result[start..end].copy_from_slice(string_ref[..].as_bytes());
            start = end;
        }

        unsafe { Ok(transmute(result)) }
    }

    /// Allocates a block of memory of a given size and alignment.
    ///
    /// If successful, returns a tuple containing the allocation address and
    /// allocation index.
    ///
    /// **_This is intended primarily for use by the internal implementation
    /// of this trait, and is not safe for use by external code. Its signature
    /// and behavior are not guaranteed to be consistent across versions of
    /// this crate._**
    #[doc(hidden)]
    unsafe fn allocate_memory(
        &self,
        alignment: usize,
        size: usize,
        len: usize,
    ) -> Result<*mut u8, Error>;
}
    pub unsafe fn allocate_array_uninitialized<'marker, 't, T>(
        &'marker self,
        len: usize,
    ) -> Result<Allocation<'marker, 't, [T]>, Error> {
        Marker::allocate_array_uninitialized(self, len)
    }

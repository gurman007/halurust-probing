    fn test_base_2b<OutLen: ArraySize, B: Unsigned>(x: &[u8]) {
        if x.len() < (OutLen::USIZE * B::USIZE + 7) / 8 {
            return; // TODO: enforce this at the prop level
        }

        let a = base_2b::<OutLen, B>(x);
        let mut b = BoxedUint::from_be_slice_vartime(&x[..(OutLen::USIZE * B::USIZE + 7) / 8]);

        if (B::USIZE * OutLen::USIZE) % 8 != 0 {
            // Clear lower bits of b
            b >>= 8 - ((B::USIZE * OutLen::USIZE) % 8);
        }

        let c: BoxedUint = a.iter().fold(
            BoxedUint::zero_with_precision(b.bits_precision()),
            |acc, x| (acc << B::U32) + *x,
        );

        assert_eq!(b, c);
    }

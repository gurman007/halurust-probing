	pub fn transact<T: trace::Tracer, V: trace::VMTracer>(
		&mut self,
		env_info: &client::EnvInfo,
		transaction: transaction::SignedTransaction,
		tracer: T,
		vm_tracer: V,
	) -> std::result::Result<TransactSuccess<T::Output, V::Output>, TransactErr> {
		let initial_gas = transaction.gas;
		// Verify transaction
		let is_ok = transaction.verify_basic(true, None, false);
		if let Err(error) = is_ok {
			return Err(
				TransactErr{
					state_root: *self.state.root(),
					error: error.into(),
					end_state: (self.dump_state)(&self.state),
				});
		}

		// Apply transaction
		let result = self.state.apply_with_tracing(&env_info, self.spec.engine.machine(), &transaction, tracer, vm_tracer);
		let scheme = self.spec.engine.machine().create_address_scheme(env_info.number);

		// Touch the coinbase at the end of the test to simulate
		// miner reward.
		// Details: https://github.com/paritytech/parity-ethereum/issues/9431
		let schedule = self.spec.engine.machine().schedule(env_info.number);
		self.state.add_balance(&env_info.author, &0.into(), if schedule.no_empty {
			state::CleanupMode::NoEmpty
		} else {
			state::CleanupMode::ForceCreate
		}).ok();
		// Touching also means that we should remove the account if it's within eip161
		// conditions.
		self.state.kill_garbage(
			&vec![env_info.author].into_iter().collect(),
			schedule.kill_empty,
			&None,
			false
		).ok();

		self.state.commit().ok();

		let state_root = *self.state.root();

		let end_state = (self.dump_state)(&self.state);

		match result {
			Ok(result) => {
				Ok(TransactSuccess {
					state_root,
					gas_left: initial_gas - result.receipt.gas_used,
					outcome: result.receipt.outcome,
					output: result.output,
					trace: result.trace,
					vm_trace: result.vm_trace,
					logs: result.receipt.logs,
					contract_address: if let transaction::Action::Create = transaction.action {
						Some(executive::contract_address(scheme, &transaction.sender(), &transaction.nonce, &transaction.data).0)
					} else {
						None
					},
					end_state,
				}
			)},
			Err(error) => Err(TransactErr {
				state_root,
				error,
				end_state,
			}),
		}
	}
pub struct TransactSuccess<T, V> {
	/// State root
	pub state_root: H256,
	/// Amount of gas left
	pub gas_left: U256,
	/// Output
	pub output: Vec<u8>,
	/// Traces
	pub trace: Vec<T>,
	/// VM Traces
	pub vm_trace: Option<V>,
	/// Created contract address (if any)
	pub contract_address: Option<H160>,
	/// Generated logs
	pub logs: Vec<log_entry::LogEntry>,
	/// outcome
	pub outcome: receipt::TransactionOutcome,
	/// end state if needed
	pub end_state: Option<pod_state::PodState>,
}
pub struct TransactErr {
	/// State root
	pub state_root: H256,
	/// Execution error
	pub error: ::error::Error,
	/// end state if needed
	pub end_state: Option<pod_state::PodState>,
}
pub fn json_chain_test<H: FnMut(&str, HookType)>(json_data: &[u8], start_stop_hook: &mut H) -> Vec<String> {
	let _ = ::env_logger::try_init();
	let tests = ethjson::state::test::Test::load(json_data).unwrap();
	let mut failed = Vec::new();

	for (name, test) in tests.into_iter() {
		start_stop_hook(&name, HookType::OnStart);

		{
			let multitransaction = test.transaction;
			let env: EnvInfo = test.env.into();
			let pre: PodState = test.pre_state.into();

			for (spec_name, states) in test.post_states {
				let total = states.len();
				let spec = match EvmTestClient::spec_from_json(&spec_name) {
					Some(spec) => spec,
					None => {
						println!("   - {} | {:?} Ignoring tests because of missing spec", name, spec_name);
						continue;
					}
				};

				for (i, state) in states.into_iter().enumerate() {
					let info = format!("   - {} | {:?} ({}/{}) ...", name, spec_name, i + 1, total);
					if skip_test(&name, &spec.name, i + 1) {
						println!("{} in skip list : SKIPPED", info);
						continue;
					}

					let post_root: H256 = state.hash.into();
					let transaction: SignedTransaction = multitransaction.select(&state.indexes).into();

					let result = || -> Result<_, EvmTestError> {
						Ok(EvmTestClient::from_pod_state(&spec, pre.clone())?
							.transact(&env, transaction, trace::NoopTracer, trace::NoopVMTracer))
					};
					match result() {
						Err(err) => {
							println!("{} !!! Unexpected internal error: {:?}", info, err);
							flushln!("{} fail", info);
							failed.push(name.clone());
						},
						Ok(Ok(TransactSuccess { state_root, .. })) if state_root != post_root => {
							println!("{} !!! State mismatch (got: {}, expect: {}", info, state_root, post_root);
							flushln!("{} fail", info);
							failed.push(name.clone());
						},
						Ok(Err(TransactErr { state_root, ref error, .. })) if state_root != post_root => {
							println!("{} !!! State mismatch (got: {}, expect: {}", info, state_root, post_root);
							println!("{} !!! Execution error: {:?}", info, error);
							flushln!("{} fail", info);
							failed.push(name.clone());
						},
						Ok(Err(TransactErr { error, .. })) => {
							flushln!("{} ok ({:?})", info, error);
						},
						Ok(_) => {
							flushln!("{} ok", info);
						},
					}
				}
			}
		}

		start_stop_hook(&name, HookType::OnStop);
	}

	if !failed.is_empty() {
		println!("!!! {:?} tests failed.", failed.len());
	}
	failed
}
pub fn run_transaction<T: Informant>(
	name: &str,
	idx: usize,
	spec: &ethjson::spec::ForkSpec,
	pre_state: &pod_state::PodState,
	post_root: H256,
	env_info: &client::EnvInfo,
	transaction: transaction::SignedTransaction,
	mut informant: T,
	trie_spec: TrieSpec,
) {
	let spec_name = format!("{:?}", spec).to_lowercase();
	let spec = match EvmTestClient::spec_from_json(spec) {
		Some(spec) => {
			informant.before_test(&format!("{}:{}:{}", name, spec_name, idx), "starting");
			spec
		},
		None => {
			informant.before_test(&format!("{}:{}:{}", name, spec_name, idx), "skipping because of missing spec");
			return;
		},
	};

	informant.set_gas(env_info.gas_limit);

	let mut sink = informant.clone_sink();
	let result = run(&spec, trie_spec, transaction.gas, pre_state, |mut client| {
		let result = client.transact(env_info, transaction, trace::NoopTracer, informant);
		match result {
			Ok(TransactSuccess { state_root, gas_left, output, vm_trace, end_state, .. }) => {
				if state_root != post_root {
					(Err(EvmTestError::PostCondition(format!(
						"State root mismatch (got: {:#x}, expected: {:#x})",
						state_root,
						post_root,
					))), state_root, end_state, Some(gas_left), None)
				} else {
					(Ok(output), state_root, end_state, Some(gas_left), vm_trace)
				}
			},
			Err(TransactErr { state_root, error, end_state }) => {
				(Err(EvmTestError::PostCondition(format!(
					"Unexpected execution error: {:?}", error
				))), state_root, end_state, None, None)
			},
		}
	});

	T::finish(result, &mut sink)
}

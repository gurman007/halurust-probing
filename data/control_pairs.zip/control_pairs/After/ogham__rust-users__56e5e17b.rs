        pub struct UserExtras {
            pub extras: super::unix::UserExtras,
            pub change: time_t,
            pub expire: time_t,
        }
            pub unsafe fn from_passwd(passwd: c_passwd) -> UserExtras {
                UserExtras {
                    change: passwd.pw_change,
                    expire: passwd.pw_expire,
                    extras: super::unix::UserExtras::from_passwd(passwd),
                }
            }
            fn home_dir(&self) -> &Path {
                Path::new(&self.extras.extras.home_dir)
            }
            fn with_home_dir(mut self, home_dir: &str) -> User {
                self.extras.extras.home_dir = home_dir.to_owned();
                self
            }
            fn shell(&self) -> &Path {
                Path::new(&self.extras.extras.shell)
            }
            fn with_shell(mut self, shell: &str) -> User {
                self.extras.extras.shell = shell.to_owned();
                self
            }
            fn default() -> UserExtras {
                UserExtras {
                    extras: super::unix::UserExtras::default(),
                    change: 0,
                    expire: 0,
                }
            }

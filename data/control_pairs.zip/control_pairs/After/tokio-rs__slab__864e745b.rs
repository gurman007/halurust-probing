    pub fn replace_with<F>(&mut self, idx: I, fun: F)
        -> Result<(), ()>
        where F: FnOnce(T) -> Option<T>
    {
        // In current implementation we can just remove the element and insert
        // it again, but this guarantee is not documented
        let idx_raw = idx.as_usize();
        if let Some(val) = self.remove(idx) {
            match fun(val) {
                Some(newval) => {
                    let nidx = self.insert(newval)
                        .ok().expect("We have just deleted");
                    // .. so we just assert that this guarantee is still ok
                    debug_assert!(idx_raw == nidx.as_usize());
                    Ok(())
                }
                None => Ok(()),
            }
        } else {
            Err(())
        }
    }
    fn as_mut(&mut self) -> Option<&mut T> {
        match *self {
            Entry::Filled(ref mut val) => Some(val),
            Entry::Empty(_) => None,
        }
    }
    fn as_ref(&self) -> Option<&T> {
        match *self {
            Entry::Filled(ref val) => Some(val),
            Entry::Empty(_) => None,
        }
    }
    fn put(&mut self, val: T) -> usize {
        match *self {
            Entry::Empty(nxt) => {
                mem::replace(self, Entry::Filled(val));
                nxt
            },
            Entry::Filled(_) => panic!("Should not happen"),
        }
    }
    fn test_replace_with() {
        let mut slab = Slab::<u32, usize>::new(16);
        let tok = slab.insert(5u32).unwrap();
        assert!(slab.replace_with(tok, |x| Some(x+1)).is_ok());
        assert!(slab.replace_with(tok+1, |x| Some(x+1)).is_err());
        assert_eq!(slab[tok], 6);
    }

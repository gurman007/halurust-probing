    fn from_ref(q: &Q) -> &Qey<Q> { unsafe { mem::transmute(q) } }
            fn borrow(&self) -> &Bar { &self.0 }
    pub fn contains_key<Q: ?Sized>(&self, k: &Q) -> bool where K: Borrow<Q>, Q: Eq + Hash {
        self.map.contains_key(Qey::from_ref(k))
    }
    pub fn get<Q: ?Sized>(&self, k: &Q) -> Option<&V> where K: Borrow<Q>, Q: Eq + Hash {
        self.map.get(Qey::from_ref(k)).map(|e| &e.value)
    }
    pub fn get_mut<Q: ?Sized>(&mut self, k: &Q) -> Option<&mut V> where K: Borrow<Q>, Q: Eq + Hash {
        self.map.get_mut(Qey::from_ref(k)).map(|e| &mut e.value)
    }
    pub fn get_refresh<Q: ?Sized>(&mut self, k: &Q) -> Option<&V> where K: Borrow<Q>, Q: Eq + Hash {
        let (value, node_ptr_opt) = match self.map.get_mut(Qey::from_ref(k)) {
            None => (None, None),
            Some(node) => {
                let node_ptr: *mut LinkedHashMapEntry<K, V> = &mut **node;
                (Some(unsafe { &(*node_ptr).value }), Some(node_ptr))
            }
        };
        match node_ptr_opt {
            None => (),
            Some(node_ptr) => {
                self.detach(node_ptr);
                self.attach(node_ptr);
            }
        }
        return value;
    }
    pub fn remove<Q: ?Sized>(&mut self, k: &Q) -> Option<V> where K: Borrow<Q>, Q: Eq + Hash {
        let removed = self.map.remove(Qey::from_ref(k));
        removed.map(|mut node| {
            let node_ptr: *mut LinkedHashMapEntry<K,V> = &mut *node;
            self.detach(node_ptr);
            node.value
        })
    }
    fn index(&self, index: &Q) -> &V {
        self.get(index).expect("no entry found for key")
    }
    fn index_mut(&mut self, index: &Q) -> &mut V {
        self.get_mut(index).expect("no entry found for key")
    }
    fn test_iter_mut() {
        let mut map = LinkedHashMap::new();
        map.insert("a", 10);
        map.insert("c", 30);
        map.insert("b", 20);

        {
            let mut iter = map.iter_mut();
            let entry = iter.next().unwrap();
            assert_eq!(&"a", entry.0);
            *entry.1 = 17;

            // reverse iterator
            let mut iter = iter.rev();
            let entry = iter.next().unwrap();
            assert_eq!(&"b", entry.0);
            *entry.1 = 23;

            let entry = iter.next().unwrap();
            assert_eq!(&"c", entry.0);
            assert_eq!(None, iter.next());
            assert_eq!(None, iter.next());
        }

        assert_eq!(17, map["a"]);
        assert_eq!(23, map["b"]);
    }

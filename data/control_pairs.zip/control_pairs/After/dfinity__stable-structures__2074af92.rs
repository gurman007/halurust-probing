    pub(super) fn load_v2<M: Memory>(
        address: Address,
        page_size: PageSize,
        header: NodeHeader,
        memory: &M,
    ) -> Self {
        #[cfg(feature = "bench_scope")]
        let _p = canbench_rs::bench_scope("node_load_v2"); // May add significant overhead.

        // Load the node, including any overflows, into a buffer.
        let overflows = read_overflows(address, memory);

        let reader = NodeReader {
            address,
            overflows: &overflows,
            page_size,
            memory,
        };

        let mut offset = Address::from(0);

        // Load the node type.
        let node_type = match header.node_type {
            LEAF_NODE_TYPE => NodeType::Leaf,
            INTERNAL_NODE_TYPE => NodeType::Internal,
            other => unreachable!("Unknown node type {}", other),
        };

        // Load the number of entries
        let num_entries = header.num_entries as usize;

        // Load children if this is an internal node.
        offset += ENTRIES_OFFSET;
        let children = if node_type == NodeType::Internal {
            // Empirical constant from benchmarks: individual reads are faster for ≤4 children.
            // From 5 up, batch reads consistently perform better.
            const CHILDREN_BATCH_READ_THRESHOLD: usize = 4;
            let count = num_entries + 1;
            if count <= CHILDREN_BATCH_READ_THRESHOLD {
                // For very small counts, use individual reads to avoid allocation overhead
                let mut children = Vec::with_capacity(count);
                for _ in 0..count {
                    children.push(Address::from(read_u64(&reader, offset)));
                    offset += Address::size();
                }
                children
            } else {
                // For larger counts, use the optimized batch read
                let children = read_address_vec(&reader, offset, count);
                offset += Bytes::from(count) * Address::size();
                children
            }
        } else {
            vec![]
        };

        // Load the keys (eagerly if small).
        const EAGER_LOAD_KEY_SIZE_THRESHOLD: u32 = 16;
        let mut entries = Vec::with_capacity(num_entries);
        let mut buf = vec![];

        for _ in 0..num_entries {
            let key_offset = Bytes::from(offset.get());

            // Get key size.
            let key_size = if K::BOUND.is_fixed_size() {
                K::BOUND.max_size()
            } else {
                let size = read_u32(&reader, offset);
                offset += U32_SIZE;
                size
            };

            // Eager-load small keys, defer large ones.
            let key = if key_size <= EAGER_LOAD_KEY_SIZE_THRESHOLD {
                read_to_vec(
                    &reader,
                    Address::from(offset.get()),
                    &mut buf,
                    key_size as usize,
                );
                LazyKey::by_value(K::from_bytes(Cow::Borrowed(&buf)))
            } else {
                LazyKey::by_ref(key_offset, key_size)
            };

            offset += Bytes::from(key_size);
            entries.push((key, LazyValue::by_ref(Bytes::from(0_u64), 0)));
        }

        // Load the values
        for (_key, value) in entries.iter_mut() {
            // Load the values lazily.
            let value_size = read_u32(&reader, offset);
            *value = LazyValue::by_ref(Bytes::from(offset.get()), value_size);
            offset += U32_SIZE + Bytes::from(value_size as u64);
        }

        Self {
            address,
            entries,
            children,
            node_type,
            version: Version::V2(page_size),
            overflows,
        }
    }
fn read_address_vec<M: Memory>(m: &M, addr: Address, count: usize) -> std::vec::Vec<Address> {
    let chunk_size = Address::size().get() as usize;
    assert_eq!(chunk_size, 8);
    let byte_len = count * chunk_size;
    let mut buf = std::vec::Vec::with_capacity(byte_len);
    read_to_vec(m, addr, &mut buf, byte_len);

    buf.chunks_exact(chunk_size)
        .map(|chunk| {
            // SAFETY: chunks_exact(chunk_size) ensures each chunk has exactly 8 bytes
            let bytes: [u8; 8] = chunk.try_into().expect("chunk must be 8 bytes");
            Address::from(u64::from_le_bytes(bytes))
        })
        .collect()
}

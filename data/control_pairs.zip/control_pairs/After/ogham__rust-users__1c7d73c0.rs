            fn new(gid: gid_t, name: &str) -> Group {
                Group {
                    gid: gid,
                    name: Arc::new(name.to_owned()),
                    members: Vec::new(),
                }
            }
        pub trait UserExt {

            /// Returns a path to this user’s home directory.
            fn home_dir(&self) -> &Path;

            /// Sets this user value’s home directory to the given string.
            /// Can be used to construct test users, which by default come with a
            /// dummy home directory string.
            fn with_home_dir(mut self, home_dir: &str) -> Self;

            /// Returns a path to this user’s shell.
            fn shell(&self) -> &Path;

            /// Sets this user’s shell path to the given string.
            /// Can be used to construct test users, which by default come with a
            /// dummy shell field.
            fn with_shell(mut self, shell: &str) -> Self;

            // TODO(ogham): Isn’t it weird that the setters take string slices, but
            // the getters return paths?
        }
            fn home_dir(&self) -> &Path {
                Path::new(&self.extras.home_dir)
            }
            fn with_home_dir(mut self, home_dir: &str) -> User {
                self.extras.home_dir = home_dir.to_owned();
                self
            }
            fn shell(&self) -> &Path {
                Path::new(&self.extras.shell)
            }
            fn with_shell(mut self, shell: &str) -> User {
                self.extras.shell = shell.to_owned();
                self
            }
            fn members(&self) -> &[String] {
                &*self.members
            }
            pub unsafe fn from_passwd(passwd: c_passwd) -> UserExtras {
                UserExtras {
                    extras: super::unix::UserExtras::from_passwd(passwd),
                }
            }
            fn default() -> UserExtras {
                UserExtras {
                    extras: super::unix::UserExtras::default(),
                }
            }

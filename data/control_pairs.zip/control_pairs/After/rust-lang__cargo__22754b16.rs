    pub fn new(gctx: &'a GlobalContext) -> CargoResult<Retry<'a>> {
        Ok(Retry {
            gctx,
            retries: 0,
            max_retries: gctx.net_config()?.retry.unwrap_or(MAX_RETRY_DEFAULT) as u64,
        })
    }

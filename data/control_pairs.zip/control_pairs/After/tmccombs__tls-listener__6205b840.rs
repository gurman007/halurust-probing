    pub fn accept(&mut self) -> impl Future<Output = Option<<Self as Stream>::Item>> + '_
    where
        Self: Unpin,
    {
        self.next()
    }
    pub fn replace_acceptor_pin(self: Pin<&mut Self>, acceptor: T) {
        *self.project().tls = acceptor;
    }
    pub fn replace_acceptor(&mut self, acceptor: T) {
        self.tls = acceptor;
    }

        fn test_memory_consumption() {
            use std::fmt::Write;
            let len_words = 100_000;
            let word_len = 8;
            let mut buf = String::with_capacity(word_len);

            fn read_stats() -> (usize, usize) {
                jemalloc_ctl::epoch::advance().unwrap();
                let allocated = jemalloc_ctl::stats::allocated::read().unwrap();
                let resident = jemalloc_ctl::stats::resident::read().unwrap();
                (allocated, resident)
            }

            let (allocated_before, resident_before) = read_stats();

            let mut interner = StringInterner::new();
            for i in (0..).take(len_words) {
                write!(&mut buf, "{:08}", i).unwrap();
                interner.get_or_intern(buf.as_str());
                buf.clear();
            }
            assert_eq!(interner.len(), len_words);

            let (allocated_after, resident_after) = read_stats();

            let allocated = allocated_after - allocated_before;
            let resident = resident_after - resident_before;
            let ideal = len_words * word_len;

            println!(
                "string interner consumed too much memory:\
                \n   interned words = {:9}\
                \n   bytes per word = {:9}\
                \n   ideal          = {:9}\
                \n   allocated      = {:9}\
                \n   resident       = {:9}",
                len_words, word_len, ideal, allocated, resident,
            );

            // Overhead for the string interners compared to ideal.
            //
            // An approximation for the currently known overhead for both
            // SimpleBackend and BucketBackend is factor 18 compared to ideal.
            let known_overhead = <$backend as BackendStats>::OVERHEAD;
            assert!((allocated as f64) < (ideal as f64 * known_overhead));
        }

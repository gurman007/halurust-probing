    fn country_id(
        #[case] number: PhoneNumber,
        #[case] country: Option<country::Id>,
        #[case] _type: Type,
    ) -> anyhow::Result<()> {
        // Flatten the error into an Option.
        // XXX: We can't currently distinguish an error case from an unavailable case, given the
        // current phone number list in rstest above.
        assert_eq!(country, number.country().id().ok().flatten());

        Ok(())
    }

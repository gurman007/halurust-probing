    fn test_item_from() {
        let string = "abc".to_string();
        let err: InnerItemError = string.into();
        assert_eq!(
            format!("{err}"),
            "decode xml to object has error, info: abc"
        );
    }
    fn test_list_from() {
        let string = "abc".to_string();
        let err: InnerListError = string.into();
        assert_eq!(
            format!("{err}"),
            "decode xml to object list has error, info: abc"
        );
    }
        fn bar() -> InnerListError {
            quick_xml::Error::TextNotFound.into()
        }
    fn test_common_prefixes() {
        struct ObjectA {}
        impl RefineObject<MyError> for ObjectA {}

        struct ListA {}

        struct MyError {}

        impl From<InnerItemError> for MyError {
            fn from(_: InnerItemError) -> Self {
                MyError {}
            }
        }

        impl From<quick_xml::Error> for MyError {
            fn from(_: quick_xml::Error) -> Self {
                MyError {}
            }
        }

        impl fmt::Display for MyError {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                write!(f, "demo")
            }
        }

        impl ItemError for MyError {}
        impl ListError for MyError {}

        impl RefineObjectList<ObjectA, MyError, MyError> for ListA {
            fn set_prefix(&mut self, prefix: &str) -> Result<(), MyError> {
                assert!(prefix == "bar");
                Ok(())
            }

            fn set_common_prefix(&mut self, list: &[Cow<'_, str>]) -> Result<(), MyError> {
                assert!(list[0] == "foo1/");
                assert!(list[1] == "foo2/");
                Ok(())
            }
        }

        let xml = r#"<?xml version="1.0" encoding="UTF-8"?>
        <ListBucketResult>
          <Prefix>bar</Prefix>
          <Contents>
            <Key>9AB932LY.jpeg</Key>
          </Contents>
          <Contents>
            <Key>9AB932LY.jpeg</Key>
          </Contents>
          <CommonPrefixes>
            <Prefix>foo1/</Prefix>
            <Prefix>foo2/</Prefix>
          </CommonPrefixes>
        </ListBucketResult>
        "#;

        let mut list = ListA {};

        let init_object = || ObjectA {};

        let res = list.decode(xml, init_object);

        assert!(res.is_ok());
    }

pub struct StackVec<A: Array> {
    // The capacity field is used for iteration and other optimizations.
    // Publicly expose the fields, so they may be used in constant
    // initialization.
    pub data: mem::MaybeUninit<A>,
    pub length: usize,
}
    pub fn new() -> StackVec<A> {
        StackVec {
            length: 0,
            data: mem::MaybeUninit::uninit(),
        }
    }
    pub unsafe fn from_vec_unchecked(mut vec: Vec<A::Item>) -> StackVec<A> {
        let mut data: A = mem::uninitialized();
        let len = vec.len();
        vec.set_len(0);
        ptr::copy_nonoverlapping(vec.as_ptr(), data.ptr_mut(), len);

        StackVec {
            length: len,
            data: mem::MaybeUninit::new(data),
        }
    }
    pub fn from_buf(buf: A) -> StackVec<A> {
        StackVec {
            length: A::size(),
            data: mem::MaybeUninit::new(buf),
        }
    }
    pub unsafe fn from_buf_and_len_unchecked(buf: A, len: usize) -> StackVec<A> {
        StackVec {
            length: len,
            data: mem::MaybeUninit::new(buf),
        }
    }
    pub fn into_inner(self) -> Result<A, Self> {
        if self.len() != A::size() {
            Err(self)
        } else {
            unsafe {
                let this = mem::ManuallyDrop::new(self);
                let array = ptr::read(this.as_ptr() as *const A);
                Ok(array)
            }
        }
    }
    pub fn from_slice(slice: &[A::Item]) -> Self {
        assert!(slice.len() <= A::size());
        StackVec {
            length: slice.len(),
            data: unsafe {
                let mut data: mem::MaybeUninit<A> = mem::MaybeUninit::uninit();
                let ptr = data.as_mut_ptr() as *mut A::Item;
                ptr::copy_nonoverlapping(slice.as_ptr(), ptr, slice.len());
                data
            }
        }
    }
    fn deref(&self) -> &[A::Item] {
        unsafe {
            let ptr = self.data.as_ptr() as *const A::Item;
            slice::from_raw_parts(ptr, self.len())
        }
    }
    fn deref_mut(&mut self) -> &mut [A::Item] {
        unsafe {
            let ptr = self.data.as_mut_ptr() as *mut A::Item;
            slice::from_raw_parts_mut(ptr, self.len())
        }
    }
    fn issue_5() {
        let vec = StackVec::<[&u32; 2]>::new();
        println!("{:?}", Some(vec));
        assert!(Some(StackVec::<[&u32; 2]>::new()).is_some());
    }

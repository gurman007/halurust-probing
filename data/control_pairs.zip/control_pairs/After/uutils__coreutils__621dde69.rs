fn exec(files: &[PathBuf], settings: &Settings) -> LnResult<()> {
    // Handle cases where we create links in a directory first.
    if let Some(ref target_path) = settings.target_dir {
        // 4th form: a directory is specified by -t.
        return link_files_in_dir(files, target_path, settings);
    }

    // if -T is specified we may have a wrong number of operands.
    match files.split_last().expect("clap rejects empty") {
        // the target directory is the current directory
        (_, []) if !settings.no_target_dir => {
            link_files_in_dir(files, &PathBuf::from("."), settings)
        }
        // create links in the last argument
        (last, rest) if !settings.no_target_dir && (rest.len() > 1 || last.is_dir()) => {
            link_files_in_dir(rest, last, settings)
        }
        (f0, []) => Err(LnError::MissingDestination(f0.clone())),
        (last, [f]) => link(f, last, settings),
        (extra, [_, _]) | (_, [_, _, extra, ..]) => Err(LnError::ExtraOperand(
            extra.into(),
            uucore::execution_phrase().to_string(),
        )),
    }
}

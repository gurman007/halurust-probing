pub struct Config {
    /// The selected profile. **(default: _debug_ `debug` / _release_ `release`)**
    ///
    /// **Note:** This field is never serialized nor deserialized. When a
    /// `Config` is merged into a `Figment` as a `Provider`, this profile is
    /// selected on the `Figment`. When a `Config` is extracted, this field is
    /// set to the extracting Figment's selected `Profile`.
    #[serde(skip)]
    pub profile: Profile,
    /// IP address to serve on. **(default: `127.0.0.1`)**
    pub address: IpAddr,
    /// Port to serve on. **(default: `8000`)**
    pub port: u16,
    /// Number of threads to use for executing futures. **(default: `num_cores`)**
    pub workers: usize,
    /// Keep-alive timeout in seconds; disabled when `0`. **(default: `5`)**
    pub keep_alive: u32,
    /// Streaming read size limits. **(default: [`Limits::default()`])**
    pub limits: Limits,
    /// The TLS configuration, if any. **(default: `None`)**
    pub tls: Option<TlsConfig>,
    /// How, if at all, to identify the server via the `Server` header.
    /// **(default: `"Rocket"`)**
    pub ident: Ident,
    /// The secret key for signing and encrypting. **(default: `0`)**
    ///
    /// **Note:** This field _always_ serializes as a 256-bit array of `0`s to
    /// aid in preventing leakage of the secret key.
    #[cfg(feature = "secrets")]
    #[cfg_attr(nightly, doc(cfg(feature = "secrets")))]
    #[serde(serialize_with = "SecretKey::serialize_zero")]
    pub secret_key: SecretKey,
    /// Directory to store temporary files in. **(default:
    /// [`std::env::temp_dir()`])**
    #[serde(serialize_with = "RelativePathBuf::serialize_relative")]
    pub temp_dir: RelativePathBuf,
    /// Max level to log. **(default: _debug_ `normal` / _release_ `critical`)**
    pub log_level: LogLevel,
    /// Graceful shutdown configuration. **(default: [`Shutdown::default()`])**
    pub shutdown: Shutdown,
    /// Whether to use colors and emoji when logging. **(default: `true`)**
    #[serde(deserialize_with = "figment::util::bool_from_str_or_int")]
    pub cli_colors: bool,
    /// PRIVATE: This structure may grow (but never change otherwise) in a
    /// non-breaking release. As such, constructing this structure should
    /// _always_ be done using a public constructor or update syntax:
    ///
    /// ```rust
    /// use rocket::Config;
    ///
    /// let config = Config {
    ///     port: 1024,
    ///     keep_alive: 10,
    ///     ..Default::default()
    /// };
    /// ```
    #[doc(hidden)]
    #[serde(skip)]
    pub __non_exhaustive: (),
}
    pub fn figment() -> Figment {
        Figment::from(Config::default())
            .merge(Toml::file(Env::var_or("ROCKET_CONFIG", "Rocket.toml")).nested())
            .merge(Env::prefixed("ROCKET_").ignore(&["PROFILE"]).global())
            .select(Profile::from_env_or("ROCKET_PROFILE", Self::DEFAULT_PROFILE))
    }
    pub(crate) fn pretty_print(&self, figment: &Figment) {
        use crate::log::PaintExt;

        launch_info!("{}Configured for {}.", Paint::emoji("🔧 "), self.profile);

        launch_info_!("address: {}", Paint::default(&self.address).bold());
        launch_info_!("port: {}", Paint::default(&self.port).bold());
        launch_info_!("workers: {}", Paint::default(self.workers).bold());
        launch_info_!("ident: {}", Paint::default(&self.ident).bold());

        let ka = self.keep_alive;
        if ka > 0 {
            launch_info_!("keep-alive: {}", Paint::default(format!("{}s", ka)).bold());
        } else {
            launch_info_!("keep-alive: {}", Paint::default("disabled").bold());
        }

        launch_info_!("limits: {}", Paint::default(&self.limits).bold());
        match self.tls_enabled() {
            true => launch_info_!("tls: {}", Paint::default("enabled").bold()),
            false => launch_info_!("tls: {}", Paint::default("disabled").bold()),
        }

        #[cfg(feature = "secrets")] {
            launch_info_!("secret key: {:?}", Paint::default(&self.secret_key).bold());
            if !self.secret_key.is_provided() {
                warn!("secrets enabled without a stable `secret_key`");
                launch_info_!("disable `secrets` feature or configure a `secret_key`");
                launch_info_!("this becomes an {} in non-debug profiles", Paint::red("error"));
            }
        }

        launch_info_!("temp dir: {}", Paint::default(&self.temp_dir.relative().display()).bold());
        launch_info_!("log level: {}", Paint::default(self.log_level).bold());
        launch_info_!("cli colors: {}", Paint::default(&self.cli_colors).bold());
        launch_info_!("shutdown: {}", Paint::default(&self.shutdown).bold());

        // Check for now depreacted config values.
        for (key, replacement) in Self::DEPRECATED_KEYS {
            if let Some(md) = figment.find_metadata(key) {
                warn!("found value for deprecated config key `{}`", Paint::white(key));
                if let Some(ref source) = md.source {
                    launch_info_!("in {} {}", Paint::white(source), md.name);
                }

                if let Some(new_key) = replacement {
                    launch_info_!("key has been by replaced by `{}`", Paint::white(new_key));
                } else {
                    launch_info_!("key has no special meaning");
                }
            }
        }

        // Check for now removed config values.
        for (prefix, replacement) in Self::DEPRECATED_PROFILES {
            if let Some(profile) = figment.profiles().find(|p| p.starts_with(prefix)) {
                warn!("found set deprecated profile `{}`", Paint::white(profile));

                if let Some(new_profile) = replacement {
                    launch_info_!("profile was replaced by `{}`", Paint::white(new_profile));
                } else {
                    launch_info_!("profile `{}` has no special meaning", profile);
                }
            }
        }
    }
    pub async fn ignite(mut self) -> Result<Rocket<Ignite>, Error> {
        self = Fairings::handle_ignite(self).await;
        self.fairings.audit().map_err(|f| ErrorKind::FailedFairings(f.to_vec()))?;

        // Extract the configuration; initialize the logger.
        #[allow(unused_mut)]
        let mut config = Config::try_from(&self.figment).map_err(ErrorKind::Config)?;
        crate::log::init(&config);

        // Check for safely configured secrets.
        #[cfg(feature = "secrets")]
        if !config.secret_key.is_provided() {
            if config.profile != Config::DEBUG_PROFILE {
                return Err(Error::new(ErrorKind::InsecureSecretKey(config.profile.clone())));
            }

            if config.secret_key.is_zero() {
                config.secret_key = crate::config::SecretKey::generate()
                    .unwrap_or_else(crate::config::SecretKey::zero);
            }
        };

        // Initialize the router; check for collisions.
        let mut router = Router::new();
        self.routes.clone().into_iter().for_each(|r| router.add_route(r));
        self.catchers.clone().into_iter().for_each(|c| router.add_catcher(c));
        router.finalize().map_err(ErrorKind::Collisions)?;

        // Finally, freeze managed state.
        self.state.freeze();

        // Log everything we know: config, routes, catchers, fairings.
        // TODO: Store/print managed state type names?
        config.pretty_print(self.figment());
        log_items("📬 ", "Routes", self.routes(), |r| &r.uri.base, |r| &r.uri);
        log_items("🥅 ", "Catchers", self.catchers(), |c| &c.base, |c| &c.base);
        self.fairings.pretty_print();

        // Ignite the rocket.
        let rocket: Rocket<Ignite> = Rocket(Igniting {
            router, config,
            shutdown: Shutdown(TripWire::new()),
            figment: self.0.figment,
            fairings: self.0.fairings,
            state: self.0.state,
        });

        // Query the sentinels, abort if requested.
        let sentinels = rocket.routes().flat_map(|r| r.sentinels.iter());
        sentinel::query(sentinels, &rocket).map_err(ErrorKind::SentinelAborts)?;

        Ok(rocket)
    }

    pub fn commit<E: Curve>(
        aux: &Aux,
        data: Data<E>,
        pdata: PrivateData<E>,
        security: &SecurityParams,
        rng: &mut impl RngCore,
    ) -> Result<(Commitment<E>, PrivateCommitment<E>), Error> {
        let two_to_l_plus_e = (Integer::ONE << (security.l + security.epsilon)).complete();
        let n_j_at_two_to_l = (Integer::ONE << security.l).complete() * &aux.rsa_modulo;
        let n_j_at_two_to_l_plus_e = (&two_to_l_plus_e * &aux.rsa_modulo).complete();

        let alpha = Integer::from_rng_half_pm(&two_to_l_plus_e, rng);
        let mu = Integer::from_rng_half_pm(&n_j_at_two_to_l, rng);
        let r = Integer::gen_invertible(data.key.n(), rng);
        let beta = Scalar::random(rng);
        let gamma = Integer::from_rng_half_pm(&n_j_at_two_to_l_plus_e, rng);

        let s = aux.combine(pdata.plaintext, &mu)?;
        let t = aux.combine(&alpha, &gamma)?;
        let d = data.key.encrypt_with(&alpha, &r)?;
        let y = data.a * beta + Point::<E>::generator() * alpha.to_scalar();
        let z = Point::<E>::generator() * beta;

        Ok((
            Commitment { s, t, d, y, z },
            PrivateCommitment {
                alpha,
                mu,
                r,
                beta,
                gamma,
            },
        ))
    }
    pub fn verify<E: Curve>(
        aux: &Aux,
        data: Data<E>,
        commitment: &Commitment<E>,
        security: &SecurityParams,
        challenge: &Challenge,
        proof: &Proof<E>,
    ) -> Result<(), InvalidProof> {
        {
            let lhs = data
                .key
                .encrypt_with(&proof.z1, &proof.z2)
                .map_err(|_| InvalidProofReason::PaillierEnc)?;
            let rhs = {
                let e_at_c = data
                    .key
                    .omul(challenge, data.ciphertext)
                    .map_err(|_| InvalidProofReason::PaillierOp)?;
                data.key
                    .oadd(&commitment.d, &e_at_c)
                    .map_err(|_| InvalidProofReason::PaillierOp)?
            };
            fail_if_ne(InvalidProofReason::EqualityCheck(1), lhs, rhs)?;
        }
        {
            let lhs = data.a * proof.w + Point::<E>::generator() * proof.z1.to_scalar();
            let rhs = commitment.y + data.x * challenge.to_scalar();
            fail_if_ne(InvalidProofReason::EqualityCheck(2), lhs, rhs)?;
        }
        {
            let lhs = Point::<E>::generator() * proof.w;
            let rhs = commitment.z + data.b * challenge.to_scalar();
            fail_if_ne(InvalidProofReason::EqualityCheck(3), lhs, rhs)?;
        }
        {
            let lhs = aux.combine(&proof.z1, &proof.z3)?;
            let rhs = {
                let s_to_e = aux.pow_mod(&commitment.s, challenge)?;
                (&commitment.t * s_to_e).modulo(&aux.rsa_modulo)
            };
            fail_if_ne(InvalidProofReason::EqualityCheck(4), lhs, rhs)?;
        }

        fail_if(
            InvalidProofReason::RangeCheck(5),
            proof
                .z1
                .is_in_half_pm(&(Integer::ONE << (security.l + security.epsilon)).complete()),
        )?;

        Ok(())
    }
    pub fn challenge<E: Curve>(rng: &mut impl RngCore) -> Challenge {
        Integer::from_rng_half_pm(&Integer::curve_order::<E>(), rng)
    }
    fn passing_test<C: Curve, D: Digest>() {
        let mut rng = rand_dev::DevRng::new();
        let security = super::SecurityParams {
            l: 1024,
            epsilon: 300,
        };
        let plaintext = Integer::from_rng_half_pm(&(Integer::ONE << security.l).complete(), &mut rng);
        run_with::<C, D>(&mut rng, security, plaintext).expect("proof failed");
    }
    fn failing_test<C: Curve, D: Digest>() {
        let mut rng = rand_dev::DevRng::new();
        let security = super::SecurityParams {
            l: 1024,
            epsilon: 300,
        };
        let plaintext = (Integer::ONE << (security.l + security.epsilon-1)).complete() + 1;
        let r = run_with::<C, D>(&mut rng, security, plaintext).expect_err("proof should not pass");
        match r.reason() {
            InvalidProofReason::RangeCheck(5) => (),
            e => panic!("proof should not fail with: {e:?}"),
        }
    }

pub unsafe fn str_from_ptr(ptr: *const ::std::os::raw::c_char) -> Result<Option<&'static str>, std::str::Utf8Error> {
    if ptr.is_null() {
        return Ok(None);
    }

    Some(unsafe { CStr::from_ptr(ptr) }.to_str()).transpose()
}
